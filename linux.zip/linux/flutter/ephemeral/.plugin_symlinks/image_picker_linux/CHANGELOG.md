## 0.2.2

* Adds support for `getMultiVideoWithOptions`.
* Updates minimum supported SDK version to Flutter 3.27/Dart 3.6.

## 0.2.1+2

* Updates minimum supported SDK version to Flutter 3.22/Dart 3.4.
* Fixes `getMedia` mime types.

## 0.2.1+1

* Adds pub topics to package metadata.
* Updates minimum supported SDK version to Flutter 3.7/Dart 2.19.

## 0.2.1

* Adds `getMedia` method.

## 0.2.0

* Implements initial Linux support.
