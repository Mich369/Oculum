part of '../../main.dart';

/// Tiro automatico del Vitalium Grezzo. Un 1 naturale e' un critico negativo:
/// puo' ridurre la cura, ma chi usa il risultato la limita sempre a zero.
int oculumRawVitaliumMedicineRoll({required int die, required int medicine}) {
  final total = die + medicine;
  return die == 1 ? -max(1, total.abs()) : total;
}

/// Gradi I-II: meta' del tiro; dal III: tiro intero. Mantiene il segno del
/// critico negativo, cosi' puo' annullare una cura ma non generare danno.
int oculumRawVitaliumMedicineBonus({
  required int grade,
  required int medicineRoll,
}) {
  if (grade >= 3) return medicineRoll;
  if (grade >= 1) return medicineRoll ~/ 2;
  return 0;
}

String oculumRawVitaliumRuleForGrade(int grade) {
  if (grade >= 3) {
    return 'Grado III+: attivo d30 + Medicina, tiro intero. Un 1 naturale può annullare la cura, mai fare danno.';
  }
  if (grade >= 2) {
    return 'Grado II: attivo d20 + Medicina, metà tiro. Un 1 naturale può annullare la cura, mai fare danno.';
  }
  if (grade >= 1) {
    return 'Grado I: attivo d10 + Medicina, metà tiro. Un 1 naturale può annullare la cura, mai fare danno.';
  }
  return 'Richiede Grado I per applicare il tiro automatico di Medicina.';
}

int oculumMerchantWeaponSkillDamage(int grade) => 5 + max(0, grade) * 10;

String oculumMerchantWeaponSkillName(String weaponName) {
  final lower = weaponName.toLowerCase();
  if (lower.contains('arco') || lower.contains('balestra')) {
    return 'Tiro di $weaponName';
  }
  if (lower.contains('martello') || lower.contains('mazza')) {
    return 'Schianto di $weaponName';
  }
  if (lower.contains('lancia') || lower.contains('picca')) {
    return 'Affondo di $weaponName';
  }
  if (lower.contains('ascia')) return 'Fendente di $weaponName';
  return 'Taglio di $weaponName';
}

String oculumMerchantWeaponSkillText(String weaponName, int grade) {
  final damage = oculumMerchantWeaponSkillDamage(grade);
  final nextDamage = damage + 5;
  return 'I/usi $weaponName: @Danni+$damage (1/4).\n'
      'II/@Danni+$nextDamage (2/4), scegli se spostare o esporre il bersaglio.\n'
      'III/@Danni+${nextDamage + 10} (3/4), il Master applica la conseguenza coerente con l arma.\n'
      'Al quarto uso la Skill va in recupero fino al turno successivo.';
}

/// Negoziante locale della scheda. Lo stock usa il salvataggio della scheda,
/// ma il suo identificatore di sessione lo rinnova solo dopo la chiusura e
/// riapertura dell'app: non cambia ad ogni rebuild o apertura del pannello.
extension _OculumHomeMerchant on _OculumHomePageState {
  List<Map<String, dynamic>> ensureMerchantStock() {
    if (merchantStockSessionId == merchantRuntimeSessionId &&
        merchantStock.isNotEmpty) {
      return merchantStock;
    }
    final random = Random(
      monsterSpriteStableSeed(currentSheetScrollId()) ^
          DateTime.now().microsecondsSinceEpoch,
    );
    final rawVitaliumRule = oculumRawVitaliumRuleForGrade(
      max(0, leggiNumero(gradoController)),
    );
    merchantStock = <Map<String, dynamic>>[
      {
        'id': 'raw_vitalium',
        'name': 'Vitalium Grezzo',
        'cost': 13 + random.nextInt(7),
        'kind': 'raw_vitalium',
        'desc':
            'Consumabile: cura HP pari all Oculum immesso. $rawVitaliumRule',
      },
      {
        'id': 'refined_vitalium',
        'name': 'Vitalium Ridefinito',
        'cost': 100 + random.nextInt(61),
        'kind': 'refined_vitalium',
        'desc': 'Refulla HP, integrita, Oculum e statistiche temporanee.',
      },
      {
        'id': 'oculum_vial',
        'name': 'Fiala di Oculum',
        'cost': 6 + random.nextInt(3),
        'kind': 'oculum_vial',
        'desc': 'Consumabile: ricarica 1d4 Oculum.',
      },
      {
        'id': 'title_item',
        'name': 'Item Titolo',
        'cost': 75 + random.nextInt(46),
        'kind': 'title_item',
        'desc': 'Scegli tu se diventa arma, armatura o scudo.',
      },
    ];
    if (random.nextInt(12) == 0) {
      merchantStock.add(<String, dynamic>{
        'id': 'scroll_bone_prison',
        'name': 'Pergamena della Prigione d Ossa',
        'cost': 160,
        'kind': 'bone_prison_scroll',
        'desc':
            'Rara. Imprigiona il bersaglio, applica Stordito e infligge danno perforante.',
      });
    }
    // Catalogo > 200 oggetti: ogni scheda ne vede solo pochi, ma non pesca
    // sempre dagli stessi dieci nomi. Lo stock salvato resta invariato fino al
    // prossimo avvio dell'app.
    const materials = <String>[
      'bronzo rovinato',
      'ferro opaco',
      'rame freddo',
      'osso levigato',
      'legno nero',
      'acciaio vecchio',
      'vetro fumé',
      'pietra di fiume',
      'cuoio duro',
      'argento annerito',
      'corallo secco',
      'cenere compressa',
      'ottone consumato',
      'salice rosso',
      'sale nero',
      'vetro di luna',
    ];
    const weapons = <String>[
      'coltellino',
      'spada corta',
      'spada lunga',
      'sciabola',
      'stocco',
      'ascia',
      'mazza',
      'martello',
      'lancia',
      'picca',
      'alabarda',
      'falce',
      'frusta',
      'arco',
      'balestra',
      'guanti d arme',
    ];
    const protections = <String>[
      'scudo',
      'brocchiere',
      'mantello',
      'giubba',
      'corazza',
      'piastra',
      'elmo',
      'bracciale',
      'stivali',
      'anello',
      'cappuccio',
      'targa',
    ];
    final catalog = <({String name, bool weapon})>[
      for (final material in materials)
        for (final weapon in weapons)
          (name: '$weapon di $material', weapon: true),
      for (final material in materials)
        for (final protection in protections)
          (name: '$protection di $material', weapon: false),
    ];
    for (var i = 0; i < 8; i++) {
      final source = catalog[random.nextInt(catalog.length)];
      final grade = random.nextInt(40) == 0 ? 1 + random.nextInt(12) : 0;
      final weapon = source.weapon;
      final damage = grade == 0
          ? 2 + random.nextInt(5)
          : 12 + grade * 8 + random.nextInt(7);
      final defence = grade == 0
          ? 1 + random.nextInt(3)
          : 3 + grade * 4 + random.nextInt(4);
      merchantStock.add(<String, dynamic>{
        'id': 'merchant_${i}_${random.nextInt(1 << 31)}',
        'name': source.name,
        'cost': grade == 0
            ? 25 + random.nextInt(51)
            : grade * (100 + random.nextInt(101)),
        'kind': 'gear',
        'grade': grade,
        'weapon': weapon,
        'damage': damage,
        'defence': defence,
        'quickReaction': grade > 0 && random.nextInt(9) == 0,
        'desc': grade == 0
            ? 'Reliquia minuta: bonus difensivo o offensivo contenuto.'
            : 'Oggetto graduato molto raro: richiede Grado $grade per essere equipaggiato.',
      });
    }
    merchantStockSessionId = merchantRuntimeSessionId;
    return merchantStock;
  }

  String merchantOfferDescription(Map<String, dynamic> offer) {
    if ('${offer['kind'] ?? ''}' == 'raw_vitalium') {
      return 'Consumabile: cura HP pari all Oculum immesso. ${oculumRawVitaliumRuleForGrade(max(0, leggiNumero(gradoController)))}';
    }
    if ('${offer['kind'] ?? ''}' == 'gear' && readBoolValue(offer['weapon'])) {
      final grade = readIntValue(offer['grade']);
      return '${offer['desc'] ?? ''}\nSkill: ${oculumMerchantWeaponSkillName('${offer['name'] ?? ''}')} — +${oculumMerchantWeaponSkillDamage(grade)} danni${grade > 0 ? ' (scala +10 per Grado)' : ''}.';
    }
    return '${offer['desc'] ?? ''}';
  }

  CharacterSkill merchantWeaponSkill(InventoryItem item) {
    final grade = max(item.gradoOggetto, item.gradoRichiesto);
    final name = oculumMerchantWeaponSkillName(item.nome);
    final text = oculumMerchantWeaponSkillText(item.nome, grade);
    return CharacterSkill(
      nome: name,
      tipo: 'Skill arma del Negoziante',
      costo: '1 azione',
      cooldown: 'Recupero dopo 4 usi',
      descrizione: text,
      danni: oculumMerchantWeaponSkillDamage(grade),
      equipaggiata: true,
      forme: <CharacterSkillForm>[
        CharacterSkillForm(
          nome: 'Forma I',
          tipo: 'Skill arma del Negoziante',
          costo: '1 azione',
          cooldown: 'Recupero dopo 4 usi',
          descrizione: text,
        ),
      ],
    );
  }

  Widget merchantQuickPanel() {
    final stock = ensureMerchantStock();
    return gothicPanel(
      borderColor: tertiaryColor.withValues(alpha: .7),
      padding: EdgeInsets.zero,
      child: Theme(
        data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
        child: ExpansionTile(
          collapsedBackgroundColor: const Color(0xFF151019),
          backgroundColor: const Color(0xFF0D1017),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          collapsedShape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          onExpansionChanged: (open) {
            // ignore: invalid_use_of_protected_member
            setState(() => merchantIsOpen = open);
          },
          tilePadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 3),
          childrenPadding: const EdgeInsets.fromLTRB(10, 0, 10, 10),
          leading: Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const LinearGradient(
                colors: [Color(0xFFC4863C), Color(0xFF442315)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              border: Border.all(color: const Color(0xFFE6D8BD)),
            ),
            child: const Icon(Icons.storefront_outlined, color: Colors.white),
          ),
          title: Row(
            children: [
              Expanded(
                child: Text(
                  t('Mercante in vista', 'Merchant in sight'),
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w900,
                    letterSpacing: .4,
                  ),
                ),
              ),
              Text(
                '${leggiNumero(obserController)} O',
                style: const TextStyle(
                  color: Color(0xFFFFD977),
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
          subtitle: Text(
            t(
              'Bancarella personale · stock fisso fino alla prossima apertura dell app.',
              'Personal stall · fixed stock until the next app launch.',
            ),
            style: const TextStyle(color: Colors.white70, fontSize: 11),
          ),
          children: [
            Align(
              alignment: Alignment.centerLeft,
              child: OutlinedButton.icon(
                onPressed:
                    merchantDustPurchasedSinceLongRest ||
                        leggiNumero(obserController) < 20
                    ? null
                    : buyAscensionDustFromMerchant,
                icon: const Icon(Icons.auto_awesome_outlined),
                label: Text(
                  merchantDustPurchasedSinceLongRest
                      ? t(
                          'Dust acquistata · disponibile dopo il Riposo Lungo',
                          'Dust purchased · available after a Long Rest',
                        )
                      : t(
                          '20 Obser → 1 Ascension Dust · 1 per Riposo Lungo',
                          '20 Obser → 1 Ascension Dust · 1 per Long Rest',
                        ),
                ),
              ),
            ),
            for (final offer in stock)
              Container(
                margin: const EdgeInsets.only(top: 7),
                decoration: BoxDecoration(
                  color: const Color(0xFF18151C),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: readIntValue(offer['grade']) > 0
                        ? const Color(0xFFFFC35B).withValues(alpha: .72)
                        : Colors.white24,
                  ),
                ),
                child: ListTile(
                  dense: true,
                  title: Text(
                    '${offer['name']}',
                    style: const TextStyle(color: Colors.white),
                  ),
                  subtitle: Text(
                    merchantOfferDescription(offer),
                    style: const TextStyle(color: Colors.white70, fontSize: 11),
                  ),
                  trailing: FilledButton(
                    onPressed:
                        leggiNumero(obserController) <
                            readIntValue(offer['cost'])
                        ? null
                        : () => buyMerchantOffer(offer),
                    child: Text('${offer['cost']} O'),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  // ignore: unused_element
  Future<void> showMerchantDialog() async {
    final stock = ensureMerchantStock();
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, refresh) => AlertDialog(
          backgroundColor: const Color(0xFF0D0C13),
          title: Text('Negoziante', style: TextStyle(color: tertiaryColor)),
          content: SizedBox(
            width: min(620, MediaQuery.sizeOf(context).width * .94),
            height: min(560, MediaQuery.sizeOf(context).height * .68),
            child: ListView.builder(
              itemCount: stock.length,
              itemBuilder: (context, index) {
                final offer = stock[index];
                final cost = readIntValue(offer['cost']);
                return ListTile(
                  title: Text(
                    '${offer['name']}',
                    style: const TextStyle(color: Colors.white),
                  ),
                  subtitle: Text(
                    merchantOfferDescription(offer),
                    style: const TextStyle(color: Colors.white70),
                  ),
                  trailing: FilledButton(
                    onPressed: leggiNumero(obserController) < cost
                        ? null
                        : () async {
                            await buyMerchantOffer(offer);
                            if (mounted) refresh(() {});
                          },
                    child: Text('$cost O'),
                  ),
                );
              },
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: Text(t('Chiudi', 'Close')),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> buyMerchantOffer(Map<String, dynamic> offer) async {
    final cost = readIntValue(offer['cost']);
    if (leggiNumero(obserController) < cost) return;
    final kind = '${offer['kind'] ?? ''}';
    String titleType = '';
    if (kind == 'title_item') {
      titleType =
          await showDialog<String>(
            context: context,
            builder: (context) => SimpleDialog(
              title: const Text('Scegli il tuo Item Titolo'),
              children: [
                SimpleDialogOption(
                  onPressed: () => Navigator.pop(context, 'arma'),
                  child: const Text('Arma'),
                ),
                SimpleDialogOption(
                  onPressed: () => Navigator.pop(context, 'armatura'),
                  child: const Text('Armatura'),
                ),
                SimpleDialogOption(
                  onPressed: () => Navigator.pop(context, 'scudo'),
                  child: const Text('Scudo'),
                ),
              ],
            ),
          ) ??
          '';
      if (titleType.isEmpty) return;
    }
    // ignore: invalid_use_of_protected_member
    // ignore: invalid_use_of_protected_member
    setState(() {
      obserController.text = (leggiNumero(obserController) - cost).toString();
      final item = merchantItemFromOffer(offer, titleType: titleType);
      inventario.add(item);
      if (item.arma) {
        final weaponSkill = merchantWeaponSkill(item);
        if (!skills.any((skill) => skill.nome == weaponSkill.nome)) {
          skills.add(weaponSkill);
        }
      }
      risultato = 'Negoziante: hai speso $cost Obser per ${item.nome}.';
      aggiungiLog(risultato);
    });
    programmaSalvataggio();
  }

  /// Il mercante paga circa un sesto del valore stimato: utile, ma spilorcio.
  int merchantSaleValue(InventoryItem item) {
    final grade = max(item.gradoOggetto, item.gradoRichiesto);
    final rawValue =
        18 +
        item.bonusDanno * 8 +
        item.bonusDifesa * 10 +
        item.bonusScudo * 3 +
        item.bonusScudoOculum * 12 +
        grade * grade * 90;
    return max(1, rawValue ~/ 6) * max(1, item.quantita);
  }

  void sellInventoryItemToMerchant(InventoryItem item) {
    if (!merchantIsOpen || !inventario.contains(item)) return;
    final payment = merchantSaleValue(item);
    // ignore: invalid_use_of_protected_member
    setState(() {
      if (item.equipaggiata) {
        applicaScudoItemAttuale(item, -1);
        item.equipaggiata = false;
      }
      inventario.remove(item);
      obserController.text = (leggiNumero(obserController) + payment)
          .toString();
      risultato = 'Negoziante: hai venduto ${item.nome} per $payment Obser.';
      aggiungiLog(risultato);
    });
    programmaSalvataggio();
  }

  void buyAscensionDustFromMerchant() {
    if (merchantDustPurchasedSinceLongRest || leggiNumero(obserController) < 20) {
      return;
    }
    // ignore: invalid_use_of_protected_member
    setState(() {
      obserController.text = (leggiNumero(obserController) - 20).toString();
      ascensionDustController.text = (leggiNumero(ascensionDustController) + 1)
          .toString();
      merchantDustPurchasedSinceLongRest = true;
      risultato = 'Negoziante: 20 Obser convertiti in 1 Ascension Dust.';
      aggiungiLog(risultato);
    });
    programmaSalvataggio();
  }

  InventoryItem merchantItemFromOffer(
    Map<String, dynamic> offer, {
    String titleType = '',
  }) {
    final kind = '${offer['kind'] ?? ''}';
    if (kind == 'raw_vitalium') {
      return InventoryItem(
        nome: 'Vitalium Grezzo',
        peso: .1,
        quantita: 1,
        note:
            'Consumabile: cura HP pari all Oculum immesso. ${oculumRawVitaliumRuleForGrade(max(0, leggiNumero(gradoController)))}',
      );
    }
    if (kind == 'refined_vitalium') {
      return InventoryItem(
        nome: 'Vitalium Ridefinito',
        peso: .2,
        quantita: 1,
        note:
            'Consumabile: refulla HP, integrita, Oculum e statistiche temporanee.',
      );
    }
    if (kind == 'oculum_vial') {
      return InventoryItem(
        nome: 'Fiala di Oculum',
        peso: .1,
        quantita: 1,
        note: 'Consumabile: ricarica 1d4 Oculum.',
      );
    }
    if (kind == 'bone_prison_scroll') {
      return InventoryItem(
        nome: 'Pergamena della Prigione d Ossa',
        peso: .1,
        quantita: 1,
        note:
            'Usabile: infligge 12 danni perforanti e applica Stordito per 1 turno al bersaglio della scheda attiva.',
      );
    }
    final grade = readIntValue(offer['grade']);
    final isTitle = kind == 'title_item';
    final weapon = isTitle
        ? titleType == 'arma'
        : readBoolValue(offer['weapon']);
    final shield = isTitle ? titleType == 'scudo' : !weapon && grade > 0;
    return InventoryItem(
      nome: isTitle ? 'Item Titolo — $titleType' : '${offer['name']}',
      peso: 1.2,
      quantita: 1,
      note: isTitle
          ? 'Oggetto scelto dal Negoziante.'
          : weapon
          ? '${offer['desc']}\nSkill: ${oculumMerchantWeaponSkillName('${offer['name'] ?? ''}')}. ${oculumMerchantWeaponSkillText('${offer['name'] ?? ''}', grade)}'
          : '${offer['desc']}',
      arma: weapon,
      protegge: !weapon,
      bonusDanno: weapon
          ? max(0, readIntValue(offer['damage'], fallback: 2 + grade * 8))
          : 0,
      bonusDifesa: weapon
          ? 0
          : max(0, readIntValue(offer['defence'], fallback: 1 + grade * 4)),
      bonusScudo: shield ? 4 + grade * 10 : (weapon ? 0 : 2 + grade * 4),
      bonusScudoOculum: grade >= 3 && shield ? 4 + grade * 3 : 0,
      gradoOggetto: grade,
      gradoRichiesto: grade,
      elementoDanno: grade >= 2 ? 'Oculum' : 'Fisico',
      buff: readBoolValue(offer['quickReaction'])
          ? '@ReazioneVeloce+1'
          : grade >= 3 && shield
          ? '@SchivateOculum+1'
          : '',
    );
  }

  bool isMerchantConsumable(InventoryItem item) => const <String>{
    'Vitalium Grezzo',
    'Vitalium Ridefinito',
    'Fiala di Oculum',
    'Pergamena della Prigione d Ossa',
    'Pinna di Pesce Alato',
  }.contains(item.nome.trim());

  Future<void> useMerchantConsumable(InventoryItem item) async {
    if (!inventario.contains(item) || !isMerchantConsumable(item)) return;
    var amount = 0;
    if (item.nome.trim() == 'Vitalium Grezzo') {
      final available = max(0, leggiNumero(currentOculumController));
      if (available <= 0) {
        risultato = 'Vitalium Grezzo: non hai Oculum da immettere.';
        aggiungiLog(risultato);
        return;
      }
      final input = TextEditingController(text: '1');
      amount =
          await showDialog<int>(
            context: context,
            builder: (dialogContext) => AlertDialog(
              title: const Text('Vitalium Grezzo'),
              content: TextField(
                controller: input,
                autofocus: true,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: 'Oculum da immettere (1–$available)',
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(dialogContext),
                  child: const Text('Annulla'),
                ),
                FilledButton(
                  onPressed: () => Navigator.pop(
                    dialogContext,
                    readIntValue(input.text).clamp(1, available),
                  ),
                  child: const Text('Usa'),
                ),
              ],
            ),
          ) ??
          0;
      input.dispose();
      if (amount <= 0) return;
    }
    // ignore: invalid_use_of_protected_member
    setState(() {
      switch (item.nome.trim()) {
        case 'Vitalium Grezzo':
          final grade = max(0, leggiNumero(gradoController));
          final medicineDieFaces = grade >= 3
              ? 30
              : grade >= 2
              ? 20
              : 10;
          final medicineDie = Random().nextInt(medicineDieFaces) + 1;
          final medicineRoll = oculumRawVitaliumMedicineRoll(
            die: medicineDie,
            medicine: medicinaAttualeAggiustaNucleo(),
          );
          final medicineBonus = oculumRawVitaliumMedicineBonus(
            grade: grade,
            medicineRoll: medicineRoll,
          );
          final heal = max(0, amount + medicineBonus);
          currentOculumController.text = max(
            0,
            leggiNumero(currentOculumController) - amount,
          ).toString();
          currentHpController.text = min(
            maxHp(),
            leggiNumero(currentHpController) + heal,
          ).toString();
          final medicineDetails = grade < 1
              ? ' d$medicineDieFaces Medicina: $medicineDie, tiro $medicineRoll: nessun bonus prima del Grado I.'
              : grade >= 3
              ? ' d$medicineDieFaces Medicina: $medicineDie, tiro $medicineRoll: ${medicineBonus >= 0 ? '+' : ''}$medicineBonus HP.'
              : ' d$medicineDieFaces Medicina: $medicineDie, tiro $medicineRoll, metà: ${medicineBonus >= 0 ? '+' : ''}$medicineBonus HP.';
          risultato =
              'Vitalium Grezzo: -$amount Oculum, +$heal HP.$medicineDetails${heal == 0 && medicineBonus < 0 ? ' Il critico negativo ha annullato la cura, senza infliggere danno.' : ''}';
          break;
        case 'Vitalium Ridefinito':
          currentHpController.text = maxHp().toString();
          currentOculumController.text = oculumTotale().toString();
          for (final art in arti) {
            art.integritaCorrente = artIntegrityEffectiveMaximum(art);
          }
          currentResilienzaController.text = resilienzaTotale().toString();
          currentVolontaController.text = volontaTotale().toString();
          currentMateriaController.text = materiaTotale().toString();
          currentOculumController.text = oculumTotale().toString();
          risultato = 'Vitalium Ridefinito: risorse e integrita ripristinate.';
          break;
        case 'Fiala di Oculum':
          amount = Random().nextInt(4) + 1;
          currentOculumController.text = min(
            oculumTotale(),
            leggiNumero(currentOculumController) + amount,
          ).toString();
          risultato = 'Fiala di Oculum: +$amount Oculum (1d4).';
          break;
        case 'Pergamena della Prigione d Ossa':
          final before = hpCorrenti();
          currentHpController.text = max(0, before - 12).toString();
          applyCondition(
            'stordito',
            duration: 1,
            source: 'Pergamena della Prigione d Ossa',
          );
          risultato =
              'Pergamena della Prigione d Ossa: 12 danni perforanti e Stordito per 1 turno.';
          break;
        case 'Pinna di Pesce Alato':
          applyCondition(
            'nuoto_aria',
            duration: 3,
            source: 'Pinna di Pesce Alato',
          );
          risultato =
              'Pinna di Pesce Alato: Nuoto nell’Aria attivo per 3 turni.';
          break;
      }
      if (item.quantita > 1) {
        item.quantita--;
      } else {
        inventario.remove(item);
      }
      aggiungiLog(risultato);
    });
    programmaSalvataggio();
  }
}
