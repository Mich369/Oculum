part of '../../main.dart';

// ignore_for_file: invalid_use_of_protected_member, unused_element

const String oculumSheetShareCodePrefix = 'OCULUM-SHEETS-v1:';
const String oculumSheetShareCodePrefixV2 = 'OC2:';

/// FNV-1a a 32 bit: breve, deterministico e sufficiente per riconoscere un
/// codice copiato male. Non è una firma crittografica e non sostituisce il
/// decoder legacy, che continua a essere accettato.
String oculumShareChecksum(Iterable<int> bytes) {
  var hash = 0x811c9dc5;
  for (final byte in bytes) {
    hash ^= byte & 0xff;
    hash = (hash * 0x01000193) & 0xffffffff;
  }
  return hash.toRadixString(16).padLeft(8, '0');
}

List<Map<String, dynamic>> oculumDecodeSheetShareText(String rawText) {
  List<Map<String, dynamic>> sheetsFromPayload(dynamic decoded) {
    if (decoded is! Map) {
      throw const FormatException('Payload non valido.');
    }
    final map = Map<String, dynamic>.from(decoded);
    final rawSheets = map['sheets'] ?? map['schedePersonaggio'];
    if (rawSheets is List) {
      return rawSheets
          .whereType<Map>()
          .map((sheet) => Map<String, dynamic>.from(sheet))
          .toList();
    }
    if (map.containsKey('nome') || map.containsKey('tipoScheda')) {
      return <Map<String, dynamic>>[map];
    }
    throw const FormatException('Nessuna scheda trovata.');
  }

  final text = rawText.trim();
  if (text.isEmpty) throw const FormatException('Il codice e vuoto.');
  final codeParts = text
      .split(RegExp(r'[\s,;]+'))
      .map((part) => part.trim())
      .where(
        (part) =>
            part.startsWith(oculumSheetShareCodePrefix) ||
            part.startsWith(oculumSheetShareCodePrefixV2),
      )
      .toList();
  if (codeParts.isEmpty) return sheetsFromPayload(jsonDecode(text));

  final sheets = <Map<String, dynamic>>[];
  for (final code in codeParts) {
    final isV2 = code.startsWith(oculumSheetShareCodePrefixV2);
    var encoded = code
        .substring(
          isV2
              ? oculumSheetShareCodePrefixV2.length
              : oculumSheetShareCodePrefix.length,
        )
        .trim();
    String? checksum;
    if (isV2) {
      final separator = encoded.indexOf(':');
      // OC2 originale era "OC2:<payload>". OC2 nuovo è
      // "OC2:<checksum>:<payload>": entrambe le forme restano importabili.
      if (separator == 8 &&
          RegExp(r'^[0-9a-fA-F]{8}$').hasMatch(encoded.substring(0, 8))) {
        checksum = encoded.substring(0, 8).toLowerCase();
        encoded = encoded.substring(separator + 1);
      }
    }
    while (encoded.length % 4 != 0) {
      encoded += '=';
    }
    final bytes = base64Url.decode(encoded);
    if (checksum != null && oculumShareChecksum(bytes) != checksum) {
      throw const FormatException(
        'Codice OC2 corrotto o copiato incompleto: controllo integrità non valido.',
      );
    }
    final decodedText = utf8.decode(isV2 ? gzip.decode(bytes) : bytes);
    sheets.addAll(sheetsFromPayload(jsonDecode(decodedText)));
  }
  if (sheets.isEmpty) {
    throw const FormatException('Nessuna scheda trovata.');
  }
  return sheets;
}

dynamic oculumDecodeJsonText(String text) => jsonDecode(text);

extension _OculumHomeRulesSettingsSearch on _OculumHomePageState {
  // REGOLE / MANUALE
  // =====================================================

  String manualPdfSafeText(String value) {
    return cleanUiText(value)
        .replaceAll('•', '-')
        .replaceAll('•', '-')
        .replaceAll('—', '-')
        .replaceAll('–', '-')
        .replaceAll('¼', '1/4')
        .replaceAll('½', '1/2')
        .replaceAll('¾', '3/4')
        .replaceAll('⅓', '1/3')
        .replaceAll('⅔', '2/3');
  }

  String manualPdfExtraSafeText(String value) {
    return manualPdfSafeText(value)
        .replaceAll('•', '-')
        .replaceAll('—', '-')
        .replaceAll('–', '-')
        .replaceAll('→', '->')
        .replaceAll('’', "'")
        .replaceAll('“', '"')
        .replaceAll('”', '"')
        .replaceAll('…', '...')
        .replaceAll('¼', '1/4')
        .replaceAll('½', '1/2')
        .replaceAll('¾', '3/4')
        .replaceAll('⅓', '1/3')
        .replaceAll('⅔', '2/3')
        .replaceAll('Ã ', 'a')
        .replaceAll('Ã¨', 'e')
        .replaceAll('Ã©', 'e')
        .replaceAll('Ã¬', 'i')
        .replaceAll('Ã²', 'o')
        .replaceAll('Ã¹', 'u')
        .replaceAll('à', 'a')
        .replaceAll('è', 'e')
        .replaceAll('é', 'e')
        .replaceAll('ì', 'i')
        .replaceAll('ò', 'o')
        .replaceAll('ù', 'u');
  }

  String manualParserExamplesPdfText() {
    return t(
      '''
Esempi complessi funzionanti:

@Resistenza Fuoco
Riduce il danno Fuoco in arrivo.

@FragilitaVera Acqua
Aumenta molto il danno Acqua in arrivo.

@ResistenzaImpenetrabile fisico
Riduce fortemente il danno fisico/normale.

@DanniSubiti+15% Acqua
Aumenta del 15% il danno Acqua dopo difesa e modificatori.

@DanniSubiti-6 fuoco
Toglie 6 danni Fuoco dopo difesa e modificatori.

@safehp
Consumabile: se un colpo ti porterebbe a 0 HP, resti a 1 HP.

@saveShield+30
Consumabile: se dopo un colpo resti vivo a 25% HP o meno, ottieni 30 Scudo.

Combo esempio:
@Resistenza Fuoco
@DanniSubiti-6 Fuoco
@saveShield+25
Un colpo Fuoco viene ridotto, poi perde 6 danni; se sopravvivi sotto il 25% HP ricevi 25 Scudo.
''',
      '''
Working complex examples:

@Resistenza Fuoco
Reduces incoming Fire damage.

@FragilitaVera Acqua
Greatly increases incoming Water damage.

@ResistenzaImpenetrabile fisico
Strongly reduces physical/normal damage.

@DanniSubiti+15% Acqua
Increases Water damage by 15% after defense and modifiers.

@DanniSubiti-6 fuoco
Removes 6 Fire damage after defense and modifiers.

@safehp
Consumable: if a hit would take you to 0 HP, you stay at 1 HP.

@saveShield+30
Consumable: if after a hit you survive at 25% HP or lower, you gain 30 Shield.

Combo example:
@Resistenza Fuoco
@DanniSubiti-6 Fuoco
@saveShield+25
A Fire hit is reduced, then loses 6 damage; if you survive under 25% HP you gain 25 Shield.
''',
    );
  }

  List<String> manualPdfSplitTextBlocks(String value, {int maxChars = 650}) {
    final text = manualPdfExtraSafeText(
      value,
    ).replaceAll('\r\n', '\n').replaceAll('\r', '\n').trim();
    if (text.isEmpty) return const <String>[];

    final blocks = <String>[];

    void addWrappedLine(String rawLine) {
      final line = rawLine.trim();
      if (line.isEmpty) return;
      if (line.length <= maxChars) {
        blocks.add(line);
        return;
      }

      final words = line.split(RegExp(r'\s+'));
      final buffer = StringBuffer();
      for (final word in words) {
        if (word.isEmpty) continue;
        final nextLength = buffer.isEmpty
            ? word.length
            : buffer.length + 1 + word.length;
        if (nextLength > maxChars && buffer.isNotEmpty) {
          blocks.add(buffer.toString());
          buffer.clear();
        }
        if (buffer.isNotEmpty) buffer.write(' ');
        buffer.write(word);
      }
      if (buffer.isNotEmpty) blocks.add(buffer.toString());
    }

    for (final paragraph in text.split(RegExp(r'\n{2,}'))) {
      for (final line in paragraph.split('\n')) {
        addWrappedLine(line);
      }
    }

    return blocks;
  }

  List<pw.Widget> manualPdfTextWidgets(String value, pw.TextStyle style) {
    final blocks = manualPdfSplitTextBlocks(value);
    return [
      for (final block in blocks) ...[
        pw.Text(block, style: style),
        pw.SizedBox(height: 4),
      ],
    ];
  }

  Future<void> salvaManualePdfAggiornato() async {
    setState(() {
      risultato = t('Genero il PDF del manuale...', 'Generating manual PDF...');
    });

    try {
      final now = DateTime.now();
      final stamp =
          '${now.year}${now.month.toString().padLeft(2, '0')}${now.day.toString().padLeft(2, '0')}_${now.hour.toString().padLeft(2, '0')}${now.minute.toString().padLeft(2, '0')}';
      final fileName = 'oculum_manuale_$stamp.pdf';
      final bytes = await oculumBuildManualPdf(english: linguaInglese);
      if (kIsWeb) {
        await oculumDownloadBytes(
          bytes: bytes,
          fileName: fileName,
          mimeType: 'application/pdf',
        );
        if (!mounted) return;
        setState(() {
          risultato = t(
            'Download manuale PDF avviato.',
            'Manual PDF download started.',
          );
          aggiungiLog(risultato);
        });
        return;
      }

      Directory dir;
      try {
        dir = await getApplicationDocumentsDirectory();
      } catch (_) {
        dir = Directory.current;
      }
      final file = File('${dir.path}${Platform.pathSeparator}$fileName');
      await file.writeAsBytes(bytes);

      if (!mounted) return;
      setState(() {
        risultato = t(
          'Manuale PDF salvato: ${file.path}',
          'Manual PDF saved: ${file.path}',
        );
        aggiungiLog(risultato);
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        risultato = t(
          'Errore salvataggio PDF manuale: $error',
          'Manual PDF save error: $error',
        );
        aggiungiLog(risultato);
      });
    }
  }

  Widget manualIndexButton(int index) {
    final section = activeManualSections[index];
    final selected = manualSectionIndex == index;

    return GestureDetector(
      onTap: () {
        setState(() => manualSectionIndex = index);
      },
      child: Container(
        width: double.infinity,
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
        decoration: BoxDecoration(
          color: selected
              ? tertiaryColor.withValues(alpha: 0.20)
              : Colors.black.withValues(alpha: 0.28),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(
            color: selected
                ? tertiaryColor
                : primaryColor.withValues(alpha: 0.35),
            width: selected ? 1.5 : 1.0,
          ),
        ),
        child: Row(
          children: [
            Icon(
              selected ? Icons.visibility : Icons.menu_book,
              color: selected ? tertiaryColor : Colors.grey.shade400,
              size: 18,
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                manualTitle(section),
                style: TextStyle(
                  color: selected ? tertiaryColor : Colors.white,
                  fontWeight: selected ? FontWeight.bold : FontWeight.normal,
                  fontSize: 13.5,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget rulesPageEfficient() {
    final filteredIndexes = manualFilteredIndexes();

    if (manualSectionIndex < 0 ||
        manualSectionIndex >= activeManualSections.length) {
      manualSectionIndex = 0;
    }

    final section = activeManualSections[manualSectionIndex];
    final builders = <WidgetBuilder>[
      (_) => functionAnchor('rules_root', sectionTitle(t('Regole', 'Rules'))),
      (_) => manualQuickToolsPanel(),
      (_) => appUsageGuideNavigationPanel(),
      (_) => rulesManualIntroPanelEfficient(),
      (_) => rulesSearchPanelEfficient(filteredIndexes.length),
      (_) => sectionTitle(t('Indice', 'Index')),
    ];

    if (filteredIndexes.isEmpty) {
      builders.add(
        (_) => gothicPanel(
          borderColor: tertiaryColor,
          child: Text(t('Nessuna sezione trovata.', 'No section found.')),
        ),
      );
    } else {
      for (final index in filteredIndexes) {
        final manualIndex = index;
        builders.add(
          (_) => RepaintBoundary(
            key: ValueKey('manual_index_$manualIndex'),
            child: gothicPanel(
              borderColor: tertiaryColor.withValues(alpha: 0.55),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              child: manualIndexButton(manualIndex),
            ),
          ),
        );
      }
    }

    builders.addAll([
      (_) => functionAnchor(
        'rules_open_section',
        sectionTitle(t('Sezione Aperta', 'Opened Section')),
      ),
      (_) => rulesOpenedSectionPanelEfficient(section),
    ]);

    final fullWidthIndexes = <int>{
      0,
      5,
      builders.length - 2,
      builders.length - 1,
    };

    return responsivePageBuilder(
      pageKey: 'rules',
      builders: builders,
      fullWidthIndexes: fullWidthIndexes,
      maxColumns: 3,
      minColumnWidth: 320,
      cacheExtent: 420,
      primary: false,
      physics: const AlwaysScrollableScrollPhysics(
        parent: ClampingScrollPhysics(),
      ),
      respectKeyboardInsets: true,
    );
  }

  Widget rulesManualIntroPanelEfficient() {
    return gothicPanel(
      borderColor: tertiaryColor,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'MANUALE OCULUM',
            style: TextStyle(
              color: tertiaryColor,
              fontSize: 24,
              fontWeight: FontWeight.w900,
              letterSpacing: 2.5,
            ),
          ),
          const SizedBox(height: 10),
          smallInfoText(
            t(
              'Questo manuale e pensato anche per nuovi giocatori. Ogni sezione spiega non solo la regola, ma anche il senso narrativo dietro la regola.',
              'This manual is also written for new players. Each section explains not only the rule, but also the narrative meaning behind it.',
            ),
          ),
          const SizedBox(height: 12),
          ElevatedButton.icon(
            onPressed: salvaManualePdfAggiornato,
            icon: const Icon(Icons.picture_as_pdf),
            label: Text(t('Salva PDF aggiornato', 'Save updated PDF')),
            style: ElevatedButton.styleFrom(
              backgroundColor: tertiaryColor,
              foregroundColor: tertiaryColor.computeLuminance() > 0.45
                  ? Colors.black
                  : Colors.white,
            ),
          ),
        ],
      ),
    );
  }

  Widget rulesSearchPanelEfficient(int resultCount) {
    return gothicPanel(
      borderColor: primaryColor,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            t('Cerca nel Manuale', 'Search Manual'),
            style: TextStyle(
              color: primaryColor,
              fontWeight: FontWeight.bold,
              fontSize: 18,
            ),
          ),
          const SizedBox(height: 12),
          campoTesto(
            label: t(
              'Cerca regole, mostri, titoli, arti...',
              'Search rules, monsters, titles, arts...',
            ),
            controller: manualSearchController,
            numero: false,
          ),
          const SizedBox(height: 12),
          Text(
            '${t('Risultati', 'Results')}: $resultCount/${activeManualSections.length}',
          ),
        ],
      ),
    );
  }

  Widget rulesOpenedSectionPanelEfficient(ManualSection section) {
    return gothicPanel(
      borderColor: tertiaryColor,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            manualTitle(section),
            style: TextStyle(
              color: tertiaryColor,
              fontSize: 24,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 14),
          SelectableText(
            manualContent(section).trim(),
            style: TextStyle(
              color: Colors.grey.shade100,
              fontSize: 15.5,
              height: 1.50,
            ),
          ),
        ],
      ),
    );
  }

  Widget rulesPage() {
    final filteredIndexes = manualFilteredIndexes();

    if (manualSectionIndex < 0 ||
        manualSectionIndex >= activeManualSections.length) {
      manualSectionIndex = 0;
    }

    final section = activeManualSections[manualSectionIndex];

    return responsivePageList(
      pageKey: 'rules',
      maxColumns: 3,
      minColumnWidth: 320,
      fullWidthIndexes: const <int>{0, 7, 8},
      children: [
        functionAnchor('rules_root', sectionTitle(t('Regole', 'Rules'))),
        manualQuickToolsPanel(),
        appUsageGuideNavigationPanel(),
        gothicPanel(
          borderColor: tertiaryColor,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'MANUALE OCULUM',
                style: TextStyle(
                  color: tertiaryColor,
                  fontSize: 24,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 2.5,
                ),
              ),
              const SizedBox(height: 10),
              smallInfoText(
                t(
                  'Questo manuale è pensato anche per nuovi giocatori. Ogni sezione spiega non solo la regola, ma anche il senso narrativo dietro la regola.',
                  'This manual is also written for new players. Each section explains not only the rule, but also the narrative meaning behind it.',
                ),
              ),
              const SizedBox(height: 12),
              ElevatedButton.icon(
                onPressed: salvaManualePdfAggiornato,
                icon: const Icon(Icons.picture_as_pdf),
                label: Text(t('Salva PDF aggiornato', 'Save updated PDF')),
                style: ElevatedButton.styleFrom(
                  backgroundColor: tertiaryColor,
                  foregroundColor: tertiaryColor.computeLuminance() > 0.45
                      ? Colors.black
                      : Colors.white,
                ),
              ),
            ],
          ),
        ),
        gothicPanel(
          borderColor: primaryColor,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                t('Cerca nel Manuale', 'Search Manual'),
                style: TextStyle(
                  color: primaryColor,
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                ),
              ),
              const SizedBox(height: 12),
              campoTesto(
                label: t(
                  'Cerca regole, mostri, titoli, arti...',
                  'Search rules, monsters, titles, arts...',
                ),
                controller: manualSearchController,
                numero: false,
              ),
              const SizedBox(height: 12),
              Text(
                '${t('Risultati', 'Results')}: ${filteredIndexes.length}/${activeManualSections.length}',
              ),
            ],
          ),
        ),
        sectionTitle(t('Indice', 'Index')),
        gothicPanel(
          borderColor: tertiaryColor,
          child: Column(
            children: [
              if (filteredIndexes.isEmpty)
                Text(t('Nessuna sezione trovata.', 'No section found.'))
              else
                for (final index in filteredIndexes) manualIndexButton(index),
            ],
          ),
        ),
        functionAnchor(
          'rules_open_section',
          sectionTitle(t('Sezione Aperta', 'Opened Section')),
        ),
        gothicPanel(
          borderColor: tertiaryColor,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                manualTitle(section),
                style: TextStyle(
                  color: tertiaryColor,
                  fontSize: 24,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 14),
              SelectableText(
                manualContent(section).trim(),
                style: TextStyle(
                  color: Colors.grey.shade100,
                  fontSize: 15.5,
                  height: 1.50,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  List<Map<String, dynamic>> appUsageGuideDestinations() {
    return <Map<String, dynamic>>[
      {
        'title': t(
          'Immagine scheda / drop Windows',
          'Sheet image / Windows drop',
        ),
        'page': 0,
        'anchorId': 'sheet_image',
        'icon': Icons.image,
      },
      {
        'title': t('Centro comandi scheda', 'Sheet command center'),
        'page': 0,
        'anchorId': 'sheet_command_center',
        'icon': Icons.dashboard_customize,
      },
      {
        'title': t(
          'Nome, tipo, livello e grado',
          'Name, type, level and grade',
        ),
        'page': 0,
        'anchorId': 'sheet_identity',
        'icon': Icons.badge,
      },
      {
        'title': t('Razza e tratti', 'Race and traits'),
        'page': 0,
        'anchorId': 'sheet_race',
        'icon': Icons.diversity_3,
      },
      {
        'title': 'EXP',
        'page': 0,
        'anchorId': 'sheet_exp',
        'icon': Icons.trending_up,
      },
      {
        'title': 'HP / Scudi',
        'page': 0,
        'anchorId': 'sheet_hp',
        'icon': Icons.favorite,
      },
      {
        'title': t('Danno / Cura / Tipo danno', 'Damage / Heal / Damage type'),
        'page': 0,
        'anchorId': 'sheet_damage_heal',
        'icon': Icons.local_fire_department,
      },
      {
        'title': t('Combattimento', 'Combat'),
        'page': 0,
        'anchorId': 'sheet_combat_values',
        'icon': Icons.sports_martial_arts,
      },
      {
        'title': t('Riepilogo rapido', 'Quick summary'),
        'page': 0,
        'anchorId': 'sheet_values',
        'icon': Icons.dashboard,
      },
      {
        'title': t('Statistiche cliccabili', 'Clickable stats'),
        'page': 0,
        'anchorId': 'sheet_stats',
        'icon': Icons.auto_graph,
      },
      {
        'title': t('Valori modificabili', 'Editable values'),
        'page': 0,
        'anchorId': 'sheet_editable_values',
        'icon': Icons.tune,
      },
      {
        'title': t('Party scheda', 'Sheet party'),
        'page': 0,
        'anchorId': 'sheet_party',
        'icon': Icons.groups,
      },
      {
        'title': t('Riposo / stati', 'Rest / conditions'),
        'page': 1,
        'anchorId': 'rest_root',
        'icon': Icons.nightlight_round,
      },
      {
        'title': t('Titoli', 'Titles'),
        'page': 2,
        'anchorId': 'titles_root',
        'icon': Icons.auto_awesome,
      },
      {
        'title': t('Crea Titolo', 'Create Title'),
        'page': 2,
        'anchorId': 'titles_create',
        'icon': Icons.add_circle,
      },
      {
        'title': t('Art', 'Arts'),
        'page': 3,
        'anchorId': 'art_root',
        'icon': Icons.auto_fix_high,
      },
      {
        'title': t('Skill', 'Skills'),
        'page': 4,
        'anchorId': 'skills_root',
        'icon': Icons.blur_circular,
      },
      {
        'title': t('Storia / diario', 'Story / diary'),
        'page': 5,
        'anchorId': 'story_root',
        'icon': Icons.menu_book,
      },
      {
        'title': t('Inventario / armi', 'Inventory / weapons'),
        'page': 6,
        'anchorId': 'inventory_root',
        'icon': Icons.backpack,
      },
      {
        'title': t('Risorse', 'Resources'),
        'page': 7,
        'anchorId': 'resources_root',
        'icon': Icons.diamond,
      },
      {
        'title': t('Master', 'Master'),
        'page': 9,
        'anchorId': 'master_root',
        'icon': Icons.admin_panel_settings,
      },
      {
        'title': t('Impostazioni', 'Settings'),
        'page': _OculumHomePageState.settingsPageIndex,
        'anchorId': 'settings_root',
        'icon': Icons.settings,
      },
      {
        'title': t('Online', 'Online'),
        'page': _OculumHomePageState.onlinePageIndex,
        'anchorId': 'online_root',
        'icon': Icons.public,
      },
    ];
  }

  Widget appUsageGuideNavigationPanel() {
    return dropdownSection(
      title: t('Guida speciale dell’app', 'Special app guide'),
      subtitle: t(
        'Ogni pulsante porta direttamente allo spazio dell’app spiegato dal manuale. Usa questa guida quando non ricordi dove si trova una casella.',
        'Each button jumps directly to the app area explained by the manual. Use this guide when you do not remember where a field is.',
      ),
      icon: Icons.explore,
      borderColor: tertiaryColor,
      initiallyExpanded: false,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          smallInfoText(
            t(
              'Apri la sezione “Guida app: scheda, zone e click” nell’indice per leggere cosa fa ogni zona e cosa succede quando tocchi un riquadro.',
              'Open “App guide: sheet, areas and taps” in the index to read what every area does and what happens when you tap a card.',
            ),
            color: primaryColor,
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final destination in appUsageGuideDestinations())
                ElevatedButton.icon(
                  onPressed: () {
                    vaiAllaFunzione(
                      page: readIntValue(destination['page']),
                      anchorId: '${destination['anchorId'] ?? ''}',
                      logTitle: '${destination['title']}',
                    );
                  },
                  icon: Icon(destination['icon'] as IconData, size: 18),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.black.withValues(alpha: 0.35),
                    foregroundColor: primaryColor,
                    side: BorderSide(
                      color: tertiaryColor.withValues(alpha: 0.55),
                    ),
                  ),
                  label: Text('${destination['title']}'),
                ),
            ],
          ),
        ],
      ),
    );
  }

  // =====================================================
  // IMPOSTAZIONI / COLORE AVANZATO
  // =====================================================
  // =====================================================
  // IMPORT / EXPORT SALVATAGGIO
  // =====================================================

  String creaBackupJson() {
    salvaSchedaCorrenteInMemoria();
    saveActiveCampaignInMemory();

    final data = <String, dynamic>{
      ...datiSalvataggioJson(revision: salvataggioRevisione),
      'oculumBackup': true,
      'versioneBackup': 2,
      'backupCreatedAt': DateTime.now().toIso8601String(),
    };

    return const JsonEncoder.withIndent('  ').convert(data);
  }

  Future<void> esportaBackupNegliAppunti() async {
    final backup = creaBackupJson();

    await Clipboard.setData(ClipboardData(text: backup));
    if (kIsWeb) {
      final now = DateTime.now();
      final stamp =
          '${now.year}${now.month.toString().padLeft(2, '0')}${now.day.toString().padLeft(2, '0')}_${now.hour.toString().padLeft(2, '0')}${now.minute.toString().padLeft(2, '0')}';
      await oculumDownloadBytes(
        bytes: Uint8List.fromList(utf8.encode(backup)),
        fileName: 'oculum_backup_$stamp.json',
        mimeType: 'application/json',
      );
    }

    setState(() {
      risultato = t(
        kIsWeb
            ? 'Backup completo copiato e scaricato in JSON.'
            : 'Backup completo esportato negli appunti. Incollalo in un file di testo per conservarlo.',
        kIsWeb
            ? 'Full backup copied and downloaded as JSON.'
            : 'Full backup exported to clipboard. Paste it into a text file to keep it safe.',
      );

      aggiungiLog('Backup esportato negli appunti.');
    });
  }

  String get sheetShareCodePrefix => oculumSheetShareCodePrefix;

  Map<String, dynamic> schedaPerCodiceCondivisione(int index) {
    if (index < 0 || index >= schedePersonaggio.length) {
      return statoCorrenteJson();
    }

    return Map<String, dynamic>.from(
      jsonDecode(jsonEncode(schedePersonaggio[index])) as Map,
    );
  }

  String creaCodiceSchedeCondivisibili(Iterable<int> rawIndexes) {
    salvaSchedaCorrenteInMemoria();

    final indexes =
        rawIndexes
            .where((index) => index >= 0 && index < schedePersonaggio.length)
            .toSet()
            .toList()
          ..sort();

    if (indexes.isEmpty && schedePersonaggio.isNotEmpty) {
      indexes.add(schedaCorrente.clamp(0, schedePersonaggio.length - 1));
    }

    final payload = <String, dynamic>{
      'kind': 'oculum_sheets',
      'version': 2,
      'createdAt': DateTime.now().toIso8601String(),
      'sheets': indexes.map(schedaPerCodiceCondivisione).toList(),
    };

    final encoded = gzip.encode(utf8.encode(jsonEncode(payload)));
    final compact = base64UrlEncode(encoded).replaceAll('=', '');
    return '$oculumSheetShareCodePrefixV2${oculumShareChecksum(encoded)}:$compact';
  }

  List<Map<String, dynamic>> schedeDaPayloadCodice(dynamic decoded) {
    if (decoded is! Map) {
      throw const FormatException('Payload non valido.');
    }

    final map = Map<String, dynamic>.from(decoded);
    final rawSheets = map['sheets'] ?? map['schedePersonaggio'];

    if (rawSheets is List) {
      return rawSheets
          .whereType<Map>()
          .map((sheet) => Map<String, dynamic>.from(sheet))
          .toList();
    }

    if (map.containsKey('nome') || map.containsKey('tipoScheda')) {
      return [map];
    }

    throw const FormatException('Nessuna scheda trovata.');
  }

  List<Map<String, dynamic>> decodificaCodiciScheda(String rawText) {
    return oculumDecodeSheetShareText(rawText);
  }

  Future<List<Map<String, dynamic>>> decodificaCodiciSchedaAsync(
    String rawText,
  ) async {
    if (kIsWeb || rawText.length < 48 * 1024) {
      return decodificaCodiciScheda(rawText);
    }
    try {
      return await compute(
        oculumDecodeSheetShareText,
        rawText,
        debugLabel: 'oculum-sheet-import-decode',
      );
    } catch (_) {
      return decodificaCodiciScheda(rawText);
    }
  }

  Map<String, dynamic> normalizzaSchedaImportata(Map<String, dynamic> raw) {
    final safeRaw = Map<String, dynamic>.from(
      jsonDecode(jsonEncode(raw)) as Map,
    );
    final nome = '${safeRaw['nome'] ?? 'Scheda importata'}'.trim();
    final tipo = '${safeRaw['tipoScheda'] ?? 'Personaggio'}'.trim();
    final base = statoVuotoPersonaggio(
      nome: nome.isEmpty ? 'Scheda importata' : nome,
      tipo: tipo.isEmpty ? 'Personaggio' : tipo,
      livello: readIntValue(safeRaw['livello']),
      grado: readIntValue(safeRaw['grado']),
    );

    base.addAll(safeRaw);

    const chiaviPrivate = <String>[
      'id',
      'sheetTag',
      'inMasterParty',
      'masterSideOverride',
      'realtimeSharedSheet',
      'realtimeSourceKey',
      'realtimeSourceSheetTag',
      'realtimeOwnerTag',
      'realtimeOwnerName',
      'realtimeCampaignId',
      'realtimeCampaignName',
      'realtimeSharedAt',
      'realtimeReceivedAt',
      'realtimeLocalSheetTag',
      'realtimeDirtyLocal',
      'realtimeDirtyAt',
      'realtimeRestrictedByMaster',
      'realtimeReadOnlyByMaster',
      'publicTokenSide',
      'publicInitiativeBase',
      'publicInitiativeTotal',
      'publicInitiativeRollHidden',
      'realtimeCoMaster',
      'realtimeShareWithFriends',
    ];

    for (final key in chiaviPrivate) {
      base.remove(key);
    }

    base['id'] = '';
    base['sheetTag'] = '';
    base['inMasterParty'] = false;
    base['masterSideOverride'] = '';

    return base;
  }

  Future<void> copiaCodiceSchedaCorrente() async {
    await copiaCodiceSchede({schedaCorrente});
  }

  Future<void> copiaCodiceSchedeSelezionate() async {
    await copiaCodiceSchede(selectedSheetCodeIndexes);
  }

  Future<void> copiaCodiceSchede(Iterable<int> indexes) async {
    final code = creaCodiceSchedeCondivisibili(indexes);
    await Clipboard.setData(ClipboardData(text: code));

    final count = decodificaCodiciScheda(code).length;

    if (!mounted) return;
    setState(() {
      sheetCodeController.text = code;
      risultato = t(
        'Codice copiato negli appunti. Schede incluse: $count.',
        'Code copied to clipboard. Included sheets: $count.',
      );
      aggiungiLog('Codice scheda copiato. Schede: $count.');
    });
  }

  Future<void> incollaCodiceSchedeDagliAppunti() async {
    final data = await Clipboard.getData(Clipboard.kTextPlain);
    if (!mounted) return;

    setState(() {
      sheetCodeController.text = data?.text ?? '';
      risultato = sheetCodeController.text.trim().isEmpty
          ? t('Appunti vuoti.', 'Clipboard is empty.')
          : t(
              'Codice incollato nel riquadro. Premi Importa codice per salvarlo.',
              'Code pasted into the box. Press Import code to save it.',
            );
    });
  }

  Future<void> importaCodiceSchedeIncollato() async {
    try {
      final decodedSheets = await decodificaCodiciSchedaAsync(
        sheetCodeController.text,
      );
      final imported = preparaSchedeImportateUniche(
        decodedSheets.map(normalizzaSchedaImportata),
      );

      if (imported.isEmpty) {
        throw const FormatException('Nessuna scheda trovata.');
      }

      salvaSchedaCorrenteInMemoria();
      final globali = catturaImpostazioniGlobali();
      final startIndex = schedePersonaggio.length;

      setState(() {
        schedePersonaggio.addAll(imported);
        assicuraTagSchede();
        schedaCorrente = startIndex;
        caricaStatoDaJson(schedePersonaggio[schedaCorrente]);
        ripristinaImpostazioniGlobali(globali);
        selectedSheetCodeIndexes
          ..clear()
          ..addAll(
            List<int>.generate(
              imported.length,
              (offset) => startIndex + offset,
            ),
          );
        risultato = t(
          'Codice importato. Nuove schede salvate: ${imported.length}.',
          'Code imported. New saved sheets: ${imported.length}.',
        );
        aggiungiLog(
          'Codice scheda importato. Schede nuove: ${imported.length}.',
        );
      });

      await salvaDati();
    } catch (error) {
      if (!mounted) return;
      setState(() {
        risultato = t(
          'Import fallito: codice scheda non valido o incompleto.',
          'Import failed: invalid or incomplete sheet code.',
        );
        aggiungiLog('Import codice scheda fallito: $error');
      });
    }
  }

  Future<void> importaBackupDaTesto(String testo) async {
    try {
      final pulito = testo.trim();

      if (pulito.isEmpty) {
        setState(() {
          risultato = t(
            'Import fallito: il testo è vuoto.',
            'Import failed: the text is empty.',
          );
        });

        return;
      }

      final decoded = kIsWeb || pulito.length < 48 * 1024
          ? jsonDecode(pulito)
          : await compute(
              oculumDecodeJsonText,
              pulito,
              debugLabel: 'oculum-backup-import-decode',
            );

      if (decoded is! Map<String, dynamic>) {
        throw Exception('Formato backup non valido.');
      }
      if (!mounted) return;

      if (readIntValue(decoded['versioneBackup']) >= 2 &&
          decoded['campaigns'] is List) {
        final mode = await showDialog<String>(
          context: context,
          builder: (dialogContext) => AlertDialog(
            title: Text(t('Importa backup completo', 'Import full backup')),
            content: Text(
              t(
                'Puoi aggiungere solo le schede senza toccare i dati attuali, oppure ripristinare campagne, scene, mappe e impostazioni. Prima del ripristino Oculum conserva comunque i backup recenti.',
                'You can add only the sheets without changing current data, or restore campaigns, scenes, maps and settings. Oculum still preserves recent backups before restoring.',
              ),
            ),
            actions: <Widget>[
              TextButton(
                onPressed: () => Navigator.pop(dialogContext),
                child: Text(t('Annulla', 'Cancel')),
              ),
              OutlinedButton(
                onPressed: () => Navigator.pop(dialogContext, 'sheets'),
                child: Text(t('Aggiungi schede', 'Add sheets')),
              ),
              FilledButton(
                onPressed: () => Navigator.pop(dialogContext, 'full'),
                child: Text(t('Ripristina tutto', 'Restore all')),
              ),
            ],
          ),
        );
        if (!mounted || mode == null) return;
        if (mode == 'full') {
          final restored = await importaBackupCompletoProtetto(decoded);
          if (!mounted) return;
          setState(() {
            risultato = restored
                ? t(
                    'Backup completo ripristinato con protezione.',
                    'Full backup restored with protection.',
                  )
                : t(
                    'Ripristino completo non riuscito: i dati precedenti sono rimasti protetti.',
                    'Full restore failed: previous data remained protected.',
                  );
            aggiungiLog(risultato);
          });
          return;
        }
      }

      List<dynamic> rawSchede;

      if (decoded['multiScheda'] == true &&
          decoded['schedePersonaggio'] is List) {
        rawSchede = decoded['schedePersonaggio'] as List;
      } else {
        rawSchede = [decoded];
      }

      if (rawSchede.isEmpty) {
        throw Exception('Il backup non contiene schede.');
      }

      final nuoveSchede = preparaSchedeImportateUniche(
        rawSchede.whereType<Map>().map(
          (x) => normalizzaSchedaImportata(Map<String, dynamic>.from(x)),
        ),
      );

      if (nuoveSchede.isEmpty) {
        throw Exception('Il backup non contiene schede valide.');
      }

      salvaSchedaCorrenteInMemoria();
      final startIndex = schedePersonaggio.length;

      setState(() {
        schedePersonaggio.addAll(nuoveSchede);
        assicuraTagSchede();
        schedaCorrente = startIndex;

        caricaStatoDaJson(schedePersonaggio[schedaCorrente]);

        datiCaricati = true;

        risultato = t(
          'Backup importato. Nuove schede aggiunte: ${nuoveSchede.length}. Le schede esistenti non sono state sovrascritte.',
          'Backup imported. New sheets added: ${nuoveSchede.length}. Existing sheets were not overwritten.',
        );

        aggiungiLog(
          'Backup importato senza sovrascrivere. Schede nuove: ${nuoveSchede.length}.',
        );
      });

      await salvaDati();
    } catch (e) {
      setState(() {
        risultato = t(
          'Import fallito: il testo non sembra un backup valido di Oculum.',
          'Import failed: the text does not seem to be a valid Oculum backup.',
        );

        aggiungiLog('Import backup fallito: $e');
      });
    }
  }

  void mostraDialogImportBackup() {
    final importController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          backgroundColor: const Color(0xFF10121A),
          title: Text(
            t('Importa Backup', 'Import Backup'),
            style: TextStyle(color: tertiaryColor, fontWeight: FontWeight.bold),
          ),
          content: SizedBox(
            width: double.maxFinite,
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  smallInfoText(
                    t(
                      'Incolla qui il testo JSON esportato da Oculum. Attenzione: l’import sostituirà le schede salvate attuali.',
                      'Paste here the JSON text exported from Oculum. Warning: importing will replace the current saved sheets.',
                    ),
                    color: tertiaryColor,
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: importController,
                    maxLines: 14,
                    style: const TextStyle(color: Colors.white, fontSize: 13),
                    decoration: fieldDecoration(
                      t('Incolla backup JSON', 'Paste JSON backup'),
                    ),
                  ),
                ],
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text(t('Annulla', 'Cancel')),
            ),
            ElevatedButton.icon(
              onPressed: () async {
                final testo = importController.text;
                Navigator.pop(context);
                await importaBackupDaTesto(testo);
              },
              icon: const Icon(Icons.upload_file),
              style: ElevatedButton.styleFrom(
                backgroundColor: tertiaryColor,
                foregroundColor: tertiaryColor.computeLuminance() > 0.45
                    ? Colors.black
                    : Colors.white,
              ),
              label: Text(t('Importa', 'Import')),
            ),
          ],
        );
      },
    ).whenComplete(importController.dispose);
  }

  Color withAdvancedColor({
    required Color base,
    required double luminosita,
    required double saturazione,
    required double opacita,
  }) {
    final hsl = HSLColor.fromColor(base);

    final adjusted = hsl
        .withLightness(luminosita.clamp(0.0, 1.0))
        .withSaturation(saturazione.clamp(0.0, 1.0))
        .toColor();

    return adjusted.withValues(alpha: opacita.clamp(0.12, 1.0));
  }

  Widget colorPreviewSmall(Color color) {
    return Container(
      width: 56,
      height: 32,
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.white.withValues(alpha: 0.65)),
        boxShadow: [
          BoxShadow(
            color: color.withValues(alpha: 0.18),
            blurRadius: 7,
            spreadRadius: 1,
          ),
        ],
      ),
    );
  }

  OculumColorPreset? colorPresetById(String id) {
    for (final preset in colorPresets) {
      if (preset.id == id) return preset;
    }
    return null;
  }

  int colorPresetDisplayRank(String id) {
    switch (id) {
      case 'classic_reliquary':
        return 0;
      case 'classic_rpg':
        return 1;
      case 'classic_low_detail':
        return 2;
    }
    final index = colorPresets.indexWhere((preset) => preset.id == id);
    return index < 0 ? 999999 : 100 + index;
  }

  List<OculumColorPreset> orderedColorPresets({
    bool visibleOnly = false,
    bool unlockedOnly = false,
  }) {
    final presets = [
      for (final preset in colorPresets)
        if ((!visibleOnly || isColorThemeVisibleInPicker(preset)) &&
            (!unlockedOnly || isColorThemeUnlocked(preset.id)))
          preset,
    ];
    presets.sort(
      (a, b) =>
          colorPresetDisplayRank(a.id).compareTo(colorPresetDisplayRank(b.id)),
    );
    return presets;
  }

  List<String> orderedColorPresetIds(Iterable<String> ids) {
    final unique = <String>{};
    final ordered = [
      for (final id in ids)
        if (unique.add(id)) id,
    ];
    ordered.sort(
      (a, b) => colorPresetDisplayRank(a).compareTo(colorPresetDisplayRank(b)),
    );
    return ordered;
  }

  String colorPresetName(OculumColorPreset preset) {
    return t(preset.nameIt, preset.nameEn);
  }

  String colorPresetDescription(OculumColorPreset preset) {
    return t(preset.descriptionIt, preset.descriptionEn);
  }

  bool isColorThemeUnlocked(String id) {
    return id == 'classic_reliquary' ||
        id == 'classic_rpg' ||
        oculumThemeStartsUnlocked(id) ||
        (id == 'hoshy_cosmic_cat' && hoshySecretThemeCondition()) ||
        (id == 'phobia_dark' && phobiaSecretThemeCondition()) ||
        unlockedColorThemeIds.contains(id);
  }

  bool isColorThemeVisibleInPicker(OculumColorPreset preset) {
    if (preset.id == 'hoshy_cosmic_cat' || preset.id == 'phobia_dark') {
      return isColorThemeUnlocked(preset.id);
    }
    return true;
  }

  void markCustomColorPreset() {
    colorPresetSelezionato = 'custom';
  }

  void setColorDecorationPreset(String id) {
    if (id == 'none') {
      colorDecorationPresetId = 'none';
      return;
    }
    final preset = colorPresetById(id);
    if (preset == null || !isColorThemeUnlocked(id)) return;
    colorDecorationPresetId = preset.id;
  }

  void setColorGuiPreset(String id) {
    final clean = id.trim();
    if (isBuiltInGuiModeId(clean)) {
      colorGuiPresetId = clean;
      return;
    }
    final preset = colorPresetById(clean);
    if (preset == null || !isColorThemeUnlocked(clean)) return;
    colorGuiPresetId = preset.id;
  }

  void applicaDecorazioneNessuna() {
    setState(() {
      colorDecorationPresetId = 'none';
      risultato = t(
        'Decorazioni disattivate. La palette attuale resta invariata.',
        'Decorations disabled. Current palette is unchanged.',
      );
      aggiungiLog(risultato);
    });
    programmaSalvataggio();
  }

  void applicaDecorazioneColorPreset(String id) {
    final preset = colorPresetById(id);
    if (preset == null || !isColorThemeUnlocked(id)) return;
    setState(() {
      setColorDecorationPreset(id);
      risultato = t(
        'Decorazioni applicate: ${themeDecorationLabel(id)}. I colori attuali restano invariati.',
        'Decorations applied: ${themeDecorationLabel(id)}. Current colors are unchanged.',
      );
      aggiungiLog(risultato);
    });
    programmaSalvataggio();
  }

  void applicaGuiColorPreset(String id) {
    final clean = id.trim();
    final preset = colorPresetById(clean);
    if (!isBuiltInGuiModeId(clean) &&
        (preset == null || !isColorThemeUnlocked(clean))) {
      return;
    }
    setState(() {
      setColorGuiPreset(clean);
      risultato = t(
        'GUI applicata: ${guiSkinLabel(clean)}. Colori, disegni e tema restano invariati.',
        'GUI applied: ${guiSkinLabel(clean)}. Colors, drawings and theme stay unchanged.',
      );
      aggiungiLog(risultato);
    });
    programmaSalvataggio();
  }

  void applicaSoloColoriPreset(String id) {
    final preset = colorPresetById(id);
    if (preset == null || !isColorThemeUnlocked(id)) return;
    setState(() {
      primaryColor = preset.primary;
      secondaryColor = preset.secondary;
      tertiaryColor = preset.tertiary;
      eyeUtilityColor = preset.utility;
      oculumStatFormulaColor = preset.oculumFormula;
      backgroundTopColor = preset.backgroundTop;
      backgroundMidColor = preset.backgroundMid;
      backgroundBottomColor = preset.backgroundBottom;
      eyePupilGlowColor = preset.eyePupilGlow;
      colorPresetSelezionato = preset.id;
      normalizzaContrastoTemaAttivo();
      risultato = t(
        'Solo colori applicati: ${preset.nameIt}. GUI e decorazioni non cambiano.',
        'Colors only applied: ${preset.nameEn}. GUI and decorations do not change.',
      );
      aggiungiLog(risultato);
    });
    programmaSalvataggio();
  }

  void applicaColorPreset(String id) {
    final preset = colorPresetById(id);
    if (preset == null) return;

    if (!isColorThemeUnlocked(id)) {
      setState(() {
        risultato = id == 'hoshy_cosmic_cat'
            ? t(
                'Tema segreto bloccato: una scheda deve chiamarsi Hoshy.',
                'Secret theme locked: a sheet must be named Hoshy.',
              )
            : id == 'phobia_dark'
            ? t(
                'Tema segreto bloccato: una scheda deve chiamarsi Vergil oppure sbloccalo nel dungeon.',
                'Secret theme locked: a sheet must be named Vergil or unlock it in the dungeon.',
              )
            : t(
                'Tema bloccato: gioca al minigioco Oculum per sbloccarlo.',
                'Locked theme: play the Oculum minigame to unlock it.',
              );
        aggiungiLog(risultato);
      });
      return;
    }

    final keepExplicitGui =
        isBuiltInGuiModeId(colorGuiPresetId) && colorGuiPresetId != 'gui_auto';
    setState(() {
      primaryColor = preset.primary;
      secondaryColor = preset.secondary;
      tertiaryColor = preset.tertiary;
      eyeUtilityColor = preset.utility;
      oculumStatFormulaColor = preset.oculumFormula;
      backgroundTopColor = preset.backgroundTop;
      backgroundMidColor = preset.backgroundMid;
      backgroundBottomColor = preset.backgroundBottom;
      eyePupilGlowColor = preset.eyePupilGlow;
      colorPresetSelezionato = preset.id;
      normalizzaContrastoTemaAttivo();
      colorDecorationPresetId =
          (preset.id == 'classic_reliquary' ||
              preset.id == 'classic_low_detail')
          ? 'none'
          : preset.id;
      if (!keepExplicitGui) {
        colorGuiPresetId = preset.id;
      }
      if (preset.id == 'classic_low_detail') {
        themeDecorationOpacityScale = 0.6;
        themeDecorationGlowScale = 0.45;
        themeDecorationIntensityScale = 0.55;
      } else if (preset.id == 'classic_reliquary') {
        themeDecorationOpacityScale = 1.0;
        themeDecorationGlowScale = 1.0;
        themeDecorationIntensityScale = 1.0;
      }
      risultato = keepExplicitGui
          ? t(
              'Tema applicato: ${preset.nameIt}. Colori e disegni aggiornati; GUI fissa mantenuta: ${guiSkinLabel(colorGuiPresetId)}.',
              'Theme applied: ${preset.nameEn}. Colors and drawings updated; fixed GUI kept: ${guiSkinLabel(colorGuiPresetId)}.',
            )
          : t(
              'Tema applicato: ${preset.nameIt}. Colori, GUI e decorazioni aggiornati.',
              'Theme applied: ${preset.nameEn}. Colors, GUI and decorations updated.',
            );
      aggiungiLog(risultato);
    });

    programmaSalvataggio();
  }

  void unlockColorThemeFromDungeon(String presetId) {
    final preset = colorPresetById(presetId);
    if (preset == null || isColorThemeUnlocked(presetId)) return;

    setState(() {
      unlockedColorThemeIds.add(presetId);
      risultato = t(
        'Tema sbloccato dal minigioco: ${preset.nameIt}.',
        'Theme unlocked from the minigame: ${preset.nameEn}.',
      );
      aggiungiLog(risultato);
    });

    programmaSalvataggio();
  }

  Widget colorPresetSwatches(OculumColorPreset preset, {double size = 18}) {
    final colors = [
      preset.primary,
      preset.secondary,
      preset.tertiary,
      preset.utility,
      preset.oculumFormula,
      preset.backgroundMid,
      preset.eyePupilGlow,
    ];

    return Wrap(
      spacing: 4,
      runSpacing: 4,
      children: [
        for (final color in colors)
          Container(
            width: size,
            height: size,
            decoration: BoxDecoration(
              color: color,
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white24),
            ),
          ),
      ],
    );
  }

  Widget colorPresetDropdownPanel() {
    final selectedPreset = colorPresetById(colorPresetSelezionato);
    final dropdownValue =
        selectedPreset != null && isColorThemeUnlocked(selectedPreset.id)
        ? selectedPreset.id
        : 'custom';
    final screenWidth = MediaQuery.maybeOf(context)?.size.width ?? 420;
    final itemWidth = min(360.0, max(220.0, screenWidth - 86));

    return gothicPanel(
      borderColor: tertiaryColor,
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            t('Disposizione colori', 'Color arrangement'),
            style: TextStyle(
              color: tertiaryColor,
              fontSize: 18,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 8),
          smallInfoText(
            t(
              'Preset intelligenti per testi, occhio, sfondo sfumato e bagliore arancio-rossastro vicino alla pupilla. I temi nuovi si sbloccano giocando al minigioco.',
              'Smart presets for text, eye, gradient background and the orange-red glow near the pupil. New themes unlock by playing the minigame.',
            ),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            initialValue: dropdownValue,
            isExpanded: true,
            dropdownColor: const Color(0xFF11131A),
            decoration: fieldDecoration(t('Tema colore', 'Color theme')),
            items: [
              DropdownMenuItem<String>(
                value: 'custom',
                child: Text(t('Personalizzato', 'Custom')),
              ),
              for (final preset in orderedColorPresets(visibleOnly: true))
                if (isColorThemeVisibleInPicker(preset))
                  DropdownMenuItem<String>(
                    value: preset.id,
                    enabled: isColorThemeUnlocked(preset.id),
                    child: Opacity(
                      opacity: isColorThemeUnlocked(preset.id) ? 1 : 0.45,
                      child: SizedBox(
                        width: itemWidth,
                        child: Row(
                          children: [
                            SizedBox(
                              width: 132,
                              child: colorPresetSwatches(preset, size: 12),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                isColorThemeUnlocked(preset.id)
                                    ? colorPresetName(preset)
                                    : '${colorPresetName(preset)} (${t('bloccato', 'locked')})',
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
            ],
            onChanged: (value) {
              if (value == null) return;
              if (value == 'custom') {
                setState(() {
                  colorPresetSelezionato = 'custom';
                });
                programmaSalvataggio();
                return;
              }
              applicaColorPreset(value);
            },
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final preset in orderedColorPresets(visibleOnly: true))
                if (isColorThemeVisibleInPicker(preset))
                  Tooltip(
                    message:
                        '${colorPresetName(preset)} - ${colorPresetDescription(preset)}',
                    child: ActionChip(
                      avatar: Icon(
                        isColorThemeUnlocked(preset.id)
                            ? Icons.palette
                            : Icons.lock,
                        size: 16,
                        color: isColorThemeUnlocked(preset.id)
                            ? preset.tertiary
                            : Colors.grey,
                      ),
                      backgroundColor: preset.secondary.withValues(alpha: 0.78),
                      side: BorderSide(
                        color: colorPresetSelezionato == preset.id
                            ? preset.tertiary
                            : Colors.white24,
                      ),
                      label: Text(
                        colorPresetName(preset),
                        style: TextStyle(
                          color: isColorThemeUnlocked(preset.id)
                              ? preset.primary
                              : Colors.grey.shade500,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      onPressed: isColorThemeUnlocked(preset.id)
                          ? () => applicaColorPreset(preset.id)
                          : null,
                    ),
                  ),
            ],
          ),
        ],
      ),
    );
  }

  Widget compactColorSlider({
    required String label,
    required double value,
    required double min,
    required double max,
    required int divisions,
    required String shownValue,
    required void Function(double) onChanged,
  }) {
    return Row(
      children: [
        SizedBox(
          width: 92,
          child: Text(
            label,
            style: TextStyle(
              color: primaryColor,
              fontWeight: FontWeight.bold,
              fontSize: 12,
            ),
          ),
        ),
        Expanded(
          child: Slider(
            value: value.clamp(min, max),
            min: min,
            max: max,
            divisions: divisions,
            label: shownValue,
            activeColor: tertiaryColor,
            onChanged: onChanged,
          ),
        ),
        SizedBox(
          width: 48,
          child: Text(
            shownValue,
            textAlign: TextAlign.right,
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12),
          ),
        ),
      ],
    );
  }

  Widget advancedColorPanel({
    required String target,
    required Color currentColor,
    required void Function(Color) onSelected,
  }) {
    int r = (currentColor.r * 255.0).round().clamp(0, 255);
    int g = (currentColor.g * 255.0).round().clamp(0, 255);
    int b = (currentColor.b * 255.0).round().clamp(0, 255);

    double opacity = currentColor.a;
    HSLColor hsl = HSLColor.fromColor(currentColor);
    double lightness = hsl.lightness;
    double saturation = hsl.saturation;

    return StatefulBuilder(
      builder: (context, setLocalState) {
        final rawColor = Color.fromARGB(255, r, g, b);

        final preview = withAdvancedColor(
          base: rawColor,
          luminosita: lightness,
          saturazione: saturation,
          opacita: opacity,
        );

        void applyLive() {
          setState(() {
            markCustomColorPreset();
            onSelected(preview);
            risultato = t(
              'Colore $target aggiornato.',
              '$target color updated.',
            );
            aggiungiLog('Colore $target aggiornato.');
          });
          programmaSalvataggio();
        }

        return gothicPanel(
          borderColor: preview.withValues(alpha: 0.85),
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  colorPreviewSmall(preview),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      t(
                        '$target — RGB, luminosità, saturazione, opacità',
                        '$target — RGB, lightness, saturation, opacity',
                      ),
                      style: TextStyle(
                        color: preview,
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              smallInfoText(
                t(
                  'Riquadro compatto: modifica il colore senza occupare troppo spazio. L’opacità influenza quanto il colore appare trasparente nei punti dove viene applicato.',
                  'Compact panel: edit the color without taking too much space. Opacity affects how transparent the color appears where it is applied.',
                ),
              ),
              const SizedBox(height: 8),
              compactColorSlider(
                label: 'R',
                value: r.toDouble(),
                min: 0,
                max: 255,
                divisions: 255,
                shownValue: '$r',
                onChanged: (value) {
                  setLocalState(() {
                    r = value.round();
                    hsl = HSLColor.fromColor(Color.fromARGB(255, r, g, b));
                  });
                },
              ),
              compactColorSlider(
                label: 'G',
                value: g.toDouble(),
                min: 0,
                max: 255,
                divisions: 255,
                shownValue: '$g',
                onChanged: (value) {
                  setLocalState(() {
                    g = value.round();
                    hsl = HSLColor.fromColor(Color.fromARGB(255, r, g, b));
                  });
                },
              ),
              compactColorSlider(
                label: 'B',
                value: b.toDouble(),
                min: 0,
                max: 255,
                divisions: 255,
                shownValue: '$b',
                onChanged: (value) {
                  setLocalState(() {
                    b = value.round();
                    hsl = HSLColor.fromColor(Color.fromARGB(255, r, g, b));
                  });
                },
              ),
              compactColorSlider(
                label: t('Luminosità', 'Lightness'),
                value: lightness,
                min: 0,
                max: 1,
                divisions: 100,
                shownValue: '${(lightness * 100).round()}%',
                onChanged: (value) {
                  setLocalState(() => lightness = value);
                },
              ),
              compactColorSlider(
                label: t('Saturazione', 'Saturation'),
                value: saturation,
                min: 0,
                max: 1,
                divisions: 100,
                shownValue: '${(saturation * 100).round()}%',
                onChanged: (value) {
                  setLocalState(() => saturation = value);
                },
              ),
              compactColorSlider(
                label: t('Opacità', 'Opacity'),
                value: opacity,
                min: 0.12,
                max: 1,
                divisions: 88,
                shownValue: '${(opacity * 100).round()}%',
                onChanged: (value) {
                  setLocalState(() => opacity = value);
                },
              ),
              const SizedBox(height: 8),
              ElevatedButton.icon(
                onPressed: applyLive,
                icon: const Icon(Icons.palette),
                style: ElevatedButton.styleFrom(
                  backgroundColor: preview,
                  foregroundColor: preview.computeLuminance() > 0.45
                      ? Colors.black
                      : Colors.white,
                  minimumSize: const Size.fromHeight(42),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
                label: Text(t('Applica colore', 'Apply color')),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget colorDropdown({
    required String label,
    required String value,
    required void Function(String) onChanged,
  }) {
    final categorie = categorieColori();

    return DropdownButtonFormField<String>(
      initialValue: categorie.contains(value) ? value : 'Tutti',
      dropdownColor: const Color(0xFF11131A),
      decoration: fieldDecoration(label),
      items: categorie
          .map(
            (categoria) => DropdownMenuItem<String>(
              value: categoria,
              child: Text(categoria),
            ),
          )
          .toList(),
      onChanged: (nuovoValore) {
        if (nuovoValore == null) return;
        setState(() => onChanged(nuovoValore));
        programmaSalvataggio();
      },
    );
  }

  Widget colorPicker({
    required String titolo,
    required Color selectedColor,
    required String filtro,
    required void Function(String) onFiltroChanged,
    required void Function(Color) onSelected,
    required bool editorAperto,
    required VoidCallback onToggleEditor,
  }) {
    final colori = coloriFiltrati(filtro);

    return gothicPanel(
      borderColor: selectedColor.withValues(alpha: 0.85),
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              GestureDetector(
                onTap: onToggleEditor,
                child: Tooltip(
                  message: editorAperto
                      ? t('Chiudi editor RGB', 'Close RGB editor')
                      : t('Apri editor RGB', 'Open RGB editor'),
                  child: Container(
                    width: 56,
                    height: 32,
                    decoration: BoxDecoration(
                      color: selectedColor,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: editorAperto
                            ? tertiaryColor
                            : Colors.white.withValues(alpha: 0.65),
                        width: editorAperto ? 2.2 : 1.1,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: selectedColor.withValues(alpha: 0.22),
                          blurRadius: editorAperto ? 12 : 7,
                          spreadRadius: editorAperto ? 1.5 : 1,
                        ),
                      ],
                    ),
                    child: Icon(
                      editorAperto ? Icons.expand_less : Icons.tune,
                      color: selectedColor.computeLuminance() > 0.45
                          ? Colors.black
                          : Colors.white,
                      size: 18,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  titolo,
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                    color: selectedColor,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          smallInfoText(
            t(
              'Tocca il quadratino colore per aprire o chiudere l’editor RGB avanzato.',
              'Tap the color square to open or close the advanced RGB editor.',
            ),
            color: Colors.grey.shade400,
          ),
          const SizedBox(height: 12),
          colorDropdown(
            label: t('Filtro colore', 'Color filter'),
            value: filtro,
            onChanged: onFiltroChanged,
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 9,
            runSpacing: 9,
            children: colori.map((option) {
              final selected =
                  selectedColor.toARGB32() == option.color.toARGB32();

              return Tooltip(
                message: '${option.name} — ${option.category}',
                child: GestureDetector(
                  onTap: () {
                    setState(() {
                      markCustomColorPreset();
                      onSelected(option.color);
                      aggiungiLog('Colore scelto: ${option.name}.');
                    });
                    programmaSalvataggio();
                  },
                  child: Container(
                    width: 32,
                    height: 32,
                    decoration: BoxDecoration(
                      color: option.color,
                      shape: BoxShape.circle,
                      border: Border.all(
                        color: selected ? Colors.white : Colors.black54,
                        width: selected ? 2.5 : 1.2,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: option.color.withValues(
                            alpha: selected ? 0.30 : 0.14,
                          ),
                          blurRadius: selected ? 8 : 4,
                        ),
                      ],
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  // =====================================================
  // TUTORIAL
  // =====================================================

  OculumStarterChoice sceltaTutorial(
    List<OculumStarterChoice> scelte,
    String id,
  ) => scelte.firstWhere(
    (scelta) => scelta.id == id,
    orElse: () => scelte.first,
  );

  bool _isTutorialMonsterVariant(MonsterBookEntry entry) =>
      RegExp(r'_variante_[a-z]+$').hasMatch(entry.id);

  String _tutorialMonsterBaseId(String id) =>
      id.replaceFirst(RegExp(r'_variante_[a-z]+$'), '');

  List<MonsterBookEntry> _tutorialMonsterForms(String baseId) {
    final cleanBaseId = _tutorialMonsterBaseId(baseId.trim());
    final base = monsterBookEntryById(cleanBaseId);
    if (base == null) return const <MonsterBookEntry>[];
    return <MonsterBookEntry>[
      base,
      ...monsterBookEntries.where(
        (entry) => entry.id.startsWith('${base.id}_variante_'),
      ),
    ];
  }

  int tutorialMonsterVariantChance(String difficulty) => switch (difficulty) {
    'facile' => 10,
    'difficile' => 45,
    'oculum' => 65,
    _ => 25,
  };

  MonsterBookEntry? _resolveTutorialMonsterPreset() {
    if (!tutorialGeneraMostro || tutorialMonsterPresetId.trim().isEmpty) {
      return null;
    }
    final forms = _tutorialMonsterForms(tutorialMonsterPresetId);
    if (forms.isEmpty) return monsterBookEntryById(tutorialMonsterPresetId);
    final requested = tutorialMonsterVariantId.trim();
    if (requested.isNotEmpty) {
      return forms.firstWhere(
        (entry) => entry.id == requested,
        orElse: () => forms.first,
      );
    }
    final variants = forms.skip(1).toList(growable: false);
    if (variants.isEmpty ||
        Random().nextInt(100) >=
            tutorialMonsterVariantChance(tutorialDifficultyId)) {
      return forms.first;
    }
    return variants[Random().nextInt(variants.length)];
  }

  int _tutorialMonsterLevel(MonsterBookEntry monster) =>
      max(0, monster.stats['level'] ?? 0);

  Map<String, int> _tutorialMonsterStats(MonsterBookEntry monster) =>
      oculumMonsterCreationStats(monster, _tutorialMonsterLevel(monster));

  OculumTitle _tutorialMonsterRacialTrait(MonsterBookEntry monster) {
    final choices = <String>[
      '@Difesa+1 ${elementDisplayName(monster.elementId)}',
      '@VC+1',
      '@CM+1',
      '@Danni+1 ${elementDisplayName(monster.elementId)}',
    ];
    // Ogni creatura riceve una manifestazione razziale propria. Il risultato
    // entra nel tratto salvato della scheda, quindi non cambia a ogni rebuild.
    final baseBuff = choices[Random().nextInt(choices.length)];
    // Le statistiche non fondamentali del Bestiario diventano sottotratti
    // reali della scheda generata. La Strega delle Fiale non perde quindi il
    // suo +6 Precisione quando passa dal Book al tutorial.
    final precisionBonus = monster.stats['precisione'] ?? 0;
    final buff = precisionBonus == 0
        ? baseBuff
        : '$baseBuff\n@Precisione${precisionBonus >= 0 ? '+' : ''}$precisionBonus';
    final lower = monster.nameIt.toLowerCase();
    final skill = lower.contains('lupo')
        ? 'Lupo Solitario\nI/Se combatti senza alleati, ottieni +1 a ogni statistica per ogni nemico presente.\nII/+1 aggiuntivo a VC e CM.\nIII/La prima reazione del turno non costa Reazioni.'
        : 'Istinto di ${monster.nameIt}\nI/Una volta per turno ottieni +1 VC oppure +1 CM in una scena coerente con il tuo corpo.\nII/Il bonus diventa +2.\nIII/Dopo averlo usato, una Reazione rapida può seguire l’azione.';
    return OculumTitle(
      nome: monster.nameIt,
      tipo: 'Tratto Razziale Mostro',
      ottenimento: 'Tratto innato dal Monster Book.',
      leggenda: monster.descIt,
      buff: buff,
      puntoCieco: '',
      skill: skill,
      richiede: 'I disponibile dal livello 0; rinnova fino a III.',
      equipaggiato: true,
      chiaveSistema: 'tutorial_monster_trait_${monster.id}',
    );
  }

  CharacterArt _tutorialMonsterArt(MonsterBookEntry monster, int level) =>
      oculumMonsterBookArt(monster);

  int _statPiuBassa(Map<String, int> stats) {
    const ordine = ['resilienza', 'volonta', 'materia'];
    return ordine.map((key) => stats[key] ?? 0).reduce(min);
  }

  void _aggiungiAllaStatPiuBassa(Map<String, int> stats, int punti) {
    const ordine = ['resilienza', 'volonta', 'materia'];
    for (var i = 0; i < punti; i++) {
      final minimo = _statPiuBassa(stats);
      final chiave = ordine.firstWhere((key) => stats[key] == minimo);
      stats[chiave] = (stats[chiave] ?? 0) + 1;
    }
  }

  Widget _tutorialChoiceField({
    required String label,
    required String value,
    required List<OculumStarterChoice> choices,
    required ValueChanged<String> onChanged,
  }) {
    final selected = sceltaTutorial(choices, value);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        DropdownButtonFormField<String>(
          initialValue: selected.id,
          dropdownColor: const Color(0xFF202431),
          decoration: InputDecoration(labelText: label),
          items: choices
              .map(
                (choice) => DropdownMenuItem(
                  value: choice.id,
                  child: Text(choice.nome),
                ),
              )
              .toList(),
          onChanged: (next) => onChanged(next ?? selected.id),
        ),
        const SizedBox(height: 4),
        smallInfoText(selected.descrizione),
      ],
    );
  }

  void applicaSettaggioTutorial() {
    final selectedMonster = _resolveTutorialMonsterPreset();
    // Un preset del Monster Book e' una creatura gia' definita: non gli si
    // applicano razza, background, Art iniziale, difficolta' o bonus umani.
    final isMonsterBookPreset = selectedMonster != null;
    final livello = selectedMonster == null
        ? max(0, leggiNumero(tutorialLevelController))
        : _tutorialMonsterLevel(selectedMonster);
    final gradoRichiesto = max(0, leggiNumero(tutorialGradeController));
    final gradoMassimo = gradoAutomaticoDaLivello(livello, false);
    final grado = tutorialGeneraMostro
        ? gradoMassimo
        : min(gradoRichiesto, gradoMassimo);
    final extraRes = leggiNumero(tutorialExtraResController);
    final extraVol = leggiNumero(tutorialExtraVolController);
    final extraMat = leggiNumero(tutorialExtraMatController);
    final extraOcu = leggiNumero(tutorialExtraOcuController);
    final background = sceltaTutorial(
      oculumStarterBackgrounds,
      tutorialBackgroundId,
    );
    final razza = sceltaTutorial(oculumStarterRaces, tutorialRaceId);
    final fato = sceltaTutorial(oculumStarterFateTitles, tutorialFateId);
    final art = oculumStarterArtChoices().firstWhere(
      (art) => art.nome == tutorialArtName,
      orElse: oculumStarterWaterArt,
    );
    final eMartial = !isMonsterBookPreset && art.tipo == 'Martial Art';
    if (eMartial && tutorialMartialBonus <= 0) {
      tutorialMartialBonus = oculumStarterMartialBonus(Random());
    }
    final puntiLibriDisponibili =
        oculumStarterFreeStatPoints(
          monster: tutorialGeneraMostro,
          level: livello,
          grade: grado,
        ) +
        (eMartial ? tutorialMartialBonus : 0);
    final puntiLivelloSpesi =
        max(0, extraRes) +
        max(0, extraVol) +
        max(0, extraMat) +
        max(0, extraOcu);
    if (!tutorialGeneraMostro && puntiLivelloSpesi > puntiLibriDisponibili) {
      setState(() {
        risultato =
            'Hai distribuito $puntiLivelloSpesi punti, ma il budget disponibile è $puntiLibriDisponibili.';
      });
      return;
    }
    if (gradoRichiesto > gradoMassimo) {
      setState(() {
        tutorialGradeController.text = gradoMassimo.toString();
        risultato =
            'Il livello $livello permette al massimo il Grado $gradoMassimo: il grado richiesto è stato corretto.';
      });
    }
    if (!tutorialGeneraMostro && eMartial && extraOcu > 0) {
      setState(() {
        risultato =
            'I punti bonus di una Martial Art non possono essere messi in Oculum.';
      });
      return;
    }
    final primaria = tutorialStatPrimaria;
    final secondaria = tutorialStatSecondaria == primaria
        ? const [
            'resilienza',
            'volonta',
            'materia',
            'oculum',
          ].firstWhere((stat) => stat != primaria)
        : tutorialStatSecondaria;
    final stats = <String, int>{
      'resilienza':
          extraRes + background.resilienza + razza.resilienza + fato.resilienza,
      'volonta': extraVol + background.volonta + razza.volonta + fato.volonta,
      'materia': extraMat + background.materia + razza.materia + fato.materia,
      'oculum': extraOcu + background.oculum + razza.oculum + fato.oculum,
    };
    if (selectedMonster != null) {
      stats.addAll(_tutorialMonsterStats(selectedMonster));
    }
    if (!tutorialGeneraMostro) {
      for (final stat in const ['resilienza', 'volonta', 'materia', 'oculum']) {
        stats[stat] = (stats[stat] ?? 0) + 1;
      }
      stats[primaria] = (stats[primaria] ?? 0) + 2;
      stats[secondaria] = (stats[secondaria] ?? 0) + 1;
    }
    if (!isMonsterBookPreset && eMartial) {
      _aggiungiAllaStatPiuBassa(stats, max(0, stats['oculum'] ?? 0));
      stats['oculum'] = 0;
    }
    if (!isMonsterBookPreset && tutorialDifficultyId == 'facile') {
      _aggiungiAllaStatPiuBassa(stats, 1);
    } else if (!isMonsterBookPreset &&
        (tutorialDifficultyId == 'difficile' ||
            tutorialDifficultyId == 'oculum')) {
      final chiave = [
        'resilienza',
        'volonta',
        'materia',
        'oculum',
      ].reduce((a, b) => (stats[a] ?? 0) >= (stats[b] ?? 0) ? a : b);
      final malus = tutorialDifficultyId == 'oculum' ? 2 : 1;
      stats[chiave] = max(0, (stats[chiave] ?? 0) - malus);
    }
    if (tutorialGeneraMostro) {
      final personalArts = arti.where(
        (candidate) =>
            oculumArtHasUsableSkills(candidate) &&
            candidate.tipo != 'Art Mostro' &&
            !oculumStarterArtChoices().any(
              (starter) => starter.nome == candidate.nome,
            ),
      );
      stats.addAll(
        selectedMonster != null
            ? _tutorialMonsterStats(selectedMonster)
            : oculumDistributeMonsterStats(
                max(
                  3,
                  oculumGeneratedMonsterBudget(tutorialMonsterTier, livello),
                ),
                hasSkills: skills.isNotEmpty || personalArts.isNotEmpty,
                hasOculumArt: personalArts.any(
                  (candidate) => candidate.tipo == 'Oculum Art',
                ),
                role: tutorialMonsterTier,
              ),
      );
    }
    final obserIniziale = switch (background.id) {
      'povero_citta' => Random().nextInt(4) + 1,
      'benestante' => Random().nextInt(50) + 21,
      _ => background.obser,
    };
    final expIniziale = oculumStarterInitialExperience(Random());
    final difficoltaLabel = switch (tutorialDifficultyId) {
      'facile' => 'Facile: +1 alla statistica fondamentale più bassa.',
      'difficile' => 'Difficile: -1 alla statistica fondamentale più alta.',
      'oculum' => 'Oculum: -2 alla statistica fondamentale più alta.',
      _ => 'Normale: nessuna modifica aggiuntiva.',
    };

    setState(() {
      livelloController.text = livello.toString();
      expController.text = expIniziale.toString();
      resilienzaController.text = (stats['resilienza'] ?? 0).toString();
      volontaController.text = (stats['volonta'] ?? 0).toString();
      materiaController.text = (stats['materia'] ?? 0).toString();
      oculumController.text = (stats['oculum'] ?? 0).toString();
      currentResilienzaController.text = resilienzaController.text;
      currentVolontaController.text = volontaController.text;
      currentMateriaController.text = materiaController.text;
      applyTemporaryOculumState(
        TemporaryOculumState(
          normalCurrent: readIntValue(oculumController.text),
          temporary: 0,
          rollsRemaining: 0,
        ),
      );

      aggiornaGradoAutomatico();
      refullaHp();

      titoli.removeWhere(
        (titolo) => titolo.chiaveSistema.startsWith('tutorial_'),
      );
      trattiRazziali.removeWhere(
        (tratto) => tratto.chiaveSistema.startsWith('tutorial_'),
      );
      arti.removeWhere(
        (esistente) => oculumStarterArtChoices().any(
          (starter) => starter.nome == esistente.nome,
        ),
      );
      // Cambiare preset nel tutorial sostituisce solo la precedente Art
      // generata dal Monster Book: nessuna Art personale o legacy viene
      // eliminata, ma la nuova creatura non accumula peculiarita' duplicate.
      arti.removeWhere(
        (esistente) =>
            esistente.tipo == 'Art Mostro' &&
            esistente.descrizione.startsWith('Peculiarità del Monster Book'),
      );
      // Gli equipaggiamenti dati dal Book al mostro sono marcati: riapplicare
      // il tutorial li sostituisce senza toccare l'inventario normale del player.
      inventario.removeWhere(
        (item) => item.note.contains('[Inventario tutorial mostro]'),
      );
      if (selectedMonster != null) {
        for (final rawItem in selectedMonster.inventoryItems) {
          final data = Map<String, dynamic>.from(rawItem);
          data['note'] = '${data['note'] ?? ''} [Inventario tutorial mostro]';
          inventario.add(InventoryItem.fromJson(data));
        }
      }
      if (!tutorialGeneraMostro) {
        titoli.add(
          OculumTitle(
            nome: background.nome,
            tipo: 'Titolo d’Azione',
            ottenimento: 'Scelto durante la creazione guidata.',
            leggenda: background.descrizione,
            buff: background.descrizione,
            puntoCieco: background.puntoCieco,
            skill: 'Il tuo passato influenza le azioni e le scene sociali.',
            richiede: background.conMaster
                ? 'Da completare con il Master.'
                : difficoltaLabel,
            equipaggiato: true,
            sempreVisibile: true,
            chiaveSistema: 'tutorial_background_${background.id}',
          ),
        );
        titoli.add(
          OculumTitle(
            nome: fato.nome,
            tipo: 'Titolo del Fato',
            ottenimento: 'Scelto durante la creazione guidata.',
            leggenda: fato.descrizione,
            buff: fato.descrizione,
            puntoCieco: '',
            skill: 'Segui il tuo Fato per far evolvere il Titolo.',
            richiede: fato.conMaster
                ? 'Da completare con il Master.'
                : difficoltaLabel,
            chiaveSistema: 'tutorial_fate_${fato.id}',
          ),
        );
        trattiRazziali.add(
          OculumTitle(
            nome: razza.nome,
            tipo: 'Tratto Razziale',
            ottenimento: 'Scelto durante la creazione guidata.',
            leggenda: razza.descrizione,
            buff:
                '${razza.descrizione}'
                '${razza.id == 'hideniano' ? '\n@Difesa+2 Fuoco\n@Danni+3 Fuoco' : ''}',
            puntoCieco: razza.id == 'hideniano'
                ? '@DanniSubiti+100% Acqua Magica\n${razza.puntoCieco}'
                : razza.puntoCieco,
            skill: 'Tratto innato della razza.',
            richiede: razza.conMaster
                ? 'Da completare con il Master.'
                : difficoltaLabel,
            equipaggiato: true,
            chiaveSistema: 'tutorial_race_${razza.id}',
          ),
        );
        razzaController.text = razza.nome;
      } else if (selectedMonster != null) {
        trattiRazziali.add(_tutorialMonsterRacialTrait(selectedMonster));
        final monsterArt = oculumCompleteMonsterOpen(
          _tutorialMonsterArt(selectedMonster, livello),
          name: selectedMonster.nameIt,
          level: livello,
          grade: grado,
        );
        // Il Book usa la Prima Art già presente nella scheda: non aggiunge una
        // quarta sezione. Una Prima Art personalizzata resta intatta e la
        // peculiarità viene inserita davanti, così la nuova creatura continua
        // ad avere la sua Art leggibile nella prima sezione.
        final firstBaseIndex = arti.indexWhere(
          (candidate) =>
              candidate.nome == 'Prima Art' &&
              candidate.tipo == 'Oculum Art' &&
              candidate.descrizione ==
                  'La prima manifestazione del potere personale.',
        );
        if (selectedMonster.skillIds.isNotEmpty) {
          if (firstBaseIndex >= 0) {
            arti[firstBaseIndex] = monsterArt;
          } else {
            arti.insert(0, monsterArt);
          }
        }
        razzaController.clear();
        backgroundController.text =
            'Creatura del Monster Book: richiede approvazione del Master prima di entrare nella campagna.';
      } else {
        razzaController.clear();
        backgroundController.text =
            'Mostro creato liberamente: il Master definisce origine e comportamento.';
      }
      tipoSchedaController.text = tutorialGeneraMostro
          ? (selectedMonster?.presetType ?? tutorialMonsterTier)
          : 'Personaggio';
      if (selectedMonster != null) {
        nomeController.text = selectedMonster.nameIt;
        notePersonaggioController.text = selectedMonster.descIt;
        schedePersonaggio[schedaCorrente]['monsterBookSourceId'] =
            selectedMonster.id;
        schedePersonaggio[schedaCorrente]['monsterBookApprovalRequired'] = true;
        schedePersonaggio[schedaCorrente]['monsterBookApproved'] =
            isMasterHost || modalitaMaster;
      } else if (tutorialGeneraMostro) {
        schedePersonaggio[schedaCorrente].remove('monsterBookSourceId');
        schedePersonaggio[schedaCorrente].remove('monsterBookApprovalRequired');
        schedePersonaggio[schedaCorrente].remove('monsterBookApproved');
      }
      gradoController.text = grado.toString();
      if (!tutorialGeneraMostro) {
        backgroundController.text =
            '${background.nome}\n${background.descrizione}\n\n$difficoltaLabel';
        obserController.text = (leggiNumero(obserController) + obserIniziale)
            .toString();
        arti.add(art);
      }
      monsterStatPoints = 0;
      refullaHp();

      tutorialCompletato = true;

      risultato = tutorialGeneraMostro
          ? 'Tutorial mostro applicato: ${selectedMonster?.nameIt ?? 'creatura libera'}, livello $livello. Grado $grado calcolato dal livello. Statistiche assegnate in base alle Skill e alle Art.'
          : t(
              'Tutorial applicato: ${background.nome}, ${razza.nome}, ${art.nome}. EXP iniziale: $expIniziale.',
              'Tutorial applied: ${background.nome}, ${razza.nome}, ${art.nome}. Starting EXP: $expIniziale.',
            );

      aggiungiLog(risultato);
    });

    programmaSalvataggio();
  }

  void mostraTutorial() {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          backgroundColor: const Color(0xFF0B0E16),
          elevation: 24,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(24),
            side: BorderSide(color: tertiaryColor.withValues(alpha: 0.72)),
          ),
          title: Row(
            children: [
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: tertiaryColor.withValues(alpha: 0.16),
                  border: Border.all(color: tertiaryColor, width: 1.5),
                  boxShadow: [
                    BoxShadow(
                      color: tertiaryColor.withValues(alpha: 0.22),
                      blurRadius: 18,
                    ),
                  ],
                ),
                child: Icon(Icons.visibility, color: tertiaryColor),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Rito di Creazione',
                      style: TextStyle(
                        color: tertiaryColor,
                        fontWeight: FontWeight.w900,
                        fontSize: 20,
                      ),
                    ),
                    Text(
                      'O C U L U M  •  quattro sigilli',
                      style: TextStyle(
                        color: primaryColor.withValues(alpha: 0.85),
                        fontSize: 11,
                        letterSpacing: 1.2,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          content: SizedBox(
            width: double.maxFinite,
            child: SingleChildScrollView(
              child: StatefulBuilder(
                builder: (context, setDialogState) => Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(13),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            primaryColor.withValues(alpha: 0.18),
                            tertiaryColor.withValues(alpha: 0.08),
                          ],
                        ),
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                          color: primaryColor.withValues(alpha: 0.35),
                        ),
                      ),
                      child: const Text(
                        'Scegli il tuo cammino. Ogni sigillo modifica la scheda reale, ma resterà sempre modificabile dopo la creazione.',
                        style: TextStyle(color: Colors.white70, height: 1.25),
                      ),
                    ),
                    const SizedBox(height: 18),
                    Text(
                      t('1. Difficoltà', '1. Difficulty'),
                      style: TextStyle(
                        color: primaryColor,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    smallInfoText(
                      'La difficoltà modifica automaticamente la scheda finale: Facile +1 alla statistica più bassa; Difficile -1 alla più alta; Oculum -2 alla più alta.',
                    ),
                    const SizedBox(height: 12),
                    DropdownButtonFormField<String>(
                      initialValue: tutorialDifficultyId,
                      dropdownColor: const Color(0xFF202431),
                      decoration: const InputDecoration(
                        labelText: 'Difficoltà',
                      ),
                      items: const [
                        DropdownMenuItem(
                          value: 'facile',
                          child: Text('Facile'),
                        ),
                        DropdownMenuItem(
                          value: 'normale',
                          child: Text('Normale'),
                        ),
                        DropdownMenuItem(
                          value: 'difficile',
                          child: Text('Difficile'),
                        ),
                        DropdownMenuItem(
                          value: 'oculum',
                          child: Text('Oculum'),
                        ),
                      ],
                      onChanged: (value) => setDialogState(
                        () => tutorialDifficultyId = value ?? 'normale',
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      '2. Personaggio',
                      style: TextStyle(
                        color: primaryColor,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SwitchListTile(
                      contentPadding: EdgeInsets.zero,
                      value: tutorialGeneraMostro,
                      title: const Text('Genera come Mostro'),
                      subtitle: const Text(
                        'Crea una scheda Mostro; Titoli, razza e Art restano modificabili.',
                      ),
                      onChanged: (value) =>
                          setDialogState(() => tutorialGeneraMostro = value),
                    ),
                    if (!tutorialGeneraMostro) ...[
                      smallInfoText(
                        'Umanoide: 3 punti alla primaria, 2 alla secondaria, +1 alle altre due. Scegli qui dove vanno i 3 e i 2.',
                      ),
                      const SizedBox(height: 8),
                      DropdownButtonFormField<String>(
                        initialValue: tutorialStatPrimaria,
                        isExpanded: true,
                        dropdownColor: const Color(0xFF202431),
                        decoration: const InputDecoration(
                          labelText: 'Statistica primaria — 3 punti',
                        ),
                        items: const [
                          DropdownMenuItem(
                            value: 'resilienza',
                            child: Text('RES — HP e tenuta'),
                          ),
                          DropdownMenuItem(
                            value: 'volonta',
                            child: Text('VOL — danni, difesa, VC e peso'),
                          ),
                          DropdownMenuItem(
                            value: 'materia',
                            child: Text('MAT — CM e Difesa'),
                          ),
                          DropdownMenuItem(
                            value: 'oculum',
                            child: Text(
                              'OCU — Art, cerchi, rituali e poteri oculari',
                            ),
                          ),
                        ],
                        onChanged: (value) => setDialogState(
                          () => tutorialStatPrimaria = value ?? 'resilienza',
                        ),
                      ),
                      const SizedBox(height: 8),
                      DropdownButtonFormField<String>(
                        initialValue: tutorialStatSecondaria,
                        isExpanded: true,
                        dropdownColor: const Color(0xFF202431),
                        decoration: const InputDecoration(
                          labelText: 'Statistica secondaria — 2 punti',
                        ),
                        items: const [
                          DropdownMenuItem(
                            value: 'resilienza',
                            child: Text('RES — HP e tenuta'),
                          ),
                          DropdownMenuItem(
                            value: 'volonta',
                            child: Text('VOL — danni, difesa, VC e peso'),
                          ),
                          DropdownMenuItem(
                            value: 'materia',
                            child: Text('MAT — CM e Difesa'),
                          ),
                          DropdownMenuItem(
                            value: 'oculum',
                            child: Text(
                              'OCU — Art, cerchi, rituali e poteri oculari',
                            ),
                          ),
                        ],
                        onChanged: (value) => setDialogState(
                          () => tutorialStatSecondaria = value ?? 'volonta',
                        ),
                      ),
                    ] else
                      Column(
                        children: [
                          DropdownButtonFormField<String>(
                            initialValue: tutorialMonsterTier,
                            decoration: const InputDecoration(
                              labelText: 'Tipo di creatura',
                            ),
                            items: const [
                              DropdownMenuItem(
                                value: 'Mostro',
                                child: Text('Mostro'),
                              ),
                              DropdownMenuItem(
                                value: 'Mostro Mini Boss',
                                child: Text('Mini Boss'),
                              ),
                              DropdownMenuItem(
                                value: 'Mostro Boss',
                                child: Text('Boss'),
                              ),
                            ],
                            onChanged: (value) => setDialogState(() {
                              tutorialMonsterTier = value ?? 'Mostro';
                              tutorialMonsterPresetId = '';
                              tutorialMonsterVariantId = '';
                              tutorialMonsterStatsRandomized = false;
                            }),
                          ),
                          const SizedBox(height: 8),
                          DropdownButtonFormField<String>(
                            initialValue: tutorialMonsterPresetId.isEmpty
                                ? null
                                : tutorialMonsterPresetId,
                            decoration: const InputDecoration(
                              labelText:
                                  'Occhio: scegli dal Monster Book (oppure crea tu)',
                            ),
                            items: [
                              for (final entry in monsterBookEntries.where(
                                (entry) =>
                                    entry.presetType == tutorialMonsterTier &&
                                    !_isTutorialMonsterVariant(entry),
                              ))
                                DropdownMenuItem(
                                  value: entry.id,
                                  child: Text(entry.nameIt),
                                ),
                            ],
                            onChanged: (value) => setDialogState(() {
                              tutorialMonsterPresetId = value ?? '';
                              tutorialMonsterVariantId = '';
                              tutorialMonsterStatsRandomized = false;
                            }),
                          ),
                          if (tutorialMonsterPresetId.isNotEmpty)
                            Builder(
                              builder: (context) {
                                final forms = _tutorialMonsterForms(
                                  tutorialMonsterPresetId,
                                );
                                if (forms.length <= 1) {
                                  return const SizedBox.shrink();
                                }
                                final chosen =
                                    forms.any(
                                      (entry) =>
                                          entry.id == tutorialMonsterVariantId,
                                    )
                                    ? tutorialMonsterVariantId
                                    : null;
                                final chance = tutorialMonsterVariantChance(
                                  tutorialDifficultyId,
                                );
                                return Column(
                                  children: [
                                    const SizedBox(height: 8),
                                    DropdownButtonFormField<String>(
                                      initialValue: chosen ?? '',
                                      decoration: const InputDecoration(
                                        labelText:
                                            'Forma del mostro — casuale o scelta',
                                      ),
                                      items: [
                                        DropdownMenuItem(
                                          value: '',
                                          child: Text(
                                            'Casuale — variante $chance%',
                                          ),
                                        ),
                                        for (final form in forms)
                                          DropdownMenuItem(
                                            value: form.id,
                                            child: Text(
                                              form.id == forms.first.id
                                                  ? '${form.nameIt} — forma base'
                                                  : form.nameIt,
                                            ),
                                          ),
                                      ],
                                      onChanged: (value) => setDialogState(() {
                                        tutorialMonsterVariantId = value ?? '';
                                      }),
                                    ),
                                    const SizedBox(height: 5),
                                    smallInfoText(
                                      'Casuale: Facile 10%, Normale 25%, Difficile 45%, Oculum 65%. La forma viene estratta una sola volta quando crei la scheda.',
                                    ),
                                  ],
                                );
                              },
                            ),
                          const SizedBox(height: 6),
                          smallInfoText(
                            'Se non scegli un Occhio, crei liberamente la creatura; altrimenti usa statistiche, descrizione e tipo del Mostro scelto.',
                          ),
                          if (tutorialMonsterPresetId.isEmpty) ...[
                            const SizedBox(height: 8),
                            OutlinedButton.icon(
                              onPressed: () {
                                final budget = quickMonsterStatBudget(
                                  tutorialMonsterTier,
                                  max(0, leggiNumero(tutorialLevelController)),
                                  max(0, leggiNumero(tutorialGradeController)),
                                );
                                final stats = randomQuickMonsterStats(
                                  budget,
                                  hint: tutorialMonsterTier,
                                  hasSkills:
                                      skills.isNotEmpty ||
                                      arti.any(oculumArtHasUsableSkills),
                                );
                                setDialogState(() {
                                  tutorialExtraResController.text =
                                      '${stats['resilienza'] ?? 0}';
                                  tutorialExtraVolController.text =
                                      '${stats['volonta'] ?? 0}';
                                  tutorialExtraMatController.text =
                                      '${stats['materia'] ?? 0}';
                                  tutorialExtraOcuController.text =
                                      '${stats['oculum'] ?? 0}';
                                  tutorialMonsterStatsRandomized = true;
                                });
                              },
                              icon: const Icon(Icons.casino_outlined),
                              label: const Text('Randomizza punti mostro'),
                            ),
                          ],
                        ],
                      ),
                    campoTesto(
                      label: t('Livello iniziale', 'Starting level'),
                      controller: tutorialLevelController,
                    ),
                    const SizedBox(height: 4),
                    if (!tutorialGeneraMostro)
                      campoTesto(
                        label: t('Grado iniziale', 'Starting grade'),
                        controller: tutorialGradeController,
                      )
                    else
                      ValueListenableBuilder<TextEditingValue>(
                        valueListenable: tutorialLevelController,
                        builder: (context, value, _) => smallInfoText(
                          'Grado automatico: ${oculumGradeForLevel(max(0, int.tryParse(value.text) ?? 0))}. Per le forme del Book si usa il loro livello.',
                        ),
                      ),
                    const SizedBox(height: 4),
                    smallInfoText(
                      tutorialGeneraMostro
                          ? 'Grado dal livello: +10 punti per Mostro, +15 per Mini-Boss, +25 per Boss a ogni Grado. Le Skill e le Oculum Art ricevono una riserva di Oculum; senza entrambe i punti vanno a RES, VOL e MAT. L’EXP iniziale viene estratta casualmente tra 0 e 120.'
                          : 'Umanoide: distribuzione iniziale 3/2/1/1, poi +1 punto libero per livello e +10 per grado. L’EXP iniziale viene estratta casualmente tra 0 e 120.',
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: campoTesto(
                            label: 'RES — HP e tenuta',
                            controller: tutorialExtraResController,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: campoTesto(
                            label: 'VOL — danni, difesa, VC e peso',
                            controller: tutorialExtraVolController,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: campoTesto(
                            label: 'MAT — CM e Difesa',
                            controller: tutorialExtraMatController,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: campoTesto(
                            label:
                                'OCU — Art, cerchi, rituali e poteri oculari',
                            controller: tutorialExtraOcuController,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    smallInfoText(
                      'Senza un’Oculum Art non possiedi Oculum: con una Martial Art ogni punto OCU viene trasferito automaticamente alla statistica fondamentale più bassa.',
                    ),
                    const SizedBox(height: 16),
                    Text(
                      '3. Origine e Fato',
                      style: TextStyle(
                        color: primaryColor,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    _tutorialChoiceField(
                      label:
                          'Background — diventa il tuo Titolo d’Azione visibile',
                      value: tutorialBackgroundId,
                      choices: oculumStarterBackgrounds,
                      onChanged: (value) =>
                          setDialogState(() => tutorialBackgroundId = value),
                    ),
                    const SizedBox(height: 8),
                    _tutorialChoiceField(
                      label: 'Razza',
                      value: tutorialRaceId,
                      choices: oculumStarterRaces,
                      onChanged: (value) =>
                          setDialogState(() => tutorialRaceId = value),
                    ),
                    const SizedBox(height: 8),
                    _tutorialChoiceField(
                      label: 'Titolo del Fato — perché sei qui?',
                      value: tutorialFateId,
                      choices: oculumStarterFateTitles,
                      onChanged: (value) =>
                          setDialogState(() => tutorialFateId = value),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      '4. Art iniziale',
                      style: TextStyle(
                        color: primaryColor,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    DropdownButtonFormField<String>(
                      initialValue: tutorialArtName,
                      isExpanded: true,
                      dropdownColor: const Color(0xFF202431),
                      decoration: const InputDecoration(
                        labelText: 'Scegli un’Art — ogni Art ha 3 Skill',
                      ),
                      items: oculumStarterArtChoices()
                          .map(
                            (art) => DropdownMenuItem(
                              value: art.nome,
                              child: Text('${art.nome} (${art.tipo})'),
                            ),
                          )
                          .toList(),
                      onChanged: (value) => setDialogState(() {
                        tutorialArtName = value ?? tutorialArtName;
                        final selected = oculumStarterArtChoices().firstWhere(
                          (art) => art.nome == tutorialArtName,
                        );
                        tutorialMartialBonus = selected.tipo == 'Martial Art'
                            ? oculumStarterMartialBonus(Random())
                            : 0;
                      }),
                    ),
                    const SizedBox(height: 8),
                    smallInfoText(
                      tutorialArtName == 'Zanna del Drago' ||
                              tutorialArtName == 'Berserk'
                          ? 'Martial Art: bonus estratto 1d10+2 = $tutorialMartialBonus punti liberi. Puoi metterli in RES, VOL o MAT: OCU resta 0.'
                          : 'Con un’Oculum Art puoi investire normalmente anche in OCU.',
                    ),
                    const SizedBox(height: 14),
                    Text(
                      t('Regole fondamentali', 'Core rules'),
                      style: TextStyle(
                        color: tertiaryColor,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      t(
                        '• Resilienza aumenta gli HP massimi.\n'
                            '• Volontà aumenta danno, difesa, VC e peso trasportabile.\n'
                            '• Materia aumenta CM e Difesa.\n'
                            '• Oculum potenzia Arti, cerchi, rituali e poteri oculari.\n'
                            '• Lo Scudo Critico dimezza i danni finché non viene spezzato da un critico in fight.\n'
                            '• I Titoli del Fato si ottengono dalle Skill delle Art: prima Skill livello 1, seconda Skill livello 2, terza Skill livello 3.\n'
                            '• Le pagine diario possono dare Ispirazioni.\n'
                            '• I Gradi vengono controllati automaticamente in base al livello e al Rebirth.',
                        '• Resilience increases max HP.\n'
                            '• Will increases damage, defense, VC and carrying weight.\n'
                            '• Materia increases CM and Defense.\n'
                            '• Oculum empowers Arts, circles, rituals and eye powers.\n'
                            '• Critical Shield halves damage until broken by a critical during combat.\n'
                            '• Fate Titles are gained from Art Skills: first Skill level 1, second Skill level 2, third Skill level 3.\n'
                            '• Diary pages can grant Inspirations.\n'
                            '• Grades are checked automatically based on level and Rebirth.',
                      ),
                      style: const TextStyle(color: Colors.white),
                    ),
                    const SizedBox(height: 14),
                    Text(
                      t('Funzioni principali', 'Main features'),
                      style: TextStyle(
                        color: primaryColor,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      t(
                        'Scheda: HP, danni, cura, tiri, stats, livello e grado.\n'
                            'Riposo: bisogni, cenere, recuperi e attività pesanti.\n'
                            'Titoli: buff, karma, Open e punti ciechi.\n'
                            'Art: nome, tipo e descrizione delle Art.\n'
                            'Skill: skill scritte e creazione skill.\n'
                            'Storia: background e diario.\n'
                            'Risorse: Obser, polveri e Ispirazioni.\n'
                            'Impostazioni: colori avanzati, log, lingua e tutorial.',
                        'Sheet: HP, damage, healing, rolls, stats, level and grade.\n'
                            'Rest: needs, ash, recovery and heavy activities.\n'
                            'Titles: buffs, Karma, Opens and blind spots.\n'
                            'Arts: Art name, type and description.\n'
                            'Skills: written skills and skill creation.\n'
                            'Story: background and diary.\n'
                            'Resources: Obser, powders and Inspirations.\n'
                            'Settings: advanced colors, log, language and tutorial.',
                      ),
                      style: const TextStyle(color: Colors.white),
                    ),
                  ],
                ),
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                setState(() {
                  tutorialCompletato = true;
                  aggiungiLog('Tutorial skippato/completato.');
                });
                programmaSalvataggio();
                Navigator.pop(context);
              },
              child: Text(t('Skippa', 'Skip')),
            ),
            ElevatedButton(
              onPressed: () {
                applicaSettaggioTutorial();
                Navigator.pop(context);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: tertiaryColor,
                foregroundColor: tertiaryColor.computeLuminance() > 0.45
                    ? Colors.black
                    : Colors.white,
              ),
              child: Text(t('Applica e inizia', 'Apply and start')),
            ),
          ],
        );
      },
    ).whenComplete(() {
      tutorialDialogPending = false;
    });
  }

  void mostraTutorialSeNecessario() {
    if (tutorialCompletato || tutorialDialogPending) return;

    tutorialDialogPending = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      mostraTutorial();
    });
  }

  // =====================================================
  // CERCA
  // =====================================================

  List<Map<String, dynamic>> searchResults(String query) {
    final q = query.trim().toLowerCase();
    if (q.isEmpty) return [];

    final results = <Map<String, dynamic>>[];
    final labels = linguaInglese ? pageNamesEn : pageNamesIt;

    for (int i = 0; i < labels.length; i++) {
      if (oculumSearchScore(q, labels[i]) > 0) {
        results.add({
          'title': labels[i],
          'subtitle': t('Pagina app', 'App page'),
          'page': i,
        });
      }
    }

    final funzioni = <Map<String, dynamic>>[
      {
        'key': 'danno damage subito ferita subisci colpo',
        'title': t('Danno', 'Damage'),
        'page': 0,
        'anchorId': 'sheet_damage',
      },
      {
        'key': 'cura heal guarigione recupero vita guarire',
        'title': t('Cura', 'Healing'),
        'page': 0,
        'anchorId': 'sheet_heal',
      },
      {
        'key':
            'danno cura damage heal gestione vita hp scudo critico resistenza fragilita fragilità',
        'title': t('Danno / Cura', 'Damage / Healing'),
        'page': 0,
        'anchorId': 'sheet_damage_heal',
      },
      {
        'key': 'hp vita salute punti ferita current hp temp scudo',
        'title': 'HP',
        'page': 0,
        'anchorId': 'sheet_hp',
      },
      {
        'key': 'vc valore combattimento tiro combattimento',
        'title': 'VC',
        'page': 0,
        'anchorId': 'sheet_combat_values',
      },
      {
        'key': 'cm classe mentale mente tiro mentale',
        'title': 'CM',
        'page': 0,
        'anchorId': 'sheet_combat_values',
      },
      {
        'key': 'difesa defense protezione',
        'title': t('Difesa', 'Defense'),
        'page': 0,
        'anchorId': 'sheet_combat_values',
      },
      {
        'key': 'danni danno totale damage bonus arma',
        'title': t('Danni', 'Damage'),
        'page': 0,
        'anchorId': 'sheet_combat_values',
      },
      {
        'key': 'level up grado rebirth exp esperienza livello',
        'title': t('Level up / Esperienza', 'Level up / Experience'),
        'page': 0,
        'anchorId': 'sheet_exp',
      },
      {
        'key': 'riposo cenere mangia bevi sonno bisogni stati',
        'title': t('Riposo', 'Rest'),
        'page': 1,
        'anchorId': 'rest_root',
      },
      {
        'key': 'titoli open fato karma punto cieco',
        'title': t('Titoli', 'Titles'),
        'page': 2,
        'anchorId': 'titles_root',
      },
      {
        'key': 'aggiungi titolo crea nuovo title add create',
        'title': t('Aggiungi Titolo', 'Add Title'),
        'page': 2,
        'anchorId': 'titles_create',
      },
      {
        'key':
            'comandi rapidi titoli vc cm def difesa danni damage scudo res vol mat ocu',
        'title': t('Comandi rapidi Titoli', 'Title quick commands'),
        'page': 2,
        'anchorId': 'titles_quick_commands',
      },
      {
        'key': 'art nome tipo descrizione dati art',
        'title': t('Art', 'Arts'),
        'page': 3,
        'anchorId': 'art_root',
      },
      {
        'key': 'skill scritte crea creazione tecniche talenti poteri',
        'title': t('Skill', 'Skills'),
        'page': 4,
        'anchorId': 'skills_root',
      },
      {
        'key': 'background diario storia ispirazioni',
        'title': t('Storia', 'Story'),
        'page': 5,
        'anchorId': 'story_root',
      },
      {
        'key': 'inventario peso arma oggetto borsa',
        'title': t('Borsa', 'Bag'),
        'page': 6,
        'anchorId': 'inventory_root',
      },
      {
        'key': 'obser risorse ascension dust ispirazioni diamanti',
        'title': t('Risorse', 'Resources'),
        'page': 7,
        'anchorId': 'resources_root',
      },
      {
        'key': 'manuale regole cerca indice',
        'title': t('Regole', 'Rules'),
        'page': 8,
        'anchorId': 'rules_root',
      },
      {
        'key': 'master mostro scheda rapida npc boss',
        'title': 'Master',
        'page': 9,
        'anchorId': 'master_root',
      },
      {
        'key':
            'iniziativa master turno round npc mostri boss summon partecipanti note acted skipped dead ordine manuale',
        'title': t('Iniziativa Master', 'Master Initiative'),
        'page': 9,
        'anchorId': 'master_root',
      },
      {
        'key':
            'impostazioni colori rgb luminosita luminosità saturazione opacita opacità log tutorial scudo oculum mostra sempre senza buff',
        'title': t('Opzioni', 'Options'),
        'page': _OculumHomePageState.settingsPageIndex,
        'anchorId': 'settings_root',
      },
      {
        'key':
            'scudo oculum mostra sempre senza buff vita barra hp shield oculumshield',
        'title': t('Mostra sempre Scudo Oculum', 'Always show Oculum Shield'),
        'page': _OculumHomePageState.settingsPageIndex,
        'anchorId': 'settings_oculum_shield',
      },
      {
        'key':
            'online connessione internet party tag master sync realtime supabase relay',
        'title': 'Online',
        'page': _OculumHomePageState.onlinePageIndex,
        'anchorId': 'online_root',
      },
      {
        'key':
            'dungeon minigioco run pawn mostri boss reward drop exp null fateless',
        'title': 'Dungeon',
        'page': 0,
        'action': 'dungeon',
      },
    ];

    for (final funzione in funzioni) {
      final key = '${funzione['key']} ${funzione['title']}';
      if (oculumSearchScore(q, key) > 0) {
        results.add({
          'title': funzione['title'] ?? key,
          'subtitle': t('Funzione rapida', 'Quick function'),
          'page': funzione['page'],
          'anchorId': funzione['anchorId'],
          'action': funzione['action'],
        });
      }
    }

    for (int i = 0; i < activeManualSections.length; i++) {
      final sec = activeManualSections[i];

      if (oculumSearchScore(
            q,
            '${manualTitle(sec)} ${manualContent(sec)} ${sec.titleIt} ${sec.titleEn} ${sec.contentIt} ${sec.contentEn}',
          ) >
          0) {
        results.add({
          'title': manualTitle(sec),
          'subtitle': t('Sezione Manuale', 'Manual section'),
          'page': 8,
          'anchorId': 'rules_open_section',
          'manualIndex': i,
        });
      }
    }

    void addUserResult({
      required String title,
      required String subtitle,
      required String haystack,
      required int page,
      String? anchorId,
    }) {
      final score = oculumSearchScore(q, '$title $subtitle $haystack');
      if (score <= 0) return;
      results.add({
        'title': title,
        'subtitle': subtitle,
        'page': page,
        'anchorId': anchorId,
        'score': score,
      });
    }

    for (int i = 0; i < titoli.length; i++) {
      final titolo = titoli[i];
      addUserResult(
        title: titolo.nome.trim().isEmpty
            ? t('Titolo senza nome', 'Unnamed title')
            : titolo.nome,
        subtitle: t('Titolo creato dall’utente', 'User-created title'),
        haystack:
            '${titolo.tipo} ${titolo.ottenimento} ${titolo.leggenda} ${titolo.buff} ${titolo.puntoCieco} ${titolo.skill} ${titolo.richiede} ${titolo.openName} ${titolo.openDescription} ${titolo.openBuff} ${titolo.openSkill}',
        page: 2,
        anchorId: titleEditorAnchorId(titolo),
      );
    }

    for (int i = 0; i < trattiRazziali.length; i++) {
      final tratto = trattiRazziali[i];
      addUserResult(
        title: tratto.nome.trim().isEmpty
            ? t('Tratto razziale senza nome', 'Unnamed racial trait')
            : tratto.nome,
        subtitle: t('Tratto razziale / Razza', 'Racial trait / Race'),
        haystack:
            '${tratto.tipo} ${tratto.ottenimento} ${tratto.leggenda} ${tratto.buff} ${tratto.puntoCieco} ${tratto.skill} ${tratto.richiede} ${tratto.openName} ${tratto.openDescription} ${tratto.openBuff} ${tratto.openSkill}',
        page: 2,
        anchorId: titleEditorAnchorId(tratto, trattoRazziale: true),
      );
    }

    for (int i = 0; i < skills.length; i++) {
      final skill = skills[i];
      addUserResult(
        title: skill.nome.trim().isEmpty
            ? t('Skill senza nome', 'Unnamed skill')
            : skill.nome,
        subtitle: t('Skill creata dall’utente', 'User-created skill'),
        haystack:
            '${skill.tipo} ${skill.costo} ${skill.cooldown} ${skill.descrizione}',
        page: 4,
        anchorId: 'free_skill_$i',
      );
    }

    for (int i = 0; i < arti.length; i++) {
      final art = arti[i];
      addUserResult(
        title: art.nome.trim().isEmpty ? 'Art' : art.nome,
        subtitle: t('Art / Open', 'Art / Open'),
        haystack: '${art.tipo} ${art.descrizione}',
        page: 3,
        anchorId: 'art_$i',
      );

      addUserResult(
        title: '${t('Open', 'Open')}: ${artOpenDisplayName(art, i)}',
        subtitle: t('Open Art', 'Art Open'),
        haystack:
            '${art.openName} ${art.openDescription} ${art.openBuff} ${art.openSkill}',
        page: 3,
        anchorId: 'art_${i}_open',
      );

      for (int skillIndex = 0; skillIndex < art.skills.length; skillIndex++) {
        final skill = art.skills[skillIndex];
        addUserResult(
          title:
              '${t('Skill', 'Skill')}: ${skill.nome.trim().isEmpty ? '${skillIndex + 1}' : skill.nome}',
          subtitle: art.nome.trim().isEmpty
              ? t('Skill Art', 'Art Skill')
              : '${t('Skill Art', 'Art Skill')}: ${art.nome}',
          haystack:
              '${skill.nome} ${skill.evo1} ${skill.evo2} ${skill.evo3} ${skill.evo4} ${skill.evo5}',
          page: 3,
          anchorId: 'art_${i}_skill_$skillIndex',
        );
      }
    }

    for (final item in inventario) {
      addUserResult(
        title: item.nome.trim().isEmpty
            ? t('Oggetto senza nome', 'Unnamed item')
            : item.nome,
        subtitle: item.arma && item.protegge
            ? t('Arma / Protezione', 'Weapon / Protection')
            : item.arma
            ? t('Arma / Inventario', 'Weapon / Inventory')
            : item.protegge
            ? t('Protezione / Inventario', 'Protection / Inventory')
            : t('Inventario', 'Inventory'),
        haystack:
            '${item.buff} ${item.note} ${item.elementoDanno} ${item.bonusDanno} ${item.bonusDifesa} ${item.bonusScudo} ${item.bonusScudoOculum}',
        page: 6,
        anchorId: 'inventory_root',
      );
    }

    for (final entry in inferredDamageTypeLabels().entries) {
      addUserResult(
        title: entry.value,
        subtitle: t('Tipo danno rilevato', 'Detected damage type'),
        haystack: '${entry.key} ${entry.value} danni difesa colore elemento',
        page: _OculumHomePageState.settingsPageIndex,
        anchorId: 'settings_root',
      );
    }

    for (final element in [...oculumDefaultElementIds, ...customDamageTypes]) {
      addUserResult(
        title: elementDisplayName(element),
        subtitle: t('Elemento / Tipo danno', 'Element / Damage type'),
        haystack: '$element ${elementDisplayName(element)} colore danni difesa',
        page: _OculumHomePageState.settingsPageIndex,
        anchorId: 'settings_root',
      );
    }

    for (final token in masterInitiativeTokens) {
      addUserResult(
        title: '${token['name'] ?? t('Partecipante', 'Participant')}',
        subtitle: t('Iniziativa Master', 'Master Initiative'),
        haystack:
            '${token['type'] ?? ''} ${token['side'] ?? ''} ${token['status'] ?? ''} ${token['notes'] ?? ''} ${token['initiativeRoll'] ?? ''} ${token['initiativeBase'] ?? ''} ${token['initiativeTotal'] ?? ''}',
        page: 9,
        anchorId: 'master_root',
      );
    }

    addUserResult(
      title: t('Storia della scheda', 'Sheet story'),
      subtitle: t('Background e note', 'Background and notes'),
      haystack:
          '${backgroundController.text} ${notePersonaggioController.text} ${diarioPagine.join(' ')} ${masterSessionController.text}',
      page: 5,
      anchorId: 'story_root',
    );

    results.sort(
      (a, b) => readIntValue(b['score']).compareTo(readIntValue(a['score'])),
    );
    return results;
  }

  void mostraCerca() {
    final controller = TextEditingController();

    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setLocalState) {
            final results = searchResults(controller.text);

            return AlertDialog(
              backgroundColor: const Color(0xFF10121A),
              title: Text(
                t('Cerca funzioni', 'Search functions'),
                style: TextStyle(
                  color: tertiaryColor,
                  fontWeight: FontWeight.bold,
                ),
              ),
              content: SizedBox(
                width: double.maxFinite,
                height: 420,
                child: Column(
                  children: [
                    TextField(
                      controller: controller,
                      autofocus: true,
                      style: const TextStyle(color: Colors.white),
                      decoration: fieldDecoration(
                        t('Scrivi cosa cerchi...', 'Type what you search...'),
                      ),
                      onChanged: (_) => setLocalState(() {}),
                    ),
                    const SizedBox(height: 12),
                    Expanded(
                      child: results.isEmpty
                          ? Center(
                              child: Text(
                                t('Nessun risultato.', 'No results.'),
                              ),
                            )
                          : ListView.builder(
                              itemCount: results.length,
                              itemBuilder: (context, index) {
                                final r = results[index];

                                return Material(
                                  color: Colors.transparent,
                                  child: ListTile(
                                    leading: Icon(
                                      Icons.search,
                                      color: tertiaryColor,
                                    ),
                                    title: Text(
                                      '${r['title']}',
                                      style: const TextStyle(
                                        color: Colors.white,
                                      ),
                                    ),
                                    subtitle: Text(
                                      '${r['subtitle']}',
                                      style: TextStyle(
                                        color: Colors.grey.shade400,
                                      ),
                                    ),
                                    onTap: () {
                                      Navigator.pop(context);
                                      FocusManager.instance.primaryFocus
                                          ?.unfocus();

                                      if (r['action'] == 'dungeon') {
                                        _openDungeonMiniGame();
                                        return;
                                      }

                                      vaiAllaFunzione(
                                        page: readIntValue(r['page']),
                                        anchorId: '${r['anchorId'] ?? ''}',
                                        manualIndex: r['manualIndex'] == null
                                            ? null
                                            : readIntValue(r['manualIndex']),
                                        logTitle: '${r['title']}',
                                        focusField: false,
                                      );
                                    },
                                  ),
                                );
                              },
                            ),
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: Text(t('Chiudi', 'Close')),
                ),
              ],
            );
          },
        );
      },
    ).whenComplete(controller.dispose);
  }

  // =====================================================
  // IMPOSTAZIONI
  // =====================================================

  Widget sheetCodeSettingsPanel() {
    final hasSheets = schedePersonaggio.isNotEmpty;

    return gothicPanel(
      borderColor: tertiaryColor,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.ios_share, color: tertiaryColor),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  t('Codici Scheda', 'Sheet Codes'),
                  style: TextStyle(
                    color: tertiaryColor,
                    fontSize: 20,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          smallInfoText(
            t(
              'Copia una scheda o piu schede in un codice unico. Puoi mandarlo fuori dall app in chat, al party o agli amici: chi lo incolla qui lo salva come nuova scheda.',
              'Copy one or more sheets into a single code. You can send it outside the app in chat, to the party or friends: whoever pastes it here saves it as a new sheet.',
            ),
          ),
          const SizedBox(height: 14),
          if (hasSheets) ...[
            Text(
              t('Schede da includere', 'Sheets to include'),
              style: TextStyle(
                color: primaryColor,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (int i = 0; i < schedePersonaggio.length; i++)
                  FilterChip(
                    selected: selectedSheetCodeIndexes.contains(i),
                    selectedColor: tertiaryColor.withValues(alpha: 0.25),
                    backgroundColor: Colors.black.withValues(alpha: 0.28),
                    checkmarkColor: tertiaryColor,
                    side: BorderSide(
                      color: selectedSheetCodeIndexes.contains(i)
                          ? tertiaryColor
                          : primaryColor.withValues(alpha: 0.35),
                    ),
                    label: Text(
                      '${i + 1}. ${nomeSchedaPersonaggio(i)}',
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: selectedSheetCodeIndexes.contains(i)
                            ? tertiaryColor
                            : Colors.white,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    onSelected: (value) {
                      setState(() {
                        if (value) {
                          selectedSheetCodeIndexes.add(i);
                        } else {
                          selectedSheetCodeIndexes.remove(i);
                        }
                      });
                    },
                  ),
              ],
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                ElevatedButton.icon(
                  onPressed: copiaCodiceSchedaCorrente,
                  icon: const Icon(Icons.content_copy),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: tertiaryColor,
                    foregroundColor: Colors.black,
                  ),
                  label: Text(t('Copia aperta', 'Copy current')),
                ),
                ElevatedButton.icon(
                  onPressed: selectedSheetCodeIndexes.isEmpty
                      ? null
                      : copiaCodiceSchedeSelezionate,
                  icon: const Icon(Icons.copy_all),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: primaryColor,
                    foregroundColor: Colors.black,
                  ),
                  label: Text(t('Copia selezionate', 'Copy selected')),
                ),
                OutlinedButton.icon(
                  onPressed: () {
                    setState(() {
                      selectedSheetCodeIndexes
                        ..clear()
                        ..addAll(
                          List<int>.generate(
                            schedePersonaggio.length,
                            (index) => index,
                          ),
                        );
                    });
                  },
                  icon: const Icon(Icons.select_all),
                  label: Text(t('Tutte', 'All')),
                ),
                OutlinedButton.icon(
                  onPressed: () {
                    setState(selectedSheetCodeIndexes.clear);
                  },
                  icon: const Icon(Icons.backspace_outlined),
                  label: Text(t('Pulisci', 'Clear')),
                ),
              ],
            ),
            const SizedBox(height: 16),
          ],
          TextField(
            controller: sheetCodeController,
            minLines: 4,
            maxLines: 8,
            style: const TextStyle(color: Colors.white, fontSize: 13),
            decoration: InputDecoration(
              labelText: t(
                'Incolla qui uno o piu codici scheda',
                'Paste one or more sheet codes here',
              ),
              labelStyle: TextStyle(color: primaryColor),
              filled: true,
              fillColor: Colors.black.withValues(alpha: 0.28),
              enabledBorder: OutlineInputBorder(
                borderSide: BorderSide(
                  color: primaryColor.withValues(alpha: 0.35),
                ),
              ),
              focusedBorder: OutlineInputBorder(
                borderSide: BorderSide(color: tertiaryColor),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              ElevatedButton.icon(
                onPressed: incollaCodiceSchedeDagliAppunti,
                icon: const Icon(Icons.paste),
                style: ElevatedButton.styleFrom(
                  backgroundColor: secondaryColor,
                  foregroundColor: Colors.white,
                  side: BorderSide(color: tertiaryColor),
                ),
                label: Text(t('Incolla appunti', 'Paste clipboard')),
              ),
              ElevatedButton.icon(
                onPressed: importaCodiceSchedeIncollato,
                icon: const Icon(Icons.save_alt),
                style: ElevatedButton.styleFrom(
                  backgroundColor: tertiaryColor,
                  foregroundColor: Colors.black,
                ),
                label: Text(t('Importa codice', 'Import code')),
              ),
              OutlinedButton.icon(
                onPressed: () {
                  setState(sheetCodeController.clear);
                },
                icon: const Icon(Icons.close),
                label: Text(t('Svuota riquadro', 'Empty box')),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget elementColorsSettingsPanel() {
    return gothicPanel(
      borderColor: elementColor('oculum'),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            t(
              'Colori Elementi / Tipi di Danno',
              'Element / Damage Type Colors',
            ),
            style: TextStyle(
              color: elementColor('oculum'),
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          smallInfoText(
            t(
              'Il colore del danno usa l’elemento dominante. Puoi personalizzare i colori principali; se un tipo nuovo non ha colore dedicato userà il colore extra dell’occhio senza alterare lo sprite.',
              'Damage color uses the dominant element. You can customize main colors; if a new type has no dedicated color it uses the extra eye color without altering the sprite.',
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: campoTesto(
                  label: t('Nuovo tipo di danno', 'New damage type'),
                  controller: customDamageTypeController,
                  numero: false,
                  helper: t(
                    'Esempi: Ruggine, Etere, Memoria, Fato spezzato. Verrà usato nei menu danno e nei colori.',
                    'Examples: Rust, Aether, Memory, Broken Fate. It will be used in damage menus and colors.',
                  ),
                ),
              ),
              const SizedBox(width: 8),
              ElevatedButton.icon(
                onPressed: addCustomDamageTypeFromSettings,
                icon: const Icon(Icons.add),
                style: ElevatedButton.styleFrom(
                  backgroundColor: tertiaryColor,
                  foregroundColor: tertiaryColor.computeLuminance() > 0.45
                      ? Colors.black
                      : Colors.white,
                ),
                label: Text(t('Aggiungi', 'Add')),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final element in oculumDefaultElementIds)
                InputChip(
                  backgroundColor: elementColor(
                    element,
                  ).withValues(alpha: 0.18),
                  side: BorderSide(
                    color: elementColor(element).withValues(alpha: 0.65),
                  ),
                  label: Text(
                    elementDisplayName(element),
                    style: TextStyle(
                      color: elementColor(element),
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  onPressed: () => setElementColor(element, tertiaryColor),
                  onDeleted: () => resetElementColor(element),
                  deleteIcon: Icon(
                    Icons.restore,
                    color: primaryColor,
                    size: 16,
                  ),
                ),
            ],
          ),
          if (customDamageTypes.isNotEmpty) ...[
            const SizedBox(height: 14),
            Text(
              t('Tipi personalizzati', 'Custom types'),
              style: TextStyle(
                color: primaryColor,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final element in customDamageTypes)
                  InputChip(
                    backgroundColor: elementColor(
                      element,
                    ).withValues(alpha: 0.18),
                    side: BorderSide(
                      color: elementColor(element).withValues(alpha: 0.65),
                    ),
                    label: Text(
                      elementDisplayName(element),
                      style: TextStyle(
                        color: elementColor(element),
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    onPressed: () => setElementColor(element, tertiaryColor),
                    onDeleted: () => removeCustomDamageType(element),
                    deleteIcon: const Icon(
                      Icons.delete,
                      color: Colors.redAccent,
                      size: 16,
                    ),
                  ),
              ],
            ),
          ],
          Builder(
            builder: (context) {
              final inferred = inferredDamageTypeLabels().entries
                  .where(
                    (entry) =>
                        !oculumDefaultElementIds.contains(entry.key) &&
                        !customDamageTypes.any(
                          (custom) =>
                              oculumNormalizeElementId(custom) == entry.key,
                        ),
                  )
                  .toList();
              if (inferred.isEmpty) return const SizedBox.shrink();
              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 14),
                  Text(
                    t('Rilevati nei testi', 'Detected in texts'),
                    style: TextStyle(
                      color: primaryColor,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  smallInfoText(
                    t(
                      'Questi tipi esistono finché sono scritti in Titoli, Art, Skill o oggetti. Tocca per assegnare il colore terziario; reset per togliere solo il colore.',
                      'These types exist while they are written in Titles, Arts, Skills or items. Tap to assign the tertiary color; reset removes only the color.',
                    ),
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      for (final entry in inferred)
                        InputChip(
                          backgroundColor: elementColor(
                            entry.key,
                          ).withValues(alpha: 0.18),
                          side: BorderSide(
                            color: elementColor(
                              entry.key,
                            ).withValues(alpha: 0.65),
                          ),
                          label: Text(
                            entry.value,
                            style: TextStyle(
                              color: elementColor(entry.key),
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          onPressed: () =>
                              setElementColor(entry.key, tertiaryColor),
                          onDeleted: () => resetElementColor(entry.key),
                          deleteIcon: Icon(
                            Icons.restore,
                            color: primaryColor,
                            size: 16,
                          ),
                        ),
                    ],
                  ),
                ],
              );
            },
          ),
          const SizedBox(height: 12),
          smallInfoText(
            t(
              'Tocca un elemento per assegnargli il colore terziario attuale; usa l’icona di reset per tornare al default. Il colore Oculum delle formule segue il colore qui sotto.',
              'Tap an element to assign the current tertiary color; use reset to restore default. Formula Oculum color follows the color below.',
            ),
            color: primaryColor,
          ),
          const SizedBox(height: 12),
          ElevatedButton.icon(
            onPressed: resetAllElementColors,
            icon: const Icon(Icons.restore),
            style: ElevatedButton.styleFrom(
              backgroundColor: secondaryColor,
              foregroundColor: Colors.white,
            ),
            label: Text(
              t('Reset tutti i colori elemento', 'Reset all element colors'),
            ),
          ),
        ],
      ),
    );
  }

  Widget settingsColorSwatch(String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: 0.22),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withValues(alpha: 0.68)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 18,
            height: 18,
            decoration: BoxDecoration(
              color: color,
              borderRadius: BorderRadius.circular(4),
              border: Border.all(color: Colors.white24),
            ),
          ),
          const SizedBox(width: 8),
          Text(
            label,
            style: TextStyle(color: color, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }

  String settingsCompactDate(DateTime? value) {
    if (value == null) return t('Mai', 'Never');
    final local = value.toLocal();
    final day = local.day.toString().padLeft(2, '0');
    final month = local.month.toString().padLeft(2, '0');
    final hour = local.hour.toString().padLeft(2, '0');
    final minute = local.minute.toString().padLeft(2, '0');
    return '$day/$month $hour:$minute';
  }

  String settingsEnabledLabel(bool value) {
    return value ? t('Attivo', 'On') : t('Spento', 'Off');
  }

  Color settingsEnabledColor(bool value) {
    return value ? tertiaryColor : Colors.grey.shade500;
  }

  Widget settingsStatusCard({
    required IconData icon,
    required String title,
    required String value,
    required Color color,
    String? detail,
  }) {
    return ConstrainedBox(
      constraints: const BoxConstraints(minWidth: 178, maxWidth: 268),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.black.withValues(alpha: 0.24),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: color.withValues(alpha: 0.55)),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.16),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: color.withValues(alpha: 0.55)),
              ),
              child: Icon(icon, color: color, size: 19),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: primaryColor.withValues(alpha: 0.92),
                      fontSize: 11.5,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    value,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: color,
                      fontSize: 16,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  if (detail != null) ...[
                    const SizedBox(height: 3),
                    Text(
                      detail,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: Colors.grey.shade300,
                        fontSize: 11.5,
                        height: 1.2,
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget settingsSectionBanner({
    required IconData icon,
    required String title,
    required String subtitle,
    required Color color,
  }) {
    return gothicPanel(
      borderColor: color,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: color.withValues(alpha: 0.55)),
            ),
            child: Icon(icon, color: color, size: 22),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    color: color,
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 4),
                smallInfoText(subtitle),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void resetSheetLayoutSettings() {
    setState(() {
      _expandedFunctionSections.clear();
      mostraDannoCuraScheda = true;
      mostraStrumentiManualeRapidi = true;
      mostraBorsaCompatta = true;
      mostraPartyScheda = true;
      mostraTastiRapidiIndice = true;
      mostraValoriEditabiliScheda = true;
      desktopSideMenuOpen = false;
      risultato = t(
        'Layout della scheda ripristinato.',
        'Sheet layout restored.',
      );
      aggiungiLog(risultato);
    });
    programmaSalvataggio();
  }

  Widget settingsHeroPanel() {
    final selectedPreset = colorPresetById(colorPresetSelezionato);
    final themeName = selectedPreset == null
        ? t('Personalizzato', 'Custom')
        : colorPresetName(selectedPreset);
    final saveColor = salvataggioBloccatoPerErrore
        ? Colors.redAccent
        : tertiaryColor;
    final compactSaveDate = settingsCompactDate(ultimoSalvataggioCompletatoAt);

    return gothicPanel(
      borderColor: tertiaryColor,
      padding: EdgeInsets.zero,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(lightweightUi ? 9 : 12),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                backgroundTopColor.withValues(alpha: 0.62),
                secondaryColor.withValues(alpha: 0.52),
                backgroundBottomColor.withValues(alpha: 0.82),
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 54,
                    height: 54,
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: 0.28),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: eyePupilGlowColor.withValues(alpha: 0.72),
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: eyePupilGlowColor.withValues(alpha: 0.18),
                          blurRadius: 12,
                        ),
                      ],
                    ),
                    child: Icon(Icons.tune, color: tertiaryColor, size: 28),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          t('Impostazioni Oculum', 'Oculum Settings'),
                          style: TextStyle(
                            color: tertiaryColor,
                            fontSize: 24,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(height: 4),
                        smallInfoText(
                          t(
                            'Stato rapido, controlli principali e personalizzazione della scheda in un unico posto.',
                            'Quick status, main controls and sheet customization in one place.',
                          ),
                          color: Colors.grey.shade200,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              Wrap(
                spacing: 10,
                runSpacing: 10,
                children: [
                  settingsStatusCard(
                    icon: Icons.save,
                    title: t('Ultimo salvataggio', 'Last save'),
                    value: compactSaveDate,
                    color: saveColor,
                    detail: t(
                      'Rev. $salvataggioRevisione / errori $salvataggioFallimentiConsecutivi',
                      'Rev. $salvataggioRevisione / errors $salvataggioFallimentiConsecutivi',
                    ),
                  ),
                  settingsStatusCard(
                    icon: Icons.palette,
                    title: t('Tema colore', 'Color theme'),
                    value: themeName,
                    color: tertiaryColor,
                    detail: selectedPreset == null
                        ? t('Palette manuale', 'Manual palette')
                        : colorPresetDescription(selectedPreset),
                  ),
                  settingsStatusCard(
                    icon: Icons.phone_iphone,
                    title: t('Modalita veloce', 'Fast mode'),
                    value: settingsEnabledLabel(modalitaVeloce),
                    color: settingsEnabledColor(modalitaVeloce),
                    detail: t('Vista scheda compatta', 'Compact sheet view'),
                  ),
                  settingsStatusCard(
                    icon: Icons.desktop_windows,
                    title: t('Interfaccia', 'Interface'),
                    value: modalitaDesktop
                        ? t('Desktop', 'Desktop')
                        : t('Mobile', 'Mobile'),
                    color: modalitaDesktop ? tertiaryColor : primaryColor,
                    detail: linguaInglese ? 'English' : 'Italiano',
                  ),
                  settingsStatusCard(
                    icon: Icons.admin_panel_settings,
                    title: t('Master', 'Master'),
                    value: settingsEnabledLabel(modalitaMaster),
                    color: settingsEnabledColor(modalitaMaster),
                    detail: masterPublicDiceVisible
                        ? t('Dadi pubblici', 'Public dice')
                        : t('Dadi privati', 'Private dice'),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              Container(
                height: 52,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: primaryColor.withValues(alpha: 0.32),
                  ),
                  gradient: LinearGradient(
                    colors: [
                      backgroundTopColor,
                      backgroundMidColor,
                      backgroundBottomColor,
                    ],
                  ),
                ),
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  child: Row(
                    children: [
                      settingsColorSwatch(
                        t('Primario', 'Primary'),
                        primaryColor,
                      ),
                      const SizedBox(width: 8),
                      settingsColorSwatch(
                        t('Secondario', 'Secondary'),
                        secondaryColor,
                      ),
                      const SizedBox(width: 8),
                      settingsColorSwatch(
                        t('Terziario', 'Tertiary'),
                        tertiaryColor,
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 14),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  ElevatedButton.icon(
                    onPressed: () async {
                      await salvaDati();
                      if (mounted) setState(() {});
                    },
                    icon: const Icon(Icons.save),
                    label: Text(t('Salva ora', 'Save now')),
                  ),
                  OutlinedButton.icon(
                    onPressed: esportaBackupNegliAppunti,
                    icon: const Icon(Icons.download),
                    label: Text(t('Backup', 'Backup')),
                  ),
                  const SizedBox(width: 8),
                  const OculumAuthPanel(),
                  OutlinedButton.icon(
                    onPressed: resetSheetLayoutSettings,
                    icon: const Icon(Icons.dashboard_customize),
                    label: Text(t('Reset layout', 'Reset layout')),
                  ),
                  OutlinedButton.icon(
                    onPressed: () => applicaColorPreset('classic_reliquary'),
                    icon: const Icon(Icons.restore),
                    label: Text(t('Tema default', 'Default theme')),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget settingsControlCenterPanel() {
    final lastSave = ultimoSalvataggioCompletatoAt == null
        ? t('Mai in questa sessione', 'Never in this session')
        : ultimoSalvataggioCompletatoAt!.toLocal().toString();

    ExpansionTile tile({
      required IconData icon,
      required String title,
      required List<Widget> children,
      bool expanded = false,
    }) {
      return ExpansionTile(
        initiallyExpanded: expanded,
        maintainState: true,
        tilePadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 2),
        childrenPadding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
        backgroundColor: Colors.black.withValues(alpha: 0.16),
        collapsedBackgroundColor: Colors.black.withValues(alpha: 0.06),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
          side: BorderSide(color: tertiaryColor.withValues(alpha: 0.30)),
        ),
        collapsedShape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
          side: BorderSide(color: primaryColor.withValues(alpha: 0.16)),
        ),
        leading: Icon(icon, color: tertiaryColor),
        iconColor: tertiaryColor,
        collapsedIconColor: primaryColor,
        title: Text(
          title,
          style: TextStyle(color: primaryColor, fontWeight: FontWeight.w900),
        ),
        children: children,
      );
    }

    return gothicPanel(
      borderColor: tertiaryColor,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.tune, color: tertiaryColor),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  t('Pannello di controllo', 'Control panel'),
                  style: TextStyle(
                    color: tertiaryColor,
                    fontSize: 20,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          smallInfoText(
            t(
              'Sezioni compatte per tema, salvataggi, parser @, Osservato e forme Skill. I controlli completi restano sotto.',
              'Compact sections for theme, saves, @ parser, Observation and Skill forms. Full controls remain below.',
            ),
          ),
          const SizedBox(height: 10),
          tile(
            icon: Icons.save,
            title: t(
              'Salvataggi / Backup / Autosave',
              'Saves / Backup / Autosave',
            ),
            expanded: true,
            children: [
              smallInfoText(
                t(
                  'Ultimo salvataggio: $lastSave. Revisione: $salvataggioRevisione. Fallimenti consecutivi: $salvataggioFallimentiConsecutivi.',
                  'Last save: $lastSave. Revision: $salvataggioRevisione. Consecutive failures: $salvataggioFallimentiConsecutivi.',
                ),
                color: salvataggioBloccatoPerErrore
                    ? Colors.redAccent
                    : tertiaryColor,
              ),
              if (ultimoErroreCaricamentoSalvataggio.isNotEmpty) ...[
                const SizedBox(height: 6),
                smallInfoText(
                  ultimoErroreCaricamentoSalvataggio,
                  color: Colors.redAccent,
                ),
              ],
              const SizedBox(height: 10),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  ElevatedButton.icon(
                    onPressed: () async {
                      await salvaDati();
                      if (mounted) setState(() {});
                    },
                    icon: const Icon(Icons.save),
                    label: Text(t('Salva ora', 'Save now')),
                  ),
                  OutlinedButton.icon(
                    onPressed: esportaBackupNegliAppunti,
                    icon: const Icon(Icons.download),
                    label: Text(t('Esporta backup', 'Export backup')),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 8),
          tile(
            icon: Icons.palette,
            title: t(
              'Aspetto / Tema e colori',
              'Appearance / Theme and colors',
            ),
            children: [
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  settingsColorSwatch(t('Primario', 'Primary'), primaryColor),
                  settingsColorSwatch(
                    t('Secondario', 'Secondary'),
                    secondaryColor,
                  ),
                  settingsColorSwatch(
                    t('Terziario', 'Tertiary'),
                    tertiaryColor,
                  ),
                  settingsColorSwatch(
                    t('Utility / dettagli', 'Utility / details'),
                    eyeUtilityColor,
                  ),
                  settingsColorSwatch(
                    t('Formule Oculum', 'Oculum formulas'),
                    oculumStatFormulaColor,
                  ),
                  settingsColorSwatch(
                    t('Sfondo alto', 'Background top'),
                    backgroundTopColor,
                  ),
                  settingsColorSwatch(
                    t('Sfondo medio', 'Background middle'),
                    backgroundMidColor,
                  ),
                  settingsColorSwatch(
                    t('Sfondo basso', 'Background bottom'),
                    backgroundBottomColor,
                  ),
                  settingsColorSwatch(
                    t('Glow occhio', 'Eye glow'),
                    eyePupilGlowColor,
                  ),
                ],
              ),
              const SizedBox(height: 10),
              OutlinedButton.icon(
                onPressed: () => applicaColorPreset('classic_reliquary'),
                icon: const Icon(Icons.restore),
                label: Text(
                  t('Ripristina tema predefinito', 'Restore default theme'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          tile(
            icon: Icons.alternate_email,
            title: t('Parser e comandi @', '@ parser and commands'),
            children: [
              smallInfoText(
                '@Ocu+1 ogni 50 HPSpesi\n@Stats+1\n@HP-10=Stats+1\n@Danni+Vol/2 Fuoco\n@Difesa+15 Cenere',
                color: primaryColor,
              ),
            ],
          ),
          const SizedBox(height: 8),
          tile(
            icon: Icons.remove_red_eye,
            title: t(
              'Osservato / Punti extra livello',
              'Observation / Extra level points',
            ),
            children: [
              smallInfoText(
                t(
                  'Se una scheda e Osservata, ottiene 1 punto statistica extra per ogni livello totale, anche per i livelli raggiunti prima di essere osservata. I punti non si duplicano e restano salvati.',
                  'If a sheet is Observed, it gains 1 extra stat point for each total level, including levels reached before being observed. Points do not duplicate and remain saved.',
                ),
                color: tertiaryColor,
              ),
            ],
          ),
          const SizedBox(height: 8),
          tile(
            icon: Icons.account_tree,
            title: t(
              'Skill normali / Forme skill',
              'Normal Skills / Skill forms',
            ),
            children: [
              smallInfoText(
                t(
                  'Le Skill normali possono avere da 1 a 5 forme. Le Skill vecchie vengono trattate come Forma 1 senza perdere dati.',
                  'Normal Skills can have 1 to 5 forms. Old Skills are treated as Form 1 without losing data.',
                ),
                color: tertiaryColor,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget slotMachineRulesSettingsPanel() {
    const chances = <int>[95, 80, 50, 20, 5];
    String chanceLabel(int value) => switch (value) {
      95 => t('Molto facile', 'Very easy'),
      80 => t('Facile', 'Easy'),
      50 => t('Medio', 'Medium'),
      20 => t('Difficile', 'Hard'),
      _ => t('Impossibile', 'Impossible'),
    };
    return gothicPanel(
      borderColor: Colors.purpleAccent,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.casino, color: Colors.purpleAccent),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  t('Slot machine dei tiri', 'Roll slot machine'),
                  style: const TextStyle(
                    fontWeight: FontWeight.w900,
                    fontSize: 18,
                  ),
                ),
              ),
              IconButton(
                tooltip: t('Scegli probabilita', 'Choose probability'),
                icon: const Icon(Icons.visibility),
                onPressed: () => showModalBottomSheet<void>(
                  context: context,
                  builder: (context) => SafeArea(
                    child: ListView(
                      shrinkWrap: true,
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(16),
                          child: Text(
                            t('Probabilita di riuscita', 'Success probability'),
                            style: Theme.of(context).textTheme.titleLarge,
                          ),
                        ),
                        for (final chance in chances)
                          ListTile(
                            leading: Icon(
                              slotMachineSuccessChance == chance
                                  ? Icons.visibility
                                  : Icons.visibility_off,
                            ),
                            title: Text('${chanceLabel(chance)} · $chance%'),
                            selected: slotMachineSuccessChance == chance,
                            onTap: () {
                              setState(() => slotMachineSuccessChance = chance);
                              programmaSalvataggio();
                              Navigator.pop(context);
                            },
                          ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            t(
              'Trasforma solo la visualizzazione dei tiri in tre rulli. Sottotratti inclusi: il totale reale con il bonus resta scritto sotto i rulli. Critico negativo rosso: PERICOLO. Critico positivo oro: SUCCESSO CRITICO.',
              'Turns only the roll display into three reels. Subtraits included: the real total with bonus remains below the reels. Negative critical red: DANGER. Positive critical gold: CRITICAL SUCCESS.',
            ),
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            value: slotMachineRollsEnabled,
            activeThumbColor: Colors.purpleAccent,
            title: Text(t('Abilita slot machine', 'Enable slot machine')),
            subtitle: Text(
              '${chanceLabel(slotMachineSuccessChance)} · $slotMachineSuccessChance%',
            ),
            onChanged: oculusModActive
                ? null
                : (value) {
                    setState(() => slotMachineRollsEnabled = value);
                    programmaSalvataggio();
                  },
          ),
        ],
      ),
    );
  }

  void tentaFortunaSlotMachine() {
    const symbols = <String>['BUFF', 'SCHIVATA', 'ISPIRAZIONE', 'EXP', 'VUOTO'];
    final random = Random.secure();
    if (slotFortuneUsedThisLongRest) return;
    setState(() {
      final available = symbols.toList()..shuffle(random);
      final locked = <String>{
        for (var i = 0; i < 3; i++)
          if (slotFortuneLocks[i]) slotFortuneReels[i],
      }..remove('?');
      for (var i = 0; i < 3; i++) {
        if (!slotFortuneLocks[i]) {
          slotFortuneReels[i] = available.firstWhere(
            (item) => !locked.contains(item),
          );
          locked.add(slotFortuneReels[i]);
        }
      }
      // Fortuna non decide il risultato: può solo trasformare un rullo vuoto
      // in una ricompensa diversa, lasciando il resto del caso intatto.
      final emptyIndex = slotFortuneReels.indexOf('VUOTO');
      if (emptyIndex >= 0 &&
          random.nextInt(100) < min(55, max(0, fortuna) * 5)) {
        final replacement = available.firstWhere(
          (item) =>
              item != 'VUOTO' &&
              !slotFortuneReels
                  .where((value) => value != 'VUOTO')
                  .contains(item),
          orElse: () => 'VUOTO',
        );
        if (replacement != 'VUOTO') slotFortuneReels[emptyIndex] = replacement;
      }
      final rewards = <String>[];
      for (final reward in slotFortuneReels) {
        switch (reward) {
          case 'BUFF':
            final amount = random.nextInt(2) + 1;
            tempResilienza += amount;
            tempVolonta += amount;
            tempMateria += amount;
            tempOculum += amount;
            rewards.add('BUFF +$amount');
            break;
          case 'SCHIVATA':
            schivataOculumRiduzionePronta = max(
              schivataOculumRiduzionePronta,
              25 + random.nextInt(51),
            );
            schivataOculumEtichettaPronta = t('Fortuna slot', 'Slot luck');
            rewards.add('SCHIVATA $schivataOculumRiduzionePronta%');
            break;
          case 'ISPIRAZIONE':
            ispirazioniController.text =
                '${leggiNumero(ispirazioniController) + 1}';
            rewards.add('ISPIRAZIONE');
            break;
          case 'EXP':
            final amount = 10 + random.nextInt(66);
            applicaEsperienzaFlat(
              amount,
              motivo: t('Slot fortuna', 'Luck slot'),
            );
            for (final stat in hiddenEyeStats.where((stat) => stat.unlocked)) {
              oculusSubtraitMasteryApplyGain(stat, amount);
              notifyHiddenEyeStatChanged(stat);
            }
            rewards.add('EXP +$amount');
            break;
          case 'VUOTO':
            rewards.add(t('VUOTO', 'EMPTY'));
            break;
        }
      }
      slotFortuneUsedThisLongRest = true;
      risultato = t(
        'Tenta la fortuna: ${rewards.join(' · ')}. Disponibile di nuovo dopo il prossimo riposo lungo.',
        'Try your luck: ${rewards.join(' · ')}. Available again after the next long rest.',
      );
      aggiungiLog(risultato);
    });
    invalidateDerivedDataCaches();
    notifyOculumResourceChanged();
    programmaSalvataggio();
  }

  Widget tentaFortunaSlotSheetCard() {
    if (!slotMachineRollsEnabled) return const SizedBox.shrink();
    return gothicPanel(
      borderColor: Colors.purpleAccent,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            t('Tenta la fortuna', 'Try your luck'),
            style: const TextStyle(
              color: Colors.purpleAccent,
              fontWeight: FontWeight.w900,
              fontSize: 17,
            ),
          ),
          const SizedBox(height: 6),
          Text(
            slotFortuneUsedThisLongRest
                ? t(
                    'Usata: tornerà disponibile al prossimo riposo lungo.',
                    'Used: available again after the next long rest.',
                  )
                : t(
                    'Tre ricompense sempre diverse. Blocca i rulli prima di tentare.',
                    'Three always-different rewards. Lock reels before trying.',
                  ),
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            children: [
              for (var i = 0; i < 3; i++)
                ActionChip(
                  avatar: Icon(
                    slotFortuneLocks[i] ? Icons.lock : Icons.lock_open,
                  ),
                  label: Text(slotFortuneReels[i]),
                  onPressed: slotFortuneUsedThisLongRest
                      ? null
                      : () => setState(
                          () => slotFortuneLocks[i] = !slotFortuneLocks[i],
                        ),
                ),
            ],
          ),
          const SizedBox(height: 8),
          FilledButton.icon(
            onPressed: slotFortuneUsedThisLongRest
                ? null
                : tentaFortunaSlotMachine,
            icon: const Icon(Icons.casino),
            label: Text(t('Tenta la fortuna', 'Try your luck')),
          ),
        ],
      ),
    );
  }

  Widget modsSettingsPanel() {
    return dropdownSection(
      title: 'MOD',
      subtitle: t(
        'Oculus, Old School e Roulette. Oculus è esclusiva.',
        'Oculus, Old School and Roulette. Oculus is exclusive.',
      ),
      icon: Icons.extension,
      borderColor: primaryColor,
      sectionId: 'settings_mods',
      initiallyExpanded: false,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          oculusModSettingsPanel(),
          const SizedBox(height: 10),
          gothicPanel(
            borderColor: const Color(0xFFB88A3B),
            child: SwitchListTile(
              contentPadding: EdgeInsets.zero,
              value: manuscriptLivingActive,
              activeThumbColor: const Color(0xFFB88A3B),
              secondary: const Icon(Icons.auto_stories),
              title: const Text('Manoscritto Vivente'),
              subtitle: Text(
                oculusModActive
                    ? 'Non disponibile mentre Oculus è attiva.'
                    : 'Riorganizza GIOCA come manoscritto rituale, senza cambiare dati, regole o funzioni.',
              ),
              onChanged: oculusModActive
                  ? null
                  : (value) =>
                        setActiveGameMod(value ? 'manuscript_living' : ''),
            ),
          ),
          const SizedBox(height: 10),
          gothicPanel(
            borderColor: tertiaryColor,
            child: SwitchListTile(
              contentPadding: EdgeInsets.zero,
              value: temiOldSchool,
              activeThumbColor: tertiaryColor,
              secondary: const Icon(Icons.history_edu),
              title: Text(t('Old School Style', 'Old School Style')),
              subtitle: Text(
                oculusModActive
                    ? t(
                        'Non disponibile mentre Oculus è attiva.',
                        'Unavailable while Oculus is active.',
                      )
                    : t(
                        'Ripristina il sistema grafico precedente senza toccare dati o funzioni.',
                        'Restores the previous visual system without touching data or features.',
                      ),
              ),
              onChanged: oculusModActive
                  ? null
                  : (value) {
                      setState(() {
                        temiOldSchool = value;
                        risultato = value
                            ? t(
                                'Mod Temi old school attivata.',
                                'Old-school Themes mod enabled.',
                              )
                            : t(
                                'Nuovo design Oculum attivato.',
                                'New Oculum design enabled.',
                              );
                        aggiungiLog(risultato);
                      });
                      programmaSalvataggio();
                    },
            ),
          ),
          const SizedBox(height: 10),
          slotMachineRulesSettingsPanel(),
        ],
      ),
    );
  }

  Widget settingsAppearanceControlPanel() {
    return gothicPanel(
      borderColor: tertiaryColor,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.palette_outlined, color: tertiaryColor),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  t('Aspetto Oculum', 'Oculum appearance'),
                  style: TextStyle(
                    color: tertiaryColor,
                    fontSize: 19,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 7),
          smallInfoText(
            t(
              'I controlli grafici sono raccolti qui: aprili solo quando vuoi modificare tema, pelle, colori e decorazioni.',
              'Visual controls are collected here: open them only when you want to edit theme, skin, colors and decorations.',
            ),
          ),
          const SizedBox(height: 12),
          FilledButton.tonalIcon(
            onPressed: () => setState(
              () => settingsAppearanceExpanded = !settingsAppearanceExpanded,
            ),
            icon: Icon(
              settingsAppearanceExpanded
                  ? Icons.visibility_off_outlined
                  : Icons.palette_outlined,
            ),
            label: Text(
              settingsAppearanceExpanded
                  ? t('Chiudi modifiche aspetto', 'Close appearance controls')
                  : t('Modifica aspetto', 'Edit appearance'),
            ),
          ),
        ],
      ),
    );
  }

  Widget settingsPage() {
    return responsivePageList(
      pageKey: 'settings',
      maxColumns: 2,
      minColumnWidth: 340,
      fullWidthIndexes: const <int>{0, 2, 3, 4, 5, 6, 7, 17},
      children: [
        functionAnchor(
          'settings_root',
          sectionTitle(t('Impostazioni', 'Settings')),
        ),
        gothicPanel(borderColor: tertiaryColor, child: pageDropdown()),
        functionAnchor('settings_hero', settingsHeroPanel()),
        functionAnchor('settings_mods', modsSettingsPanel()),
        functionAnchor('settings_control_center', settingsControlCenterPanel()),
        functionAnchor(
          'settings_appearance_control',
          settingsAppearanceControlPanel(),
        ),
        if (settingsAppearanceExpanded) ...[
          functionAnchor(
            'settings_theme_showcase',
            settingsThemeShowcasePanel(),
          ),
          functionAnchor('settings_gui_skins', settingsGuiSkinGalleryPanel()),
          functionAnchor(
            'settings_skin_customization',
            themeCustomizationSlidersPanel(),
          ),
          functionAnchor(
            'settings_decorations_gallery',
            settingsDecorationsGalleryPanel(),
          ),
        ],
        functionAnchor(
          'settings_management_layout',
          settingsSectionBanner(
            icon: Icons.dashboard_customize,
            title: t('Gestione e layout', 'Management and layout'),
            subtitle: t(
              'Codici scheda, sicurezza visiva, modalita, lingua e tutorial.',
              'Sheet codes, visual safeguards, modes, language and tutorial.',
            ),
            color: primaryColor,
          ),
        ),
        functionAnchor('settings_sheet_codes', sheetCodeSettingsPanel()),
        functionAnchor(
          'settings_oculum_shield',
          gothicPanel(
            borderColor: eyePupilGlowColor,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  t('Scudo Oculum', 'Oculum Shield'),
                  style: TextStyle(
                    color: eyePupilGlowColor,
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 6),
                smallInfoText(
                  t(
                    'Controlla se la sezione dello Scudo Oculum resta visibile anche quando non hai buff o valore.',
                    'Controls whether the Oculum Shield section stays visible even without a buff or value.',
                  ),
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  value: mostraSempreScudoOculum,
                  activeThumbColor: eyePupilGlowColor,
                  title: Text(
                    t('Mostra anche senza buff', 'Show even without buff'),
                  ),
                  subtitle: Text(
                    t(
                      'Se spento compare solo quando hai Scudo Oculum o @ScudoOculum attivo.',
                      'When off, it appears only when you have Oculum Shield or active @ScudoOculum.',
                    ),
                  ),
                  onChanged: (value) {
                    setState(() {
                      mostraSempreScudoOculum = value;
                      risultato = value
                          ? t(
                              'Scudo Oculum sempre visibile.',
                              'Oculum Shield always visible.',
                            )
                          : t(
                              'Scudo Oculum visibile solo quando presente.',
                              'Oculum Shield visible only when present.',
                            );
                      aggiungiLog(risultato);
                    });
                    programmaSalvataggio();
                  },
                ),
              ],
            ),
          ),
        ),

        gothicPanel(
          borderColor: primaryColor,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                t('Layout Scheda', 'Sheet Layout'),
                style: TextStyle(
                  color: primaryColor,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              smallInfoText(
                t(
                  'Ripristina tendine, pannelli rapidi e menu laterale senza toccare personaggio, titoli, skill o inventario.',
                  'Restore dropdowns, quick panels and side menu without touching character, titles, skills or inventory.',
                ),
              ),
              const SizedBox(height: 12),
              ElevatedButton.icon(
                onPressed: resetSheetLayoutSettings,
                icon: const Icon(Icons.dashboard_customize),
                style: ElevatedButton.styleFrom(
                  backgroundColor: primaryColor,
                  foregroundColor: primaryColor.computeLuminance() > 0.45
                      ? Colors.black
                      : Colors.white,
                ),
                label: Text(t('Reset layout scheda', 'Reset sheet layout')),
              ),
            ],
          ),
        ),

        gothicPanel(
          borderColor: tertiaryColor,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                t('Aspetto e modalita', 'Appearance and modes'),
                style: TextStyle(
                  color: tertiaryColor,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              smallInfoText(
                t(
                  'Attiva o nascondi sezioni ripetute. Le funzioni restano disponibili dai menù a tendina.',
                  'Enable or hide repeated sections. Features remain available from dropdown menus.',
                ),
              ),
              if (currentThemeVisualIdentity()
                      .mainSheetGuiStyle
                      .sheetLayoutId ==
                  '__legacy_old_school_toggle__')
                SwitchListTile(
                  value: modalitaVeloce,
                  activeThumbColor: tertiaryColor,
                  title: Text(t('Modalità veloce', 'Fast mode')),
                  subtitle: Text(
                    t(
                      'Mostra prima azioni essenziali e nasconde dettagli duplicati nella Scheda.',
                      'Shows essential actions first and hides duplicated details on the Sheet.',
                    ),
                  ),
                  onChanged: (value) {
                    setState(() => modalitaVeloce = value);
                    programmaSalvataggio();
                  },
                ),
              SwitchListTile(
                value: temiOldSchool,
                activeThumbColor: tertiaryColor,
                secondary: const Icon(Icons.history_edu),
                title: Text(t('Temi old school', 'Old-school themes')),
                subtitle: Text(
                  t(
                    'Ripristina il sistema grafico precedente senza perdere colori, temi o personalizzazioni già salvate.',
                    'Restores the previous visual system without losing saved colors, themes or customizations.',
                  ),
                ),
                onChanged: (value) {
                  setState(() {
                    temiOldSchool = value;
                    risultato = value
                        ? t(
                            'Mod Temi old school attivata.',
                            'Old-school Themes mod enabled.',
                          )
                        : t(
                            'Nuovo design Oculum attivato.',
                            'New Oculum design enabled.',
                          );
                    aggiungiLog(risultato);
                  });
                  programmaSalvataggio();
                },
              ),
              if (!temiOldSchool)
                DropdownButtonFormField<String>(
                  initialValue:
                      const <String>{
                        'cattedrale',
                        'manoscritto',
                        'ferro_battuto',
                        'pergamena_nera',
                        'vetro_arcano',
                        'sigillo_rituale',
                      }.contains(nuovoDesignOculum)
                      ? nuovoDesignOculum
                      : 'cattedrale',
                  decoration: fieldDecoration(
                    t('Design Oculum', 'Oculum design'),
                    helper: t(
                      'Sei sistemi coordinati; cambiano superfici, bordi e profondità senza modificare dati o funzioni.',
                      'Six coordinated systems; they change surfaces, borders and depth without modifying data or features.',
                    ),
                  ),
                  items: const [
                    DropdownMenuItem(
                      value: 'cattedrale',
                      child: Text('Cattedrale d’Ossidiana'),
                    ),
                    DropdownMenuItem(
                      value: 'manoscritto',
                      child: Text('Manoscritto Proibito'),
                    ),
                    DropdownMenuItem(
                      value: 'ferro_battuto',
                      child: Text('Ferro Battuto'),
                    ),
                    DropdownMenuItem(
                      value: 'pergamena_nera',
                      child: Text('Pergamena Nera'),
                    ),
                    DropdownMenuItem(
                      value: 'vetro_arcano',
                      child: Text('Vetro Arcano'),
                    ),
                    DropdownMenuItem(
                      value: 'sigillo_rituale',
                      child: Text('Sigillo Rituale'),
                    ),
                  ],
                  onChanged: (value) {
                    setState(() => nuovoDesignOculum = value ?? 'cattedrale');
                    programmaSalvataggio();
                  },
                ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                initialValue:
                    const <String>{
                      'leggibile',
                      'gotico',
                      'manoscritto',
                      'pergamena',
                      'arcano',
                      'rune',
                    }.contains(stileCarattereApp)
                    ? stileCarattereApp
                    : 'leggibile',
                isExpanded: true,
                decoration: fieldDecoration(
                  t('Stile dei caratteri', 'Typeface style'),
                  helper: t(
                    'Cambia i caratteri in tutta l app. I numeri e i controlli restano leggibili anche nelle finestre strette.',
                    'Changes type across the app. Numbers and controls remain readable in narrow windows.',
                  ),
                ),
                items: [
                  DropdownMenuItem(
                    value: 'leggibile',
                    child: Text(t('Leggibile moderno', 'Modern readable')),
                  ),
                  const DropdownMenuItem(
                    value: 'gotico',
                    child: Text('Gotico inciso'),
                  ),
                  const DropdownMenuItem(
                    value: 'manoscritto',
                    child: Text('Manoscritto antico'),
                  ),
                  const DropdownMenuItem(
                    value: 'pergamena',
                    child: Text('Pergamena classica'),
                  ),
                  const DropdownMenuItem(
                    value: 'arcano',
                    child: Text('Arcano elegante'),
                  ),
                  const DropdownMenuItem(
                    value: 'rune',
                    child: Text('Rune tecniche'),
                  ),
                ],
                onChanged: (value) {
                  setState(() => stileCarattereApp = value ?? 'leggibile');
                  programmaSalvataggio();
                },
              ),
              const SizedBox(height: 12),
              LayoutBuilder(
                builder: (context, constraints) {
                  final preview = gothicPanel(
                    borderColor: eyePupilGlowColor,
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          t('Esempio immediato', 'Live example'),
                          style: TextStyle(
                            color: eyePupilGlowColor,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        const SizedBox(height: 10),
                        oculumEyeHeartHealthMeter(
                          current: max(1, (maxHp() * 0.7).round()),
                          maximum: max(1, maxHp()),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          t(
                            'Le scelte cambiano solo l aspetto.',
                            'Choices change appearance only.',
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ],
                    ),
                  );
                  final selector = Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        t('Aspetto della Vita', 'Health appearance'),
                        style: TextStyle(
                          color: tertiaryColor,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      const SizedBox(height: 6),
                      smallInfoText(
                        t(
                          'Scegli dai pulsanti semitrasparenti: seguono il colore della scheda e mostrano subito la citazione scelta.',
                          'Choose from the translucent buttons: they follow the sheet color and immediately show the selected reference.',
                        ),
                      ),
                      const SizedBox(height: 10),
                      if (!modalitaVeloce)
                        OutlinedButton.icon(
                          onPressed: showLifeBarStyleGallery,
                          icon: const Icon(Icons.open_in_new_rounded),
                          label: Text(
                            '${t('Apri galleria Vita', 'Open health gallery')} · ${lifeBarStyleLabel(stileBarraVita)}',
                          ),
                        )
                      else
                        smallInfoText(
                          t(
                            'La galleria Vita è nascosta in modalità veloce.',
                            'The health gallery is hidden in fast mode.',
                          ),
                        ),
                      const SizedBox(height: 8),
                      TextButton.icon(
                        onPressed: stileBarraVita == 'base_dinamica'
                            ? null
                            : () {
                                setState(
                                  () => stileBarraVita = 'base_dinamica',
                                );
                                programmaSalvataggio();
                              },
                        icon: const Icon(Icons.restart_alt_rounded),
                        label: Text(
                          t(
                            'Ripristina Vita dinamica',
                            'Restore dynamic health',
                          ),
                        ),
                      ),
                    ],
                  );
                  if (constraints.maxWidth < 700) {
                    return Column(
                      children: [selector, const SizedBox(height: 12), preview],
                    );
                  }
                  return Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(child: selector),
                      const SizedBox(width: 14),
                      SizedBox(width: 330, child: preview),
                    ],
                  );
                },
              ),
              SwitchListTile(
                value: modalitaLeggera,
                activeThumbColor: tertiaryColor,
                title: Text(t('Modalita leggera', 'Lightweight mode')),
                subtitle: Text(
                  t(
                    'Riduce ombre, glow e spaziature pesanti senza nascondere funzioni.',
                    'Reduces heavy shadows, glow and spacing without hiding features.',
                  ),
                ),
                onChanged: (value) {
                  setState(() {
                    modalitaLeggera = value;
                    risultato = value
                        ? t(
                            'Modalita leggera attiva.',
                            'Lightweight mode enabled.',
                          )
                        : t(
                            'Modalita leggera spenta.',
                            'Lightweight mode disabled.',
                          );
                    aggiungiLog(risultato);
                  });
                  programmaSalvataggio();
                },
              ),
              SwitchListTile(
                value: modalitaMaster,
                activeThumbColor: tertiaryColor,
                title: Text(t('Modalita Master', 'Master Mode')),
                subtitle: Text(
                  t(
                    'Abilita permessi e strumenti Master locali. La sezione Sessione Master compare nella pagina Storia.',
                    'Enables local Master permissions and tools. The Master Session section appears on the Story page.',
                  ),
                ),
                onChanged: oculumStartupRole == OculumStartupRole.player
                    ? null
                    : (value) {
                        setState(() {
                          modalitaMaster = value;
                          risultato = value
                              ? t(
                                  'Modalita Master attiva.',
                                  'Master Mode enabled.',
                                )
                              : t(
                                  'Modalita Master spenta.',
                                  'Master Mode disabled.',
                                );
                          aggiungiLog(risultato);
                        });
                        programmaSalvataggio();
                      },
              ),
              SwitchListTile(
                value: usaBarraVita,
                activeThumbColor: tertiaryColor,
                title: Text(t('Vita come barra', 'HP as bar')),
                onChanged: (value) {
                  setState(() => usaBarraVita = value);
                  programmaSalvataggio();
                },
              ),
              SwitchListTile(
                value: mostraDannoCuraScheda,
                activeThumbColor: tertiaryColor,
                title: Text(t('Mostra Danno / Cura', 'Show Damage / Healing')),
                onChanged: (value) {
                  setState(() => mostraDannoCuraScheda = value);
                  programmaSalvataggio();
                },
              ),
              SwitchListTile(
                value: mostraSempreColpito,
                activeThumbColor: tertiaryColor,
                title: Text(t('Mostra sempre Colpito', 'Always show Hit')),
                subtitle: Text(
                  t(
                    'Invia al Master formula, totale e tipo danno; Vampirismo cura solo se la condizione e attiva.',
                    'Sends formula, total and damage type to the Master; Vampirism heals only while the condition is active.',
                  ),
                ),
                onChanged: (value) {
                  setState(() => mostraSempreColpito = value);
                  programmaSalvataggio();
                },
              ),
              SwitchListTile(
                value: mostraValoriEditabiliScheda,
                activeThumbColor: tertiaryColor,
                title: Text(
                  t('Valori principali a tendina', 'Main values dropdown'),
                ),
                onChanged: (value) {
                  setState(() => mostraValoriEditabiliScheda = value);
                  programmaSalvataggio();
                },
              ),
              SwitchListTile(
                value: scalaExpAutomatica,
                activeThumbColor: tertiaryColor,
                title: Text(
                  t('EXP scala automaticamente', 'EXP scales automatically'),
                ),
                subtitle: Text(
                  t(
                    'Quando aggiungi EXP, ogni 1000 viene sottratto e trasformato in livello. Spegnilo per tenere EXP grezza.',
                    'When you add EXP, each 1000 is subtracted and converted into a level. Turn it off to keep raw EXP.',
                  ),
                ),
                onChanged: (value) {
                  setState(() => scalaExpAutomatica = value);
                  programmaSalvataggio();
                },
              ),
              SwitchListTile(
                value: coMasterCanSetCoMaster,
                activeThumbColor: tertiaryColor,
                title: Text(
                  t(
                    'I Co-Master possono nominare altri Co-Master',
                    'Co-Masters can appoint other Co-Masters',
                  ),
                ),
                subtitle: Text(
                  t(
                    'Se abilitato, i Co-Master possono promuovere altri giocatori a Co-Master dalla pagina Online.',
                    'If enabled, Co-Masters can promote other players to Co-Master from the Online page.',
                  ),
                ),
                onChanged: (value) {
                  setState(() => coMasterCanSetCoMaster = value);
                  programmaSalvataggio();
                },
              ),
              SwitchListTile(
                value: masterKickRequiresConfirmation,
                activeThumbColor: tertiaryColor,
                title: Text(
                  t('Conferma prima di kickare', 'Confirm before kicking'),
                ),
                subtitle: Text(
                  t(
                    'Se disattivato, Kicka rimuove subito la scheda o il giocatore dalla campagna/sessione.',
                    'If disabled, Kick removes the sheet or player from the campaign/session immediately.',
                  ),
                ),
                onChanged: (value) {
                  setState(() => masterKickRequiresConfirmation = value);
                  programmaSalvataggio();
                },
              ),
              SwitchListTile(
                value: masterEnemyFullSheetVisibility,
                activeThumbColor: tertiaryColor,
                title: Text(
                  t(
                    'Mostra dettagli schede nemiche',
                    'Show enemy sheet details',
                  ),
                ),
                subtitle: Text(
                  t(
                    'Spento: agli altri arrivano solo immagine, lato token e iniziativa delle schede nemiche del Master.',
                    'Off: others receive only image, token side and initiative for the Master enemy sheets.',
                  ),
                ),
                onChanged: (value) {
                  setState(() {
                    masterEnemyFullSheetVisibility = value;
                    risultato = value
                        ? t(
                            'Dettagli nemici visibili nelle condivisioni Master.',
                            'Enemy details visible in Master shares.',
                          )
                        : t(
                            'Schede nemiche limitate a immagine e iniziativa.',
                            'Enemy sheets limited to image and initiative.',
                          );
                    aggiungiLog(risultato);
                  });
                  if (realtimeIsMasterRole) {
                    sendRealtimeMasterVisiblePartyTokens();
                  } else {
                    sendRealtimeCurrentSheetToStaff();
                  }
                  programmaSalvataggio();
                },
              ),
              SwitchListTile(
                value: masterPublicDiceVisible,
                activeThumbColor: tertiaryColor,
                title: Text(
                  t(
                    'Dadi Master visibili a tutti',
                    'Master dice visible to everyone',
                  ),
                ),
                subtitle: Text(
                  t(
                    'Se attivo, i tiri non-iniziativa del Master possono essere mandati in realtime dopo conferma.',
                    'When active, non-initiative Master rolls can be sent realtime after confirmation.',
                  ),
                ),
                onChanged: (value) async {
                  if (!value) {
                    setState(() {
                      masterPublicDiceVisible = false;
                      risultato = t(
                        'Dadi Master nascosti agli altri.',
                        'Master dice hidden from others.',
                      );
                      aggiungiLog(risultato);
                    });
                    programmaSalvataggio();
                    return;
                  }

                  final choice = await showDialog<String>(
                    context: context,
                    barrierDismissible: false,
                    builder: (context) {
                      return AlertDialog(
                        backgroundColor: const Color(0xFF10121A),
                        title: Text(
                          t(
                            'Dadi visibili a tutti?',
                            'Dice visible to everyone?',
                          ),
                          style: TextStyle(
                            color: tertiaryColor,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        content: Text(
                          t(
                            'Sei sicuro che vuoi che tutti vedano i dadi?',
                            'Are you sure you want everyone to see the dice?',
                          ),
                          style: const TextStyle(color: Colors.white),
                        ),
                        actions: [
                          TextButton(
                            onPressed: () => Navigator.pop(context, 'no'),
                            child: Text(t('No', 'No')),
                          ),
                          TextButton(
                            onPressed: () => Navigator.pop(context, 'yes'),
                            child: Text(t('Si', 'Yes')),
                          ),
                          ElevatedButton(
                            onPressed: () => Navigator.pop(context, 'never'),
                            child: Text(
                              t('Non chiedere piu', 'Do not ask again'),
                            ),
                          ),
                        ],
                      );
                    },
                  );

                  if (!context.mounted) return;
                  setState(() {
                    masterPublicDiceVisible =
                        choice == 'yes' || choice == 'never';
                    masterAskPublicDiceConfirmation = choice != 'never';
                    risultato = masterPublicDiceVisible
                        ? t(
                            'Dadi Master pubblici abilitati.',
                            'Public Master dice enabled.',
                          )
                        : t(
                            'Dadi Master rimasti nascosti.',
                            'Master dice stayed hidden.',
                          );
                    aggiungiLog(risultato);
                  });
                  programmaSalvataggio();
                },
              ),
              SwitchListTile(
                value: masterAskPublicDiceConfirmation,
                activeThumbColor: tertiaryColor,
                title: Text(
                  t('Chiedi prima del tiro pubblico', 'Ask before public roll'),
                ),
                subtitle: Text(
                  t(
                    'Riattiva la domanda prima che un tiro Master non-iniziativa sia visibile a tutti.',
                    'Turns the prompt back on before a non-initiative Master roll becomes visible to everyone.',
                  ),
                ),
                onChanged: (value) {
                  setState(() {
                    masterAskPublicDiceConfirmation = value;
                    risultato = value
                        ? t(
                            'Domanda dadi pubblici riattivata.',
                            'Public dice prompt restored.',
                          )
                        : t(
                            'Domanda dadi pubblici disattivata.',
                            'Public dice prompt disabled.',
                          );
                    aggiungiLog(risultato);
                  });
                  programmaSalvataggio();
                },
              ),
              SwitchListTile(
                value: sottraiStatsDaExpAggiunta,
                activeThumbColor: tertiaryColor,
                title: Text(
                  t(
                    'Sottrai stats dall’EXP aggiunta',
                    'Subtract stats from added EXP',
                  ),
                ),
                subtitle: Text(
                  t(
                    'Quando aggiungi EXP, Resilienza + Volontà + Materia + Oculum totali vengono sottratti dall’EXP realmente aggiunta.',
                    'When adding EXP, total Resilience + Will + Matter + Oculum are subtracted from the EXP actually added.',
                  ),
                ),
                onChanged: (value) {
                  setState(() => sottraiStatsDaExpAggiunta = value);
                  programmaSalvataggio();
                },
              ),
              SwitchListTile(
                value: mostraStrumentiManualeRapidi,
                activeThumbColor: tertiaryColor,
                title: Text(
                  t('Strumenti rapidi manuale', 'Manual quick tools'),
                ),
                onChanged: (value) {
                  setState(() => mostraStrumentiManualeRapidi = value);
                  programmaSalvataggio();
                },
              ),
              SwitchListTile(
                value: mostraBorsaCompatta,
                activeThumbColor: tertiaryColor,
                title: Text(t('Borsa rapida a tendina', 'Quick bag dropdown')),
                onChanged: (value) {
                  setState(() => mostraBorsaCompatta = value);
                  programmaSalvataggio();
                },
              ),
              SwitchListTile(
                value: mostraPartyScheda,
                activeThumbColor: tertiaryColor,
                title: Text(t('Sezione Party', 'Party section')),
                onChanged: (value) {
                  setState(() => mostraPartyScheda = value);
                  programmaSalvataggio();
                },
              ),
              SwitchListTile(
                value: mostraTastiRapidiIndice,
                activeThumbColor: tertiaryColor,
                title: Text(t('Tasti rapidi a indice', 'Quick index buttons')),
                onChanged: (value) {
                  setState(() => mostraTastiRapidiIndice = value);
                  programmaSalvataggio();
                },
              ),
            ],
          ),
        ),
        blockedOculumFriendsSettingsPanel(),
        gothicPanel(
          borderColor: modalitaDesktop ? tertiaryColor : primaryColor,
          child: SwitchListTile(
            value: modalitaDesktop,
            activeThumbColor: tertiaryColor,
            title: Text(
              t('Modalità Desktop', 'Desktop Mode'),
              style: TextStyle(
                color: modalitaDesktop ? tertiaryColor : primaryColor,
                fontWeight: FontWeight.bold,
              ),
            ),
            subtitle: Text(
              modalitaDesktop
                  ? t(
                      'Attiva: uso menu alto e nascondo la barra mobile in basso.',
                      'Enabled: using top menu and hiding the mobile bottom bar.',
                    )
                  : t(
                      'Disattiva: uso la barra mobile in basso.',
                      'Disabled: using the mobile bottom bar.',
                    ),
            ),
            onChanged: (value) {
              setState(() {
                modalitaDesktop = value;
                risultato = modalitaDesktop
                    ? t('Modalità Desktop attivata.', 'Desktop Mode enabled.')
                    : t('Modalità Mobile attivata.', 'Mobile Mode enabled.');

                aggiungiLog(risultato);
              });

              programmaSalvataggio();
            },
          ),
        ),
        gothicPanel(
          borderColor: primaryColor,
          child: SwitchListTile(
            value: linguaInglese,
            activeThumbColor: tertiaryColor,
            title: Text(
              t('Lingua', 'Language'),
              style: TextStyle(
                color: primaryColor,
                fontWeight: FontWeight.bold,
              ),
            ),
            subtitle: Text(
              linguaInglese
                  ? 'English enabled. Turn off to return to Italian.'
                  : 'Attiva per cambiare le scritte principali in inglese.',
            ),
            onChanged: (value) {
              setState(() {
                linguaInglese = value;
                risultato = linguaInglese
                    ? 'Choose a stat and roll the die.'
                    : 'Scegli una statistica e tira il dado.';
                aggiungiLog('Lingua cambiata: ${linguaInglese ? "EN" : "IT"}.');
              });
              programmaSalvataggio();
            },
          ),
        ),
        gothicPanel(
          borderColor: tertiaryColor,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                t('Tutorial', 'Tutorial'),
                style: TextStyle(
                  color: tertiaryColor,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              smallInfoText(
                t(
                  'Puoi riaprire il tutorial iniziale quando vuoi. Il setup ora parte da livello 0.',
                  'You can reopen the starting tutorial whenever you want. The setup now starts from level 0.',
                ),
              ),
              const SizedBox(height: 12),
              ElevatedButton.icon(
                onPressed: mostraTutorial,
                icon: const Icon(Icons.school),
                style: ElevatedButton.styleFrom(
                  backgroundColor: tertiaryColor,
                  foregroundColor: tertiaryColor.computeLuminance() > 0.45
                      ? Colors.black
                      : Colors.white,
                  minimumSize: const Size.fromHeight(46),
                ),
                label: Text(t('Apri Tutorial', 'Open Tutorial')),
              ),
            ],
          ),
        ),
        gothicPanel(
          borderColor: tertiaryColor,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                t('Scheda Colori', 'Color Sheet'),
                style: TextStyle(
                  color: tertiaryColor,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 10),
              smallInfoText(
                t(
                  'Ogni colore può essere scelto dalla palette oppure modificato con RGB, luminosità, saturazione e opacità. I primi tre colori restano quelli dell’occhio: il colore extra non cambia il disegno dell’occhio e serve come fallback per tipi danno nuovi o rilevati nei testi.',
                  'Each color can be chosen from the palette or edited with RGB, lightness, saturation and opacity. The first three colors remain the eye colors: the extra color does not change the eye artwork and is used as fallback for new or detected damage types.',
                ),
              ),
            ],
          ),
        ),
        colorPresetDropdownPanel(),
        elementColorsSettingsPanel(),
        colorPicker(
          titolo: t(
            'Colore Extra Occhio / Tipi Danno Nuovi',
            'Extra Eye Color / New Damage Types',
          ),
          selectedColor: eyeUtilityColor,
          filtro: filtroExtraOcchio,
          onFiltroChanged: (value) => filtroExtraOcchio = value,
          onSelected: (color) => eyeUtilityColor = color,
          editorAperto: mostraEditorExtraOcchio,
          onToggleEditor: () {
            setState(() {
              mostraEditorExtraOcchio = !mostraEditorExtraOcchio;
            });
          },
        ),
        if (mostraEditorExtraOcchio)
          advancedColorPanel(
            target: t('Extra occhio', 'Extra eye'),
            currentColor: eyeUtilityColor,
            onSelected: (color) => eyeUtilityColor = color,
          ),
        colorPicker(
          titolo: t(
            'Bagliore Pupilla / Centro Occhio',
            'Pupil Glow / Eye Center',
          ),
          selectedColor: eyePupilGlowColor,
          filtro: filtroAmbiente,
          onFiltroChanged: (value) => filtroAmbiente = value,
          onSelected: (color) => eyePupilGlowColor = color,
          editorAperto: mostraEditorPupilla,
          onToggleEditor: () {
            setState(() {
              mostraEditorPupilla = !mostraEditorPupilla;
            });
          },
        ),
        if (mostraEditorPupilla)
          advancedColorPanel(
            target: t('Bagliore pupilla', 'Pupil glow'),
            currentColor: eyePupilGlowColor,
            onSelected: (color) => eyePupilGlowColor = color,
          ),
        colorPicker(
          titolo: t('Sfondo Alto', 'Background Top'),
          selectedColor: backgroundTopColor,
          filtro: filtroAmbiente,
          onFiltroChanged: (value) => filtroAmbiente = value,
          onSelected: (color) => backgroundTopColor = color,
          editorAperto: mostraEditorSfondoAlto,
          onToggleEditor: () {
            setState(() {
              mostraEditorSfondoAlto = !mostraEditorSfondoAlto;
            });
          },
        ),
        if (mostraEditorSfondoAlto)
          advancedColorPanel(
            target: t('Sfondo alto', 'Background top'),
            currentColor: backgroundTopColor,
            onSelected: (color) => backgroundTopColor = color,
          ),
        colorPicker(
          titolo: t('Sfondo Centro', 'Background Center'),
          selectedColor: backgroundMidColor,
          filtro: filtroAmbiente,
          onFiltroChanged: (value) => filtroAmbiente = value,
          onSelected: (color) => backgroundMidColor = color,
          editorAperto: mostraEditorSfondoMedio,
          onToggleEditor: () {
            setState(() {
              mostraEditorSfondoMedio = !mostraEditorSfondoMedio;
            });
          },
        ),
        if (mostraEditorSfondoMedio)
          advancedColorPanel(
            target: t('Sfondo centro', 'Background center'),
            currentColor: backgroundMidColor,
            onSelected: (color) => backgroundMidColor = color,
          ),
        colorPicker(
          titolo: t('Sfondo Basso', 'Background Bottom'),
          selectedColor: backgroundBottomColor,
          filtro: filtroAmbiente,
          onFiltroChanged: (value) => filtroAmbiente = value,
          onSelected: (color) => backgroundBottomColor = color,
          editorAperto: mostraEditorSfondoBasso,
          onToggleEditor: () {
            setState(() {
              mostraEditorSfondoBasso = !mostraEditorSfondoBasso;
            });
          },
        ),
        if (mostraEditorSfondoBasso)
          advancedColorPanel(
            target: t('Sfondo basso', 'Background bottom'),
            currentColor: backgroundBottomColor,
            onSelected: (color) => backgroundBottomColor = color,
          ),
        colorPicker(
          titolo: t(
            'Colore Primario / Testi Magici',
            'Primary Color / Magical Text',
          ),
          selectedColor: primaryColor,
          filtro: filtroPrimario,
          onFiltroChanged: (value) => filtroPrimario = value,
          onSelected: (color) => primaryColor = color,
          editorAperto: mostraEditorPrimario,
          onToggleEditor: () {
            setState(() {
              mostraEditorPrimario = !mostraEditorPrimario;
            });
          },
        ),
        if (mostraEditorPrimario)
          advancedColorPanel(
            target: t('Primario', 'Primary'),
            currentColor: primaryColor,
            onSelected: (color) => primaryColor = color,
          ),
        colorPicker(
          titolo: t(
            'Colore Secondario / Fondi / Dadi',
            'Secondary Color / Backgrounds / Dice',
          ),
          selectedColor: secondaryColor,
          filtro: filtroSecondario,
          onFiltroChanged: (value) => filtroSecondario = value,
          onSelected: (color) => secondaryColor = color,
          editorAperto: mostraEditorSecondario,
          onToggleEditor: () {
            setState(() {
              mostraEditorSecondario = !mostraEditorSecondario;
            });
          },
        ),
        if (mostraEditorSecondario)
          advancedColorPanel(
            target: t('Secondario', 'Secondary'),
            currentColor: secondaryColor,
            onSelected: (color) => secondaryColor = color,
          ),
        colorPicker(
          titolo: t(
            'Colore Terziario / Open / Critici / Rituali',
            'Tertiary Color / Opens / Criticals / Rituals',
          ),
          selectedColor: tertiaryColor,
          filtro: filtroTerziario,
          onFiltroChanged: (value) => filtroTerziario = value,
          onSelected: (color) => tertiaryColor = color,
          editorAperto: mostraEditorTerziario,
          onToggleEditor: () {
            setState(() {
              mostraEditorTerziario = !mostraEditorTerziario;
            });
          },
        ),
        if (mostraEditorTerziario)
          advancedColorPanel(
            target: t('Terziario', 'Tertiary'),
            currentColor: tertiaryColor,
            onSelected: (color) => tertiaryColor = color,
          ),
        sectionTitle(t('Import / Export', 'Import / Export')),
        gothicPanel(
          borderColor: tertiaryColor,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                t('Backup Schede', 'Sheet Backup'),
                style: TextStyle(
                  color: tertiaryColor,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              smallInfoText(
                t(
                  'Esporta copia tutte le schede negli appunti in formato JSON. Importa permette di incollare quel JSON e ripristinare il salvataggio.',
                  'Export copies all sheets to the clipboard as JSON. Import lets you paste that JSON and restore the save.',
                ),
              ),
              const SizedBox(height: 14),
              ElevatedButton.icon(
                onPressed: esportaBackupNegliAppunti,
                icon: const Icon(Icons.download),
                style: ElevatedButton.styleFrom(
                  backgroundColor: tertiaryColor,
                  foregroundColor: tertiaryColor.computeLuminance() > 0.45
                      ? Colors.black
                      : Colors.white,
                  minimumSize: const Size.fromHeight(48),
                ),
                label: Text(t('Esporta Backup', 'Export Backup')),
              ),
              const SizedBox(height: 10),
              ElevatedButton.icon(
                onPressed: mostraDialogImportBackup,
                icon: const Icon(Icons.upload_file),
                style: ElevatedButton.styleFrom(
                  backgroundColor: secondaryColor,
                  foregroundColor: Colors.white,
                  minimumSize: const Size.fromHeight(48),
                ),
                label: Text(t('Importa Backup', 'Import Backup')),
              ),
            ],
          ),
        ),
        sectionTitle(t('Log Eventi', 'Event Log')),
        gothicPanel(
          borderColor: primaryColor,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ElevatedButton.icon(
                onPressed: pulisciLog,
                icon: const Icon(Icons.cleaning_services),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.redAccent.shade700,
                  foregroundColor: Colors.white,
                ),
                label: Text(t('Pulisci Log', 'Clear Log')),
              ),
              const SizedBox(height: 12),
              if (logEventi.isEmpty)
                Text(t('Nessun evento registrato.', 'No events recorded.'))
              else
                SizedBox(
                  height: min(360.0, max(72.0, logEventi.length * 30.0)),
                  child: ListView.builder(
                    key: const PageStorageKey<String>('event_log_lazy_list'),
                    itemCount: min(120, logEventi.length),
                    itemBuilder: (context, index) => Padding(
                      padding: const EdgeInsets.only(bottom: 6),
                      child: Text(
                        logEventi[index],
                        style: TextStyle(
                          color: Colors.grey.shade200,
                          fontSize: 12.5,
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ),
        sectionTitle(t('Anteprima Colori', 'Color Preview')),
        gothicPanel(
          borderColor: primaryColor,
          child: Column(
            children: [
              Text(
                'OCULUM',
                style: TextStyle(
                  color: primaryColor,
                  fontSize: 30,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 4,
                ),
              ),
              const SizedBox(height: 18),
              D20Widget(
                text: '20+8=28',
                fillColor: secondaryColor,
                textColor: primaryColor,
                glow: true,
                tertiaryColor: tertiaryColor,
              ),
            ],
          ),
        ),
        gothicPanel(
          borderColor: Colors.redAccent,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                t('Archivio salvataggio', 'Save Archive'),
                style: const TextStyle(
                  color: Colors.redAccent,
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                t(
                  'Non cancella nulla: archivia la campagna attuale e apre una nuova scheda vuota.',
                  'Nothing is deleted: it archives the current campaign and opens a new empty sheet.',
                ),
              ),
              const SizedBox(height: 12),
              ElevatedButton.icon(
                onPressed: cancellaSalvataggio,
                icon: const Icon(Icons.archive),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.redAccent.shade700,
                  foregroundColor: Colors.white,
                  minimumSize: const Size.fromHeight(48),
                ),
                label: Text(t('Archivia e riparti', 'Archive and restart')),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // =====================================================
}
