part of '../../main.dart';

// ignore_for_file: invalid_use_of_protected_member, unused_element

extension _OculumHomeSheetPage on _OculumHomePageState {
  // PANNELLI SCHEDA
  // =====================================================

  bool vitaAfonaAttiva() => hpCorrenti() > 0 && hasCondition('vita_afona');

  String hpReadoutProtetto() =>
      vitaAfonaAttiva() ? '☠' : '${hpCorrenti()}/${maxHp()}';

  String lifeBarStyleLabel(String id) {
    return switch (id) {
      'base_dinamica' => t('Vita dinamica', 'Dynamic health'),
      'fiamme_oculum' => t('Fiamme Oculum', 'Oculum flames'),
      'soulslike' => 'Soulslike',
      'action_rpg' => 'Action RPG',
      'jrpg_crystal' => 'JRPG Crystal',
      'survival_horror' => 'Survival Horror',
      'roguelite' => 'Roguelite',
      'oculum_eyes' => t('Cuori Occhio Oculum', 'Oculum Eye Hearts'),
      'oculum_alternativa' => t('Oculum alternativa', 'Oculum alternative'),
      _ => t('Gotico Oculum', 'Oculum Gothic'),
    };
  }

  Widget oculumEyeHeartHealthMeter({
    required int current,
    required int maximum,
    int incomingHealing = 0,
  }) {
    final ratio = maximum <= 0 ? 0.0 : (current / maximum).clamp(0.0, 1.0);
    final active = (ratio * 5).ceil().clamp(0, 5);
    final incoming = maximum <= 0
        ? 0
        : ((incomingHealing / maximum) * 5).ceil().clamp(0, 5 - active);
    return Semantics(
      label: 'HP ${(ratio * 100).round()}%',
      child: Column(
        children: [
          LayoutBuilder(
            builder: (context, constraints) {
              final iconSize = min(
                32.0,
                max(20.0, (constraints.maxWidth - 32) / 5),
              );
              return Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List<Widget>.generate(5, (index) {
                  final lit = index < active;
                  final incomingLit = !lit && index < active + incoming;
                  final color = lit
                      ? eyePupilGlowColor
                      : incomingLit
                      ? Color.lerp(eyePupilGlowColor, Colors.cyanAccent, .32)!
                      : Colors.blueGrey.shade800;
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 3),
                    child: SizedBox(
                      width: iconSize,
                      height: iconSize,
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          Icon(
                            lit || incomingLit
                                ? Icons.favorite
                                : Icons.favorite_border,
                            color: color,
                            size: iconSize,
                          ),
                          Icon(
                            lit || incomingLit
                                ? Icons.visibility
                                : Icons.visibility_off,
                            color: lit || incomingLit
                                ? Colors.white
                                : Colors.blueGrey.shade500,
                            size: iconSize * 0.42,
                          ),
                        ],
                      ),
                    ),
                  );
                }),
              );
            },
          ),
          const SizedBox(height: 6),
          Text(
            'HP $current/$maximum · ${(ratio * 100).round()}%',
            style: TextStyle(
              color: eyePupilGlowColor,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }

  Widget oculumFlameHealthMeter({
    required int current,
    required int maximum,
    int incomingHealing = 0,
  }) {
    final ratio = maximum <= 0 ? 0.0 : (current / maximum).clamp(0.0, 1.0);
    final active = (ratio * 5).ceil().clamp(0, 5);
    final incoming = maximum <= 0
        ? 0
        : ((incomingHealing / maximum) * 5).ceil().clamp(0, 5 - active);
    return Semantics(
      label: 'HP ${(ratio * 100).round()}%',
      child: Column(
        children: [
          LayoutBuilder(
            builder: (context, constraints) {
              final iconSize = min(
                34.0,
                max(20.0, (constraints.maxWidth - 32) / 5),
              );
              return Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(5, (index) {
                  final lit = index < active;
                  final incomingLit = !lit && index < active + incoming;
                  return Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 3),
                    child: Icon(
                      Icons.local_fire_department_rounded,
                      size: iconSize,
                      color: lit
                          ? eyePupilGlowColor
                          : incomingLit
                          ? Color.lerp(
                              eyePupilGlowColor,
                              Colors.cyanAccent,
                              .32,
                            )!
                          : Colors.blueGrey.shade800,
                      shadows: lit || incomingLit
                          ? [
                              Shadow(
                                color: tertiaryColor.withValues(alpha: 0.72),
                                blurRadius: 8,
                              ),
                            ]
                          : null,
                    ),
                  );
                }),
              );
            },
          ),
          const SizedBox(height: 5),
          Text(
            '$current / $maximum · ${(ratio * 100).round()}%',
            style: TextStyle(
              color: eyePupilGlowColor,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }

  IconData lifeBarStyleIcon(String id) {
    return switch (id) {
      'base_dinamica' => Icons.health_and_safety_outlined,
      'fiamme_oculum' => Icons.local_fire_department_rounded,
      'soulslike' => Icons.local_fire_department_outlined,
      'action_rpg' => Icons.flash_on_outlined,
      'jrpg_crystal' => Icons.diamond_outlined,
      'survival_horror' => Icons.warning_amber_rounded,
      'roguelite' => Icons.casino_outlined,
      'oculum_eyes' => Icons.visibility_outlined,
      'oculum_alternativa' => Icons.layers_outlined,
      _ => Icons.auto_awesome_outlined,
    };
  }

  Widget lifeBarStylePicker() {
    const styles = <String>[
      'base_dinamica',
      'fiamme_oculum',
      'gotico_oculum',
      'soulslike',
      'action_rpg',
      'jrpg_crystal',
      'survival_horror',
      'roguelite',
      'oculum_eyes',
      'oculum_alternativa',
    ];
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        for (final id in styles)
          Tooltip(
            message: t(
              'Citazione grafica: ${lifeBarStyleLabel(id)}',
              'Visual reference: ${lifeBarStyleLabel(id)}',
            ),
            child: InkWell(
              borderRadius: BorderRadius.circular(12),
              onTap: () {
                setState(() => stileBarraVita = id);
                programmaSalvataggio();
              },
              child: AnimatedContainer(
                duration: OculumDesignTokens.motionFast,
                padding: const EdgeInsets.symmetric(
                  horizontal: 11,
                  vertical: 9,
                ),
                decoration: BoxDecoration(
                  color: tertiaryColor.withValues(
                    alpha: stileBarraVita == id ? 0.28 : 0.09,
                  ),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: tertiaryColor.withValues(
                      alpha: stileBarraVita == id ? 0.95 : 0.38,
                    ),
                    width: stileBarraVita == id ? 1.5 : 1,
                  ),
                  boxShadow: stileBarraVita == id
                      ? [
                          BoxShadow(
                            color: tertiaryColor.withValues(alpha: 0.18),
                            blurRadius: 10,
                          ),
                        ]
                      : const [],
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(lifeBarStyleIcon(id), size: 17, color: tertiaryColor),
                    const SizedBox(width: 7),
                    Text(
                      lifeBarStyleLabel(id),
                      style: TextStyle(
                        color: stileBarraVita == id
                            ? Colors.white
                            : tertiaryColor,
                        fontWeight: FontWeight.w800,
                        fontSize: 12,
                      ),
                    ),
                    if (stileBarraVita == id) ...[
                      const SizedBox(width: 6),
                      const Icon(Icons.check_circle, size: 15),
                    ],
                  ],
                ),
              ),
            ),
          ),
      ],
    );
  }

  Future<void> showLifeBarStyleGallery() async {
    if (modalitaVeloce) return;
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Row(
          children: [
            Icon(Icons.favorite_rounded, color: tertiaryColor),
            const SizedBox(width: 8),
            Expanded(child: Text(t('Stile della Vita', 'Health style'))),
          ],
        ),
        content: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 620, maxHeight: 470),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                smallInfoText(
                  t(
                    'Scegli una rappresentazione. Cambia soltanto l aspetto e non modifica HP, scudi o salvataggi.',
                    'Choose a representation. It only changes appearance and does not modify HP, shields, or saves.',
                  ),
                ),
                const SizedBox(height: 12),
                lifeBarStylePicker(),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: Text(t('Chiudi', 'Close')),
          ),
        ],
      ),
    );
  }

  Future<void> showLifeBarContextMenuAt(Offset position) async {
    if (modalitaVeloce) return;
    final choice = await showMenu<String>(
      context: context,
      position: RelativeRect.fromLTRB(
        position.dx,
        position.dy,
        position.dx,
        position.dy,
      ),
      items: [
        PopupMenuItem<String>(
          value: 'style',
          child: ListTile(
            dense: true,
            leading: Icon(Icons.palette_outlined, color: tertiaryColor),
            title: Text(t('Stile...', 'Style...')),
            subtitle: Text(lifeBarStyleLabel(stileBarraVita)),
          ),
        ),
        if (conditionsAffecting(OculumConditionTarget.hp).isNotEmpty)
          PopupMenuItem<String>(
            value: 'conditions',
            child: ListTile(
              dense: true,
              leading: Icon(Icons.bolt, color: tertiaryColor),
              title: Text(t('Effetti condizioni', 'Condition effects')),
              subtitle: Text(
                '${conditionsAffecting(OculumConditionTarget.hp).length}',
              ),
            ),
          ),
      ],
    );
    if (choice == 'style' && mounted) await showLifeBarStyleGallery();
    if (choice == 'conditions' && mounted && !vitaAfonaAttiva()) {
      await showConditionImpactDialog(
        target: OculumConditionTarget.hp,
        baseValue: '${hpCorrenti()}/${maxHp()}',
        temporaryValue: '+${hpTemp()}',
        finalValue: '${vitaTotaleVisuale()}',
      );
    }
  }

  Widget lifeBarWithStyleContextMenu() {
    return conditionTargetScope(
      target: OculumConditionTarget.hp,
      builder: () {
        final rawBar = stileBarraVita == 'oculum_alternativa'
            ? stackedVitalsHudPanel()
            : lifeBar();
        final vitaAfona = vitaAfonaAttiva();
        final bar = Stack(
          children: [
            rawBar,
            if (!vitaAfona)
              Positioned(
                top: 4,
                right: 4,
                child: conditionImpactIndicator(
                  target: OculumConditionTarget.hp,
                  baseValue: '${hpCorrenti()}/${maxHp()}',
                  temporaryValue: '+${hpTemp()}',
                  finalValue: '${vitaTotaleVisuale()}',
                ),
              ),
          ],
        );
        if (modalitaVeloce) return bar;
        return GestureDetector(
          behavior: HitTestBehavior.translucent,
          onSecondaryTapDown: (details) =>
              showLifeBarContextMenuAt(details.globalPosition),
          onLongPressStart: (details) =>
              showLifeBarContextMenuAt(details.globalPosition),
          child: bar,
        );
      },
    );
  }

  List<Color> lifeBarGradient(String style, Color hpColor) {
    return switch (style) {
      'base_dinamica' => [hpColor.withValues(alpha: 0.72), hpColor],
      'soulslike' => const [Color(0xFF4B0D12), Color(0xFFB7262E)],
      'action_rpg' => const [Color(0xFF0C7F64), Color(0xFF62F2B6)],
      'jrpg_crystal' => const [Color(0xFF2355B8), Color(0xFFA4E9FF)],
      'survival_horror' => const [Color(0xFF5D6714), Color(0xFFCFDA38)],
      'roguelite' => const [Color(0xFF8E296F), Color(0xFFFF7BC2)],
      'fiamme_oculum' => [
        const Color(0xFF24104A),
        tertiaryColor,
        eyePupilGlowColor,
      ],
      _ => [const Color(0xFF66172B), hpColor, const Color(0xFFC89B3C)],
    };
  }

  Widget lifeBarIdentityOverlay({
    required String style,
    required double height,
  }) {
    switch (style) {
      case 'base_dinamica':
        return const Positioned.fill(child: IgnorePointer());
      case 'soulslike':
        return Positioned.fill(
          child: IgnorePointer(
            child: DecoratedBox(
              decoration: BoxDecoration(
                border: Border.symmetric(
                  horizontal: BorderSide(
                    color: const Color(0xFFD7B36A).withValues(alpha: 0.72),
                  ),
                ),
              ),
            ),
          ),
        );
      case 'action_rpg':
        return Positioned.fill(
          child: IgnorePointer(
            child: Row(
              children: List.generate(
                24,
                (index) => Expanded(
                  child: Container(
                    decoration: BoxDecoration(
                      border: Border(
                        right: BorderSide(
                          color: const Color(0xFF090B12),
                          width: 1.6,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      case 'jrpg_crystal':
        return Positioned.fill(
          child: IgnorePointer(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: List.generate(
                7,
                (_) => Transform.rotate(
                  angle: 0.78,
                  child: Container(
                    width: height * 0.30,
                    height: height * 0.30,
                    decoration: BoxDecoration(
                      border: Border.all(
                        color: Colors.white.withValues(alpha: 0.38),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        );
      case 'survival_horror':
        return Positioned.fill(
          child: IgnorePointer(
            child: Center(
              child: Row(
                children: [
                  const SizedBox(width: 10),
                  Icon(
                    Icons.monitor_heart_outlined,
                    size: height * 0.82,
                    color: Colors.white.withValues(alpha: 0.60),
                  ),
                  Expanded(
                    child: Container(
                      height: 1,
                      color: Colors.white.withValues(alpha: 0.26),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      case 'roguelite':
        return Positioned.fill(
          child: IgnorePointer(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: List.generate(
                10,
                (index) => Icon(
                  index.isEven ? Icons.circle : Icons.change_history,
                  size: height * 0.28,
                  color: Colors.white.withValues(alpha: 0.42),
                ),
              ),
            ),
          ),
        );
      case 'fiamme_oculum':
        return Positioned.fill(
          child: IgnorePointer(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: List.generate(
                10,
                (_) => Icon(
                  Icons.local_fire_department_rounded,
                  size: height * 0.58,
                  color: eyePupilGlowColor.withValues(alpha: 0.78),
                  shadows: [
                    Shadow(
                      color: tertiaryColor.withValues(alpha: 0.72),
                      blurRadius: 6,
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      default:
        return Positioned.fill(
          child: IgnorePointer(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Icon(Icons.church_outlined, size: height, color: primaryColor),
                Icon(
                  Icons.visibility_outlined,
                  size: height * 0.72,
                  color: Colors.white.withValues(alpha: 0.38),
                ),
                Icon(Icons.church_outlined, size: height, color: primaryColor),
              ],
            ),
          ),
        );
    }
  }

  Widget lifeBar() {
    final maxHpVal = maxHp();
    final curr = hpCorrenti();
    final incomingHealing = vitalMemoryPendingHealing();
    final temp = hpTemp();
    final shield = scudo();
    final oculumShield = scudoOculum();
    final oculumShieldMax = scudoOculumMax();
    final criticalShield = scudoCritico();
    final totalVisual = max(
      0,
      maxHpVal + temp + shield + oculumShield + criticalShield,
    );

    final hpW = totalVisual <= 0 ? 0.0 : (curr / totalVisual).clamp(0.0, 1.0);
    final incomingW = totalVisual <= 0
        ? 0.0
        : (min(incomingHealing, max(0, maxHpVal - curr)) / totalVisual).clamp(
            0.0,
            1.0,
          );
    final tempW = totalVisual <= 0 ? 0.0 : (temp / totalVisual).clamp(0.0, 1.0);
    final shieldW = totalVisual <= 0
        ? 0.0
        : (shield / totalVisual).clamp(0.0, 1.0);
    final oculumShieldW = totalVisual <= 0
        ? 0.0
        : (oculumShield / totalVisual).clamp(0.0, 1.0);
    final criticalShieldW = totalVisual <= 0
        ? 0.0
        : (criticalShield / totalVisual).clamp(0.0, 1.0);
    final showOculumShield = shouldShowScudoOculum();

    Color hpColor;
    final pureHpRatio = maxHpVal <= 0 ? 0 : curr / maxHpVal;

    if (pureHpRatio > 0.75) {
      hpColor = const Color(0xFF2ECC71);
    } else if (pureHpRatio > 0.5) {
      hpColor = const Color(0xFFF1C40F);
    } else if (pureHpRatio > 0.3) {
      hpColor = const Color(0xFFFF8C22);
    } else if (pureHpRatio > 0.15) {
      hpColor = const Color(0xFFE53935);
    } else {
      hpColor = const Color(0xFF6D1028);
    }

    final barHeight = switch (stileBarraVita) {
      'soulslike' => 22.0,
      'action_rpg' => 14.0,
      'fiamme_oculum' => 30.0,
      'jrpg_crystal' => 28.0,
      'survival_horror' => 18.0,
      'roguelite' => 30.0,
      _ => 34.0,
    };
    final barRadius = switch (stileBarraVita) {
      'soulslike' || 'survival_horror' => 3.0,
      'action_rpg' => 2.0,
      'jrpg_crystal' => 16.0,
      'roguelite' => 7.0,
      _ => 12.0,
    };
    final emptyColor = switch (stileBarraVita) {
      'soulslike' => const Color(0xFF140B0B),
      'jrpg_crystal' => const Color(0xFF11172A),
      'survival_horror' => const Color(0xFF151815),
      'roguelite' => const Color(0xFF211329),
      _ => const Color(0xFF240C14),
    };
    final narrowLifeBar = barHeight <= 22;
    final lifeBarValueText = showOculumShield
        ? 'HP $curr/$maxHpVal  T $temp  S $shield  SO $oculumShield/$oculumShieldMax  SC $criticalShield'
        : 'HP $curr/$maxHpVal  T $temp  S $shield  SC $criticalShield';
    final vitaAfona =
        curr > 0 &&
        activeConditions.any(
          (condition) => condition.conditionType == 'vita_afona',
        );

    if (vitaAfona) {
      return gothicPanel(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              t('Barra della Vita', 'Health Bar'),
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: primaryColor,
                letterSpacing: 0.8,
              ),
            ),
            const SizedBox(height: 10),
            Semantics(
              label: t(
                'Vita Afona attiva: HP attuali nascosti',
                'Voiceless Life active: current HP hidden',
              ),
              child: Container(
                height: 42,
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.black,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.white24),
                ),
                child: const Center(
                  child: Text(
                    '☠',
                    style: TextStyle(color: Colors.white, fontSize: 27),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 7),
            Text(
              t(
                'Vita Afona: gli HP restano sconosciuti finché l effetto termina o muori.',
                'Voiceless Life: HP remain unknown until the effect ends or you die.',
              ),
              textAlign: TextAlign.center,
              style: TextStyle(
                color: tertiaryColor,
                fontWeight: FontWeight.w800,
              ),
            ),
          ],
        ),
      );
    }

    return gothicPanel(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '${t('Barra della Vita', 'Health Bar')} · ${lifeBarStyleLabel(stileBarraVita)}',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: primaryColor,
              letterSpacing: 0.8,
            ),
          ),
          if (personaggioSvenuto) ...[
            const SizedBox(height: 8),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
              decoration: BoxDecoration(
                color: Colors.redAccent.withValues(alpha: 0.22),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.redAccent),
              ),
              child: Text(
                t('INCOSCIENTE', 'UNCONSCIOUS'),
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 0,
                ),
              ),
            ),
          ],
          const SizedBox(height: 8),
          if (!modalitaVeloce) ...[
            guidedExplanation(
              title: t('Come leggere la vita', 'How to read health'),
              explanation: t(
                'Gli HP sono la tua vita. Gli HP temporanei sono vita in prestito. Gli scudi proteggono gli HP: quando subisci danno, l app usa prima lo Scudo Oculum e poi le altre protezioni.',
                'HP is your life. Temporary HP is borrowed life. Shields protect HP: when you take damage, the app uses Oculum Shield first and then the other protections.',
              ),
              example: t(
                'Esempio: hai 10 HP e 3 Scudo. Un colpo da 4 consuma lo Scudo e toglie soltanto 1 HP.',
                'Example: you have 10 HP and 3 Shield. A hit for 4 uses the Shield and removes only 1 HP.',
              ),
              icon: Icons.favorite_outline,
            ),
            const SizedBox(height: 12),
          ],
          if (stileBarraVita == 'oculum_eyes')
            oculumEyeHeartHealthMeter(
              current: curr,
              maximum: maxHpVal,
              incomingHealing: incomingHealing,
            )
          else if (stileBarraVita == 'fiamme_oculum')
            oculumFlameHealthMeter(
              current: curr,
              maximum: maxHpVal,
              incomingHealing: incomingHealing,
            )
          else ...[
            if (narrowLifeBar) ...[
              Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  lifeBarValueText,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: tertiaryColor,
                    fontSize: 11,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
              const SizedBox(height: 5),
            ],
            ClipRRect(
              borderRadius: BorderRadius.circular(barRadius),
              child: Stack(
                children: [
                  Container(height: barHeight, color: emptyColor),
                  FractionallySizedBox(
                    widthFactor: hpW,
                    child: Container(
                      height: 34,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: lifeBarGradient(stileBarraVita, hpColor),
                        ),
                      ),
                    ),
                  ),
                  if (incomingW > 0)
                    FractionallySizedBox(
                      widthFactor: (hpW + incomingW).clamp(0.0, 1.0),
                      child: Align(
                        alignment: Alignment.centerRight,
                        child: FractionallySizedBox(
                          widthFactor: incomingW / (hpW + incomingW),
                          child: Container(
                            height: barHeight,
                            color: Color.lerp(
                              hpColor,
                              Colors.cyanAccent,
                              .32,
                            )!.withValues(alpha: 0.72),
                          ),
                        ),
                      ),
                    ),
                  FractionallySizedBox(
                    widthFactor: (hpW + tempW).clamp(0.0, 1.0),
                    child: Align(
                      alignment: Alignment.centerRight,
                      child: FractionallySizedBox(
                        widthFactor: tempW <= 0 ? 0 : tempW / (hpW + tempW),
                        child: Container(
                          height: barHeight,
                          color: Colors.greenAccent.withValues(alpha: 0.55),
                        ),
                      ),
                    ),
                  ),
                  FractionallySizedBox(
                    widthFactor: (hpW + tempW + shieldW).clamp(0.0, 1.0),
                    child: Align(
                      alignment: Alignment.centerRight,
                      child: FractionallySizedBox(
                        widthFactor: shieldW <= 0
                            ? 0
                            : shieldW / (hpW + tempW + shieldW),
                        child: Container(
                          height: barHeight,
                          color: tertiaryColor.withValues(alpha: 0.82),
                        ),
                      ),
                    ),
                  ),
                  if (showOculumShield)
                    FractionallySizedBox(
                      widthFactor: (hpW + tempW + shieldW + oculumShieldW)
                          .clamp(0.0, 1.0),
                      child: Align(
                        alignment: Alignment.centerRight,
                        child: FractionallySizedBox(
                          widthFactor: oculumShieldW <= 0
                              ? 0
                              : oculumShieldW /
                                    (hpW + tempW + shieldW + oculumShieldW),
                          child: Container(
                            height: barHeight,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  primaryColor.withValues(alpha: 0.62),
                                  eyePupilGlowColor.withValues(alpha: 0.88),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  FractionallySizedBox(
                    widthFactor:
                        (hpW +
                                tempW +
                                shieldW +
                                (showOculumShield ? oculumShieldW : 0) +
                                criticalShieldW)
                            .clamp(0.0, 1.0),
                    child: Align(
                      alignment: Alignment.centerRight,
                      child: FractionallySizedBox(
                        widthFactor: criticalShieldW <= 0
                            ? 0
                            : criticalShieldW /
                                  (hpW +
                                      tempW +
                                      shieldW +
                                      (showOculumShield ? oculumShieldW : 0) +
                                      criticalShieldW),
                        child: Container(
                          height: barHeight,
                          color: Colors.white.withValues(alpha: 0.48),
                        ),
                      ),
                    ),
                  ),
                  lifeBarIdentityOverlay(
                    style: stileBarraVita,
                    height: barHeight,
                  ),
                  if (!narrowLifeBar)
                    Positioned.fill(
                      child: Center(
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 8),
                          child: FittedBox(
                            fit: BoxFit.scaleDown,
                            child: DecoratedBox(
                              decoration: BoxDecoration(
                                color: Colors.black.withValues(alpha: 0.46),
                                borderRadius: BorderRadius.circular(999),
                              ),
                              child: Padding(
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 10,
                                  vertical: 3,
                                ),
                                child: Text(
                                  lifeBarValueText,
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: Colors.white,
                                    shadows: [
                                      Shadow(
                                        color: Colors.black,
                                        blurRadius: 5,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget savingShieldPanel({bool dense = false}) {
    final active = scudoSalvataggioAttivo;
    return gothicPanel(
      borderColor: active ? Colors.lightBlueAccent : tertiaryColor,
      padding: EdgeInsets.all(dense ? 8 : 10),
      child: Row(
        children: [
          Icon(
            active ? Icons.shield : Icons.shield_outlined,
            color: active ? Colors.lightBlueAccent : tertiaryColor,
            size: dense ? 18 : 22,
          ),
          SizedBox(width: dense ? 7 : 9),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  t('Scudo di Salvataggio', 'Saving Shield'),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: active ? Colors.lightBlueAccent : tertiaryColor,
                    fontWeight: FontWeight.w900,
                    fontSize: dense ? 13 : 15,
                  ),
                ),
                const SizedBox(height: 3),
                smallInfoText(
                  t(
                    'Azione gratuita: blocca l’overflow quando l’ultimo scudo si rompe.',
                    'Free action: blocks overflow when the last shield breaks.',
                  ),
                  color: active ? Colors.lightBlueAccent : Colors.grey.shade300,
                ),
              ],
            ),
          ),
          Switch(
            value: active,
            activeThumbColor: Colors.lightBlueAccent,
            onChanged: (value) {
              if (value) {
                attivaScudoSalvataggio();
              } else {
                setState(() {
                  scudoSalvataggioAttivo = false;
                  risultato = t(
                    'Scudo di Salvataggio disattivato.',
                    'Saving Shield disabled.',
                  );
                  aggiungiLog(risultato);
                });
                programmaSalvataggio();
              }
            },
          ),
        ],
      ),
    );
  }

  Widget stackedVitalsHudPanel({bool dense = false, bool embedded = false}) {
    final maxHpVal = max(0, maxHp());
    final currentHp = max(0, hpCorrenti());
    final incomingHealing = vitalMemoryPendingHealing();
    final tempHp = max(0, hpTemp());
    final shield = max(0, scudo());
    final shieldDisplayTarget = max(shield, scudoRefullTarget());
    final shieldRatioTarget = max(1, shieldDisplayTarget);
    final oculumShield = max(0, scudoOculum());
    final oculumShieldMax = max(0, scudoOculumMax());
    final oculumShieldDisplayTarget = max(oculumShield, oculumShieldMax);
    final oculumShieldRatioTarget = max(1, oculumShieldDisplayTarget);
    final lines = <Widget>[];
    final vitaAfona = vitaAfonaAttiva();

    Widget gaugeLine({
      required String label,
      required String value,
      required double ratio,
      required Color color,
      required IconData icon,
    }) {
      final safeRatio = ratio.clamp(0.0, 1.0).toDouble();
      return Padding(
        padding: EdgeInsets.only(bottom: dense ? 7 : 9),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: color, size: dense ? 13 : 15),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    cleanUiText(label),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: color,
                      fontSize: dense ? 10.5 : 12,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
                Text(
                  value,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: readableOnTheme(Colors.white),
                    fontSize: dense ? 10.5 : 12,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 4),
            ClipRRect(
              borderRadius: BorderRadius.circular(999),
              child: LinearProgressIndicator(
                value: safeRatio,
                minHeight: dense ? 5 : 7,
                color: color,
                backgroundColor: Colors.black.withValues(alpha: 0.56),
              ),
            ),
          ],
        ),
      );
    }

    lines.add(
      gaugeLine(
        label: 'HP',
        value: vitaAfona ? '☠' : '$currentHp/${max(1, maxHpVal)}',
        ratio: vitaAfona ? 0 : currentHp / max(1, maxHpVal),
        color: vitaAfona ? Colors.black : Colors.redAccent,
        icon: vitaAfona ? Icons.dangerous_rounded : Icons.favorite,
      ),
    );
    if (tempHp > 0) {
      lines.add(
        gaugeLine(
          label: 'HP Temp',
          value: '$tempHp/${max(1, maxHpVal)}',
          ratio: tempHp / max(1, maxHpVal),
          color: Colors.greenAccent,
          icon: Icons.favorite_border,
        ),
      );
    }
    if (incomingHealing > 0) {
      lines.add(
        Padding(
          padding: EdgeInsets.only(bottom: dense ? 7 : 9),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(999),
            child: LinearProgressIndicator(
              value: (incomingHealing / max(1, maxHpVal)).clamp(0.0, 1.0),
              minHeight: dense ? 3 : 4,
              color: Color.lerp(Colors.redAccent, Colors.cyanAccent, .32)!,
              backgroundColor: Colors.transparent,
            ),
          ),
        ),
      );
    }
    lines
      ..add(
        gaugeLine(
          label: t('Scudo', 'Shield'),
          value: '$shield/$shieldDisplayTarget',
          ratio: shield / shieldRatioTarget,
          color: Colors.lightBlueAccent,
          icon: Icons.shield,
        ),
      )
      ..add(
        gaugeLine(
          label: t('Scudo Oculum', 'Oculum Shield'),
          value: '$oculumShield/$oculumShieldDisplayTarget',
          ratio: oculumShield / oculumShieldRatioTarget,
          color: eyePupilGlowColor,
          icon: Icons.visibility,
        ),
      );

    final shell = Container(
      constraints: BoxConstraints(minWidth: dense ? 230 : 280),
      padding: EdgeInsets.fromLTRB(
        dense ? 10 : 12,
        dense ? 9 : 12,
        dense ? 10 : 12,
        2,
      ),
      decoration: BoxDecoration(
        color: Color.lerp(
          secondaryColor,
          backgroundBottomColor,
          0.45,
        )!.withValues(alpha: embedded ? 0.62 : 0.48),
        borderRadius: BorderRadius.circular(
          themeFieldRadiusValue(compact: dense),
        ),
        border: Border.all(
          color: eyePupilGlowColor.withValues(alpha: embedded ? 0.46 : 0.68),
          width: themePanelBorderWidth(compact: dense) * 0.84,
        ),
        boxShadow: embedded
            ? const <BoxShadow>[]
            : [
                BoxShadow(
                  color: eyePupilGlowColor.withValues(alpha: 0.12),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                Icons.stacked_line_chart,
                color: eyePupilGlowColor,
                size: dense ? 15 : 18,
              ),
              const SizedBox(width: 7),
              Expanded(
                child: Text(
                  t('Vitali a percentuale', 'Percentage vitals'),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: eyePupilGlowColor,
                    fontSize: dense ? 12 : 15,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ],
          ),
          if (personaggioSvenuto) ...[
            SizedBox(height: dense ? 6 : 8),
            Container(
              width: double.infinity,
              padding: EdgeInsets.symmetric(
                horizontal: dense ? 8 : 10,
                vertical: dense ? 5 : 7,
              ),
              decoration: BoxDecoration(
                color: Colors.redAccent.withValues(alpha: 0.22),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.redAccent),
              ),
              child: Text(
                t('INCOSCIENTE', 'UNCONSCIOUS'),
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w900,
                  fontSize: dense ? 11 : 13,
                  letterSpacing: 0,
                ),
              ),
            ),
          ],
          SizedBox(height: dense ? 7 : 10),
          ...lines,
        ],
      ),
    );

    if (embedded) return shell;
    return gothicPanel(
      borderColor: eyePupilGlowColor,
      padding: EdgeInsets.zero,
      child: shell,
    );
  }

  Widget oculumShieldPanel() {
    if (!shouldShowScudoOculum()) return const SizedBox.shrink();

    Widget shieldCell({required String label, required Widget child}) {
      final conditionTarget = conditionTargetForUiLabel(label);
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 2, bottom: 4),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    cleanUiText(label),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: eyePupilGlowColor,
                      fontSize: uiScale(11),
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
                if (conditionTarget != null)
                  conditionImpactIndicator(target: conditionTarget),
              ],
            ),
          ),
          Container(
            height: phoneCompactUi ? 34 : 38,
            alignment: Alignment.center,
            clipBehavior: Clip.antiAlias,
            padding: const EdgeInsets.symmetric(horizontal: 8),
            decoration: BoxDecoration(
              color: Colors.black.withValues(alpha: 0.48),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: eyePupilGlowColor.withValues(alpha: 0.58),
              ),
            ),
            child: child,
          ),
        ],
      );
    }

    Widget shieldNumberField({
      required String label,
      required TextEditingController controller,
      VoidCallback? onEdited,
    }) {
      Future<void> editValue() async {
        final temp = TextEditingController(text: controller.text);
        try {
          await showDialog<void>(
            context: context,
            builder: (dialogContext) {
              return AlertDialog(
                backgroundColor: const Color(0xFF10121A),
                title: Text(
                  cleanUiText(label),
                  style: TextStyle(
                    color: eyePupilGlowColor,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                content: TextField(
                  controller: temp,
                  autofocus: true,
                  keyboardType: TextInputType.number,
                  textAlign: TextAlign.center,
                  cursorColor: eyePupilGlowColor,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.w900,
                  ),
                  decoration: fieldDecoration(t('Valore', 'Value')),
                ),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.pop(dialogContext),
                    child: Text(t('Annulla', 'Cancel')),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      controller.text = max(
                        0,
                        readIntValue(temp.text),
                      ).toString();
                      onEdited?.call();
                      if (mounted) setState(() {});
                      programmaSalvataggio();
                      Navigator.pop(dialogContext);
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: eyePupilGlowColor,
                      foregroundColor:
                          eyePupilGlowColor.computeLuminance() > 0.45
                          ? Colors.black
                          : Colors.white,
                    ),
                    child: Text(t('Salva', 'Save')),
                  ),
                ],
              );
            },
          );
        } finally {
          temp.dispose();
        }
      }

      return shieldCell(
        label: label,
        child: Tooltip(
          message: t('Tocca per modificare', 'Tap to edit'),
          child: InkWell(
            onTap: editValue,
            borderRadius: BorderRadius.circular(8),
            child: SizedBox.expand(
              child: Center(
                child: Text(
                  '${max(0, readIntValue(controller.text))}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: uiScale(15),
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ),
          ),
        ),
      );
    }

    void clampScudoOculumToMax() {
      final maximum = scudoOculumMax();
      final current = max(0, readIntValue(scudoOculumController.text));
      if (maximum <= 0) {
        scudoOculumController.text = '0';
      } else if (current > maximum) {
        scudoOculumController.text = maximum.toString();
      }
    }

    Widget shieldValueField({
      required String label,
      required String value,
      String? helper,
    }) {
      return shieldCell(
        label: label,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              value,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: Colors.white,
                fontSize: uiScale(15),
                fontWeight: FontWeight.w900,
              ),
            ),
            if (helper != null && helper.trim().isNotEmpty) ...[
              const SizedBox(height: 2),
              Text(
                cleanUiText(helper),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: Colors.grey.shade400,
                  fontSize: uiScale(9.5),
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ],
        ),
      );
    }

    Widget roundShieldButton({
      required IconData icon,
      required String tooltip,
      required VoidCallback onPressed,
    }) {
      final buttonColor =
          Color.lerp(tertiaryColor, const Color(0xFFC18435), 0.78) ??
          tertiaryColor;
      final foreground = buttonColor.computeLuminance() > 0.45
          ? Colors.black
          : Colors.white;
      final size = phoneCompactUi ? 34.0 : 36.0;

      return Tooltip(
        message: cleanUiText(tooltip),
        child: GestureDetector(
          onTap: onPressed,
          behavior: HitTestBehavior.opaque,
          child: Container(
            width: size,
            height: size,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: buttonColor,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: buttonColor.withValues(alpha: 0.2),
                  blurRadius: 7,
                ),
              ],
            ),
            child: Icon(
              icon,
              size: phoneCompactUi ? 18 : 19,
              color: foreground,
            ),
          ),
        ),
      );
    }

    return gothicPanel(
      borderColor: eyePupilGlowColor,
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.visibility, color: eyePupilGlowColor, size: 18),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  t('Scudo Oculum', 'Oculum Shield'),
                  style: TextStyle(
                    color: eyePupilGlowColor,
                    fontWeight: FontWeight.w900,
                    fontSize: uiScale(15),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          LayoutBuilder(
            builder: (context, constraints) {
              final compact = constraints.maxWidth < 430;
              final currentField = shieldNumberField(
                label: t('Attuale', 'Current'),
                controller: scudoOculumController,
                onEdited: () {
                  final current = max(
                    0,
                    readIntValue(scudoOculumController.text),
                  );
                  final maximum = scudoOculumMax();
                  if (current > maximum) {
                    final bonus = scudoOculumBonusMassimo();
                    scudoOculumMaxController.text = max(
                      0,
                      current - bonus,
                    ).toString();
                  }
                },
              );
              final manualMaxField = shieldNumberField(
                label: t('Max manuale', 'Manual max'),
                controller: scudoOculumMaxController,
                onEdited: clampScudoOculumToMax,
              );
              final maxField = shieldValueField(
                label: t('Totale', 'Total'),
                value: scudoOculumMax().toString(),
                helper: scudoOculumBonusMassimo() == 0
                    ? null
                    : '${t('Buff', 'Buff')} ${scudoOculumBonusMassimo() >= 0 ? '+' : ''}${scudoOculumBonusMassimo()}',
              );

              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(child: currentField),
                      SizedBox(width: compact ? 8 : 10),
                      Expanded(child: manualMaxField),
                      SizedBox(width: compact ? 8 : 10),
                      Expanded(child: maxField),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      roundShieldButton(
                        icon: Icons.remove_circle_outline,
                        tooltip: t('-1 Scudo Oculum', '-1 Oculum Shield'),
                        onPressed: () {
                          setState(() {
                            modificaScudoOculum(-1);
                            risultato = t(
                              'Scudo Oculum -1: ${scudoOculum()}/${scudoOculumMax()}.',
                              'Oculum Shield -1: ${scudoOculum()}/${scudoOculumMax()}.',
                            );
                            aggiungiLog(risultato);
                          });
                          programmaSalvataggio();
                        },
                      ),
                      const SizedBox(width: 8),
                      roundShieldButton(
                        icon: Icons.add_circle_outline,
                        tooltip: t('+1 Scudo Oculum', '+1 Oculum Shield'),
                        onPressed: () {
                          setState(() {
                            modificaScudoOculum(1);
                            risultato = t(
                              'Scudo Oculum +1: ${scudoOculum()}/${scudoOculumMax()}.',
                              'Oculum Shield +1: ${scudoOculum()}/${scudoOculumMax()}.',
                            );
                            aggiungiLog(risultato);
                          });
                          programmaSalvataggio();
                        },
                      ),
                      const SizedBox(width: 8),
                      roundShieldButton(
                        icon: Icons.refresh,
                        tooltip: t(
                          'Ricarica Scudo Oculum',
                          'Recharge Oculum Shield',
                        ),
                        onPressed: () {
                          setState(() {
                            ricaricaScudoOculum();
                            risultato = t(
                              'Scudo Oculum ricaricato: ${scudoOculum()}/${scudoOculumMax()}.',
                              'Oculum Shield recharged: ${scudoOculum()}/${scudoOculumMax()}.',
                            );
                            aggiungiLog(risultato);
                          });
                          programmaSalvataggio();
                        },
                      ),
                    ],
                  ),
                ],
              );
            },
          ),
        ],
      ),
    );
  }

  Widget campoStatAttualeVisibile({
    required String key,
    required String label,
    String? helper,
    TextEditingController? controller,
    FocusNode? focusNode,
  }) {
    syncVisibleCurrentStatEditor(key);
    return campoTesto(
      label: label,
      controller: controller ?? visibleCurrentStatController(key),
      helper: helper,
      focusNode: focusNode,
      onChanged: (value) => setCurrentStatFromVisibleInput(key, value),
    );
  }

  Widget oculumResourcePanel() {
    return ValueListenableBuilder<int>(
      valueListenable: oculumResourceRevision,
      builder: (context, revision, child) => _oculumResourcePanelContent(),
    );
  }

  Widget _oculumResourcePanelContent() {
    final massimo = oculumMassimo();
    // This panel is the player-facing source of truth.  Keep its sleep lock
    // explicit instead of relying on a derived value that can be rebuilt by a
    // parser/cache while the state is toggled.
    final sleeping = oculumAddormentato;
    final current = sleeping ? 0 : oculumTotale();
    // `normalCurrentOculum` may be negative internally to account for an
    // already-consumed runtime bonus. It is never a meaningful player-facing
    // resource amount.
    final normalCurrent = sleeping ? 0 : max(0, normalCurrentOculum());
    final temporaryCurrent = max(0, temporaryOculum);
    final ratio = sleeping ? 0.0 : oculumRatio();
    final meterColor = ratio > 0.66
        ? tertiaryColor
        : ratio > 0.33
        ? primaryColor
        : Colors.redAccent;

    return gothicPanel(
      borderColor: meterColor,
      padding: const EdgeInsets.all(12),
      child: LayoutBuilder(
        builder: (context, constraints) {
          final compact = constraints.maxWidth < 520;

          final activeFlames = (ratio * 10).ceil().clamp(0, 10);
          final eyeSize = compact ? 86.0 : 108.0;
          final flameRadius = compact ? 32.0 : 42.0;
          final eye = Semantics(
            label:
                'Oculum $current su $massimo, ${(ratio * 100).round()} percento',
            child: SizedBox(
              width: eyeSize,
              height: eyeSize,
              child: Stack(
                alignment: Alignment.center,
                children: [
                  for (var index = 0; index < 10; index++)
                    Transform.translate(
                      offset: Offset(
                        cos(-pi / 2 + index * 2 * pi / 10) * flameRadius,
                        sin(-pi / 2 + index * 2 * pi / 10) * flameRadius,
                      ),
                      child: Icon(
                        Icons.local_fire_department_rounded,
                        size: compact ? 15 : 18,
                        color: index < activeFlames
                            ? eyePupilGlowColor
                            : Colors.blueGrey.shade800,
                        shadows: index < activeFlames
                            ? [
                                Shadow(
                                  color: eyePupilGlowColor.withValues(
                                    alpha: 0.7,
                                  ),
                                  blurRadius: 8,
                                ),
                              ]
                            : null,
                      ),
                    ),
                  Opacity(
                    opacity: (0.22 + ratio * 0.78).clamp(0.22, 1.0),
                    child: Image.asset(
                      'assets/icon/oculum_eye.png',
                      width: compact ? 42 : 54,
                      height: compact ? 42 : 54,
                      cacheWidth: oculumImageCacheDimension(
                        context,
                        compact ? 42 : 54,
                        max: 192,
                      ),
                      cacheHeight: oculumImageCacheDimension(
                        context,
                        compact ? 42 : 54,
                        max: 192,
                      ),
                      fit: BoxFit.contain,
                      errorBuilder: (context, error, stackTrace) => Icon(
                        Icons.visibility,
                        color: meterColor,
                        size: compact ? 38 : 50,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );

          final controls = Wrap(
            spacing: 8,
            runSpacing: 8,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              IconButton.filledTonal(
                tooltip: '-1 Oculum',
                onPressed: sleeping ? null : () => modificaOculumAttuale(-1),
                icon: const Icon(Icons.remove),
              ),
              IconButton.filledTonal(
                tooltip: '+1 Oculum',
                onPressed: sleeping ? null : () => modificaOculumAttuale(1),
                icon: const Icon(Icons.add),
              ),
              IconButton.filledTonal(
                tooltip: t('Reset al massimo', 'Reset to max'),
                onPressed: sleeping ? null : resetOculumAttuale,
                icon: const Icon(Icons.restart_alt),
              ),
            ],
          );

          final content = Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                sleeping
                    ? t(
                        'Oculum dormiente 0/$massimo',
                        'Sleeping Oculum 0/$massimo',
                      )
                    : temporaryCurrent > 0
                    ? 'Oculum $current · $normalCurrent + ${temporaryCurrent}T / $massimo'
                    : 'Oculum $current/$massimo',
                style: TextStyle(
                  color: meterColor,
                  fontSize: compact ? 17 : 20,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 8),
              ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: LinearProgressIndicator(
                  value: ratio,
                  minHeight: 12,
                  color: meterColor,
                  backgroundColor: Colors.black45,
                ),
              ),
              const SizedBox(height: 10),
              campoStatAttualeVisibile(
                label: t('Oculum attuale', 'Current Oculum'),
                key: 'oculum',
                controller: oculumPanelCurrentController,
                focusNode: oculumPanelCurrentFocusNode,
                helper: t(
                  temporaryCurrent > 0
                      ? 'Totale $current: $normalCurrent normale + $temporaryCurrent temporaneo. Il temporaneo termina dopo $temporaryOculumRollsRemaining tiri validi. I buff restano separati e non modificano la base.'
                      : 'Totale $current: $normalCurrent normale. I buff restano separati e non modificano la base.',
                  temporaryCurrent > 0
                      ? 'Total $current: $normalCurrent normal + $temporaryCurrent temporary. Temporary Oculum ends after $temporaryOculumRollsRemaining valid rolls. Buffs stay separate and do not change the base.'
                      : 'Total $current: $normalCurrent normal. Buffs stay separate and do not change the base.',
                ),
              ),
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: oculumAddormentato
                      ? Colors.indigo.withValues(alpha: 0.20)
                      : Colors.black.withValues(alpha: 0.18),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: oculumAddormentato
                        ? Colors.indigoAccent
                        : primaryColor.withValues(alpha: 0.35),
                  ),
                ),
                child: Row(
                  children: [
                    Icon(
                      oculumAddormentato
                          ? Icons.visibility_off
                          : Icons.visibility,
                      color: oculumAddormentato
                          ? Colors.indigoAccent
                          : primaryColor,
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        oculumAddormentato
                            ? t(
                                'Oculum addormentato: ogni guadagno è dimezzato per difetto.',
                                'Sleeping Oculum: every gain is halved and rounded down.',
                              )
                            : t(
                                'Oculum sveglio: i recuperi hanno valore pieno.',
                                'Awake Oculum: recovery has full value.',
                              ),
                        maxLines: compact ? 4 : 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    const SizedBox(width: 8),
                    if (compact)
                      IconButton.filledTonal(
                        tooltip: oculumAddormentato
                            ? t('Risveglia Oculum', 'Wake Oculum')
                            : t('Addormenta Oculum', 'Put Oculum to sleep'),
                        onPressed: oculumAddormentato
                            ? confermaRisvegliaOculum
                            : attivaOculumAddormentato,
                        icon: Icon(
                          oculumAddormentato
                              ? Icons.wb_sunny_outlined
                              : Icons.bedtime_outlined,
                        ),
                      )
                    else
                      FilledButton.icon(
                        onPressed: oculumAddormentato
                            ? confermaRisvegliaOculum
                            : attivaOculumAddormentato,
                        icon: Icon(
                          oculumAddormentato
                              ? Icons.wb_sunny_outlined
                              : Icons.bedtime_outlined,
                        ),
                        label: Text(
                          oculumAddormentato
                              ? t('Risveglia', 'Wake')
                              : t('Addormenta', 'Sleep'),
                        ),
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 8),
              SwitchListTile.adaptive(
                contentPadding: const EdgeInsets.symmetric(horizontal: 8),
                value: consumoElevato,
                secondary: const Icon(Icons.local_fire_department_outlined),
                title: Text(t('Consumo elevato', 'High consumption')),
                subtitle: Text(
                  t(
                    'Solo quando è attivo, ogni tiro valido consuma 1 punto della statistica collegata.',
                    'Only while active, every valid roll consumes 1 point from its linked stat.',
                  ),
                ),
                onChanged: (value) {
                  setState(() {
                    consumoElevato = value;
                    risultato = value
                        ? t(
                            'Consumo elevato attivato.',
                            'High consumption activated.',
                          )
                        : t(
                            'Consumo elevato disattivato.',
                            'High consumption deactivated.',
                          );
                    aggiungiLog(risultato);
                  });
                  programmaSalvataggio();
                },
              ),
              if (!modalitaVeloce) ...[
                const SizedBox(height: 6),
                guidedExplanation(
                  title: t(
                    'Questi sono stati speciali',
                    'These are special states',
                  ),
                  explanation: t(
                    'Addormentato azzera subito l Oculum e dimezza soltanto quello che recuperi. Si risveglia dopo 2 riposi lunghi oppure 2 brevi e 1 lungo. I tiri non consumano statistiche salvo Consumo elevato o le eccezioni speciali indicate.',
                    'Sleeping clears current Oculum immediately and halves only what you recover. It wakes after 2 long rests or 2 short rests and 1 long rest. Rolls do not consume stats unless High Consumption is active or a stated special exception applies.',
                  ),
                  example: t(
                    'Esempio: recuperi 7 Oculum mentre dorme, quindi ne ricevi 3.',
                    'Example: you recover 7 Oculum while it sleeps, so you receive 3.',
                  ),
                  icon: Icons.visibility_off_outlined,
                ),
              ],
              const SizedBox(height: 10),
              controls,
            ],
          );

          if (compact) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(child: eye),
                const SizedBox(height: 10),
                content,
              ],
            );
          }

          return Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              eye,
              const SizedBox(width: 14),
              Expanded(child: content),
            ],
          );
        },
      ),
    );
  }

  void attivaOculumAddormentato() {
    if (oculumAddormentato) return;
    setState(() {
      attivaStatoOculumAddormentato();
      risultato = t(
        'Oculum addormentato attivato: Oculum attuale azzerato e guadagni dimezzati per difetto.',
        'Sleeping Oculum activated: current Oculum cleared and gains halved, rounded down.',
      );
      aggiungiLog(risultato);
    });
    notifyConditionsChanged(<OculumConditionTarget>{
      OculumConditionTarget.oculum,
      OculumConditionTarget.recupero,
    });
    programmaSalvataggio();
  }

  Future<void> confermaRisvegliaOculum() async {
    if (!oculumAddormentato) return;
    final conferma = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: const Color(0xFF10121A),
        title: Text(t('Risveglia Oculum', 'Wake Oculum')),
        content: Text(
          t(
            'Vuoi togliere la condizione Oculum addormentato? I valori attuali, temporanei e massimi resteranno invariati.',
            'Remove the Sleeping Oculum condition? Current, temporary, and maximum values will remain unchanged.',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: Text(t('Annulla', 'Cancel')),
          ),
          FilledButton.icon(
            onPressed: () => Navigator.pop(dialogContext, true),
            icon: const Icon(Icons.wb_sunny_outlined),
            label: Text(t('Risveglia Oculum', 'Wake Oculum')),
          ),
        ],
      ),
    );
    if (conferma != true || !mounted) return;
    setState(() {
      risvegliaStatoOculumAddormentato();
      risultato = t(
        'Oculum risvegliato: valori attuali, temporanei e massimi invariati.',
        'Oculum awakened: current, temporary, and maximum values unchanged.',
      );
      aggiungiLog(risultato);
    });
    notifyConditionsChanged(<OculumConditionTarget>{
      OculumConditionTarget.oculum,
      OculumConditionTarget.recupero,
    });
    recordCurrentOculumProgress(immediate: true);
    programmaSalvataggio();
  }

  String razzaVisibile() {
    final manualRace = cleanUiText(razzaController.text).trim();
    if (manualRace.isNotEmpty) return manualRace;

    for (final tratto in trattiRazziali) {
      final nome = cleanUiText(tratto.nome).trim();
      if (nome.isNotEmpty) return nome;
    }

    return t('Razza non impostata', 'Race not set');
  }

  Widget raceIdentityPanel() {
    return gothicPanel(
      borderColor: const Color(0xFF7EE7C8),
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.diversity_3, color: Color(0xFF7EE7C8)),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  '${t('Razza visibile', 'Visible race')}: ${razzaVisibile()}',
                  style: const TextStyle(
                    color: Color(0xFF7EE7C8),
                    fontWeight: FontWeight.w900,
                    fontSize: 16,
                  ),
                ),
              ),
              Text(
                '${trattiRazziali.length}/13',
                style: TextStyle(
                  color: primaryColor,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
          if (!phoneCompactUi && !modalitaVeloce) ...[
            const SizedBox(height: 8),
            smallInfoText(
              t(
                'Se il campo resta vuoto, la Scheda mostra come Razza il primo Tratto razziale inserito nella pagina Titoli.',
                'If this field stays empty, the Sheet shows the first Racial Trait inserted on the Titles page as Race.',
              ),
            ),
          ],
          const SizedBox(height: 8),
          campoTesto(
            label: t('Razza / Linea di sangue', 'Race / Bloodline'),
            controller: razzaController,
            numero: false,
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final tratto in trattiRazziali.take(5))
                Chip(
                  label: Text(cleanUiText(tratto.nome)),
                  avatar: Icon(
                    tratto.equipaggiato
                        ? Icons.check_circle
                        : Icons.radio_button_unchecked,
                    size: 18,
                  ),
                  backgroundColor: const Color(0xFF10121A),
                  labelStyle: TextStyle(color: primaryColor),
                  side: BorderSide(
                    color: tratto.equipaggiato
                        ? const Color(0xFF7EE7C8)
                        : primaryColor.withValues(alpha: 0.35),
                  ),
                ),
              ActionChip(
                avatar: const Icon(Icons.edit, size: 18),
                label: Text(t('Modifica tratti', 'Edit traits')),
                backgroundColor: secondaryColor,
                labelStyle: TextStyle(color: primaryColor),
                side: BorderSide(color: tertiaryColor.withValues(alpha: 0.5)),
                onPressed: () => vaiAllaFunzione(
                  page: 2,
                  anchorId: 'titles_racial_traits',
                  logTitle: t('Tratti razziali', 'Racial traits'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget oculumEyeBox() {
    return gothicPanel(
      padding: const EdgeInsets.all(10),
      child: LayoutBuilder(
        builder: (context, constraints) {
          final width = constraints.maxWidth.isFinite
              ? constraints.maxWidth
              : MediaQuery.of(context).size.width;
          final compact = width < 520 || lightweightUi;
          final eyeWidth = compact ? width : min(width, 380.0);
          final eyeHeight = (eyeWidth * 0.56).clamp(
            compact ? 128.0 : 210.0,
            compact ? 205.0 : 280.0,
          );
          final radius = compact ? 18.0 : 22.0;

          final imageCard = SizedBox(
            width: eyeWidth,
            height: eyeHeight,
            child: DecoratedBox(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(radius),
                color: Colors.black,
                border: Border.all(
                  color: primaryColor.withValues(alpha: 0.70),
                  width: 1.4,
                ),
                boxShadow: [
                  BoxShadow(
                    color: tertiaryColor.withValues(alpha: 0.12),
                    blurRadius: compact ? 8 : 14,
                    spreadRadius: 0.5,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(radius - 2),
                child: Stack(
                  children: [
                    Positioned.fill(
                      child: RepaintBoundary(
                        child: CustomPaint(
                          painter: OculumEyePainter(
                            primaryColor: primaryColor,
                            secondaryColor: secondaryColor,
                            tertiaryColor: tertiaryColor,
                            pupilGlowColor: eyePupilGlowColor,
                          ),
                        ),
                      ),
                    ),
                    if (immaginePersonaggio != null)
                      Positioned.fill(
                        child: Center(
                          // La pupilla deve restare quadrata anche nel
                          // pannello dell'occhio, che invece e' orizzontale.
                          // Un FractionallySizedBox qui la deformava.
                          child: SizedBox.square(
                            dimension: min(
                              eyeWidth * (compact ? 0.66 : 0.58),
                              eyeHeight * (compact ? 0.82 : 0.88),
                            ),
                            child: GestureDetector(
                              behavior: HitTestBehavior.opaque,
                              onSecondaryTap:
                                  copiaImmaginePersonaggioNegliAppunti,
                              onLongPress: mostraAzioniImmaginePersonaggio,
                              child: Tooltip(
                                message: t(
                                  'Tasto destro: copia. Pressione lunga: copia o scarica.',
                                  'Right-click: copy. Long press: copy or download.',
                                ),
                                child: ClipPath(
                                  // Il ritratto e' solo la pupilla: niente
                                  // cornice/card rettangolare attorno ad esso.
                                  clipper: const HexagonClipper(),
                                  child: SizedBox.expand(
                                    // Il clip riceve sempre una tela quadrata
                                    // esplicita: così non può degradare a un
                                    // rettangolo quando cambia il layout.
                                    child: FittedBox(
                                      fit: BoxFit.contain,
                                      alignment: Alignment.center,
                                      child: Image.memory(
                                        immaginePersonaggio!,
                                        filterQuality: FilterQuality.high,
                                        cacheWidth: max(
                                          1,
                                          (eyeWidth * 1.6).round(),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    Positioned(
                      top: compact ? 8 : 12,
                      right: compact ? 8 : 12,
                      child: Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: [
                          ElevatedButton.icon(
                            onPressed: scegliImmagine,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.black.withValues(
                                alpha: 0.72,
                              ),
                              foregroundColor: Colors.white,
                              padding: EdgeInsets.symmetric(
                                horizontal: compact ? 7 : 14,
                                vertical: compact ? 5 : 10,
                              ),
                            ),
                            icon: Icon(Icons.image, size: compact ? 15 : 20),
                            label: Text(compact ? '+' : t('Aggiungi', 'Add')),
                          ),
                          ElevatedButton.icon(
                            onPressed: incollaImmaginePersonaggioDaClipboard,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.black.withValues(
                                alpha: 0.72,
                              ),
                              foregroundColor: Colors.white,
                              padding: EdgeInsets.symmetric(
                                horizontal: compact ? 7 : 14,
                                vertical: compact ? 5 : 10,
                              ),
                            ),
                            icon: Icon(
                              Icons.content_paste,
                              size: compact ? 15 : 20,
                            ),
                            label: Text(
                              compact
                                  ? t('Incolla', 'Paste')
                                  : t('Incolla', 'Paste'),
                            ),
                          ),
                          if (immaginePersonaggio != null)
                            ElevatedButton.icon(
                              onPressed: copiaImmaginePersonaggioNegliAppunti,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.black.withValues(
                                  alpha: 0.72,
                                ),
                                foregroundColor: Colors.white,
                                padding: EdgeInsets.symmetric(
                                  horizontal: compact ? 7 : 14,
                                  vertical: compact ? 5 : 10,
                                ),
                              ),
                              icon: Icon(
                                Icons.content_copy,
                                size: compact ? 15 : 20,
                              ),
                              label: Text(compact ? '' : t('Copia', 'Copy')),
                            ),
                          if (immaginePersonaggio != null)
                            ElevatedButton.icon(
                              onPressed: rimuoviImmagine,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.redAccent.withValues(
                                  alpha: 0.88,
                                ),
                                foregroundColor: Colors.white,
                                padding: EdgeInsets.symmetric(
                                  horizontal: compact ? 7 : 14,
                                  vertical: compact ? 5 : 10,
                                ),
                              ),
                              icon: Icon(Icons.delete, size: compact ? 15 : 20),
                              label: Text(
                                compact ? 'X' : t('Rimuovi', 'Remove'),
                              ),
                            ),
                        ],
                      ),
                    ),
                    Positioned(
                      left: compact ? 10 : 0,
                      right: compact ? 10 : 0,
                      bottom: compact ? 10 : 14,
                      child: Center(
                        child: Container(
                          constraints: BoxConstraints(
                            maxWidth: max(180, eyeWidth - (compact ? 20 : 80)),
                          ),
                          padding: EdgeInsets.symmetric(
                            horizontal: compact ? 12 : 16,
                            vertical: compact ? 7 : 8,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.black.withValues(alpha: 0.62),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: tertiaryColor.withValues(alpha: 0.22),
                            ),
                          ),
                          child: FittedBox(
                            fit: BoxFit.scaleDown,
                            child: Text(
                              cleanUiText(
                                '${tipoSchedaController.text.toUpperCase()} • ${razzaVisibile()} • ${t('SCHEDA ${schedaCorrente + 1}/${schedePersonaggio.isEmpty ? 1 : schedePersonaggio.length}', 'SHEET ${schedaCorrente + 1}/${schedePersonaggio.isEmpty ? 1 : schedePersonaggio.length}')}',
                              ),
                              maxLines: 1,
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: compact ? 11 : 12,
                                letterSpacing: compact ? 1.3 : 2,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );

          return Focus(
            focusNode: imagePasteFocusNode,
            autofocus: true,
            onKeyEvent: (node, event) {
              if (event is! KeyDownEvent ||
                  event.logicalKey != LogicalKeyboardKey.keyV ||
                  (!HardwareKeyboard.instance.isControlPressed &&
                      !HardwareKeyboard.instance.isMetaPressed)) {
                return KeyEventResult.ignored;
              }

              unawaited(incollaImmaginePersonaggioDaClipboard());
              return KeyEventResult.handled;
            },
            child: DropTarget(
              onDragEntered: (_) {
                if (!mounted) return;
                imagePasteFocusNode.requestFocus();
                setState(() => imageDropActive = true);
              },
              onDragExited: (_) {
                if (!mounted) return;
                setState(() => imageDropActive = false);
              },
              onDragDone: (detail) async {
                if (!mounted) return;
                imagePasteFocusNode.requestFocus();
                setState(() => imageDropActive = false);

                if (detail.files.isEmpty) return;

                final file = detail.files.first;
                final fileName = file.name.trim();

                try {
                  final bytes = await file.readAsBytes();
                  await importaImmaginePersonaggioDaBytes(
                    bytes,
                    sourceName: fileName.isEmpty ? 'drop Windows' : fileName,
                  );
                } catch (error) {
                  if (!mounted) return;
                  setState(() {
                    risultato = t(
                      'File non importato: non ha sostituito l’immagine attuale.',
                      'File not imported: current image was not replaced.',
                    );
                    aggiungiLog('$risultato ($error)');
                  });
                }
              },
              child: GestureDetector(
                behavior: HitTestBehavior.opaque,
                onTap: imagePasteFocusNode.requestFocus,
                child: Center(
                  child: SizedBox(
                    width: eyeWidth,
                    height: eyeHeight,
                    child: Stack(
                      children: [
                        imageCard,
                        if (imageDropActive)
                          Positioned.fill(
                            child: IgnorePointer(
                              child: DecoratedBox(
                                decoration: BoxDecoration(
                                  color: Colors.black.withValues(alpha: 0.62),
                                  borderRadius: BorderRadius.circular(radius),
                                  border: Border.all(
                                    color: tertiaryColor,
                                    width: 2.2,
                                  ),
                                ),
                                child: Center(
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Icon(
                                        Icons.file_upload,
                                        color: tertiaryColor,
                                        size: compact ? 34 : 46,
                                      ),
                                      const SizedBox(height: 10),
                                      Text(
                                        t(
                                          'Rilascia qui l’immagine',
                                          'Drop the image here',
                                        ),
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                          color: Colors.white,
                                          fontSize: compact ? 15 : 18,
                                          fontWeight: FontWeight.w900,
                                        ),
                                      ),
                                      const SizedBox(height: 6),
                                      Text(
                                        t(
                                          'Il crop si aprirà senza cancellare quella precedente.',
                                          'Crop opens without deleting the previous image.',
                                        ),
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                          color: primaryColor,
                                          fontSize: compact ? 11 : 13,
                                          fontWeight: FontWeight.w700,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget quickLoreButtonsPanel() {
    return gothicPanel(
      borderColor: primaryColor,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            t('Strumenti rapidi del Manuale', 'Quick Manual Tools'),
            style: TextStyle(
              color: primaryColor,
              fontSize: 19,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          smallInfoText(
            t(
              'Parata Oculum attuale: ${oculumCurrentParryChancePercent(currentOculum: currentOculum(), difficulty: normalizedCampaignDifficulty()).toStringAsFixed(3)}% con ${currentOculum()} Oculum. Su Normale ogni punto fino a 5 vale 0,1%; dopo 5 ogni +0,1% richiede progressivamente più punti. Solo se pari, dispersione di 1 Oculum al ${oculumCurrentParryStrainChancePercent(currentOculum: currentOculum(), difficulty: normalizedCampaignDifficulty()).toStringAsFixed(2)}%; crescita protetta fino a 20 Oculum.',
              'Current Oculum parry: ${oculumCurrentParryChancePercent(currentOculum: currentOculum(), difficulty: normalizedCampaignDifficulty()).toStringAsFixed(3)}% with ${currentOculum()} Oculum. On Normal each point up to 5 is worth 0.1%; after 5 every +0.1% progressively requires more points. Only after a parry, 1 Oculum disperses at ${oculumCurrentParryStrainChancePercent(currentOculum: currentOculum(), difficulty: normalizedCampaignDifficulty()).toStringAsFixed(2)}%; growth is protected up to 20 Oculum.',
            ),
          ),
          const SizedBox(height: 8),
          smallInfoText(
            t(
              'Tasti rapidi per automatizzare piccole regole narrative di Oculum. Il Titolo del Fato non dipende dal livello personaggio: dipende dal livello delle Skill della prima Art.',
              'Quick buttons to automate small narrative rules of Oculum. The Fate Title does not depend on character level: it depends on the level of the Skills of the first Art.',
            ),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              ElevatedButton.icon(
                onPressed: creaPrimoTitoloDelFato,
                icon: const Icon(Icons.auto_awesome),
                style: ElevatedButton.styleFrom(
                  backgroundColor: tertiaryColor,
                  foregroundColor: tertiaryColor.computeLuminance() > 0.45
                      ? Colors.black
                      : Colors.white,
                ),
                label: const Text('Primo Titolo del Fato'),
              ),
              ElevatedButton.icon(
                onPressed: controllaTitoliDelFatoAutomatici,
                icon: const Icon(Icons.fact_check),
                style: ElevatedButton.styleFrom(
                  backgroundColor: secondaryColor,
                  foregroundColor: Colors.white,
                ),
                label: Text(
                  t('Controlla Titoli del Fato', 'Check Fate Titles'),
                ),
              ),
              ElevatedButton.icon(
                onPressed: randomizzaStatsBilanciate,
                icon: const Icon(Icons.casino),
                style: ElevatedButton.styleFrom(
                  backgroundColor: primaryColor,
                  foregroundColor: primaryColor.computeLuminance() > 0.45
                      ? Colors.black
                      : Colors.white,
                ),
                label: Text(t('Stats bilanciate', 'Balanced stats')),
              ),
              ElevatedButton.icon(
                onPressed: createRuneArtQuickly,
                icon: const Icon(Icons.auto_fix_high),
                style: ElevatedButton.styleFrom(
                  backgroundColor: secondaryColor,
                  foregroundColor: Colors.white,
                ),
                label: const Text('Rune Art'),
              ),
              ElevatedButton.icon(
                onPressed: learnRuneBookForSheet,
                icon: const Icon(Icons.menu_book),
                style: ElevatedButton.styleFrom(
                  backgroundColor: tertiaryColor,
                  foregroundColor: tertiaryColor.computeLuminance() > 0.45
                      ? Colors.black
                      : Colors.white,
                ),
                label: Text(t('Libro Runico +6', 'Runic Book +6')),
              ),
              ElevatedButton.icon(
                onPressed: openRuneQuickWordsDialog,
                icon: const Icon(Icons.tune),
                style: ElevatedButton.styleFrom(
                  backgroundColor: primaryColor,
                  foregroundColor: primaryColor.computeLuminance() > 0.45
                      ? Colors.black
                      : Colors.white,
                ),
                label: Text(t('Parole Rune', 'Rune Words')),
              ),
              ElevatedButton.icon(
                onPressed: openRuneCustomWordDialog,
                icon: const Icon(Icons.edit_square),
                style: ElevatedButton.styleFrom(
                  backgroundColor: secondaryColor,
                  foregroundColor: Colors.white,
                ),
                label: Text(t('Parola Master', 'Master Word')),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget experiencePanel() {
    return experiencePanelContent();
  }

  Widget experienceProgress() {
    return ValueListenableBuilder<int>(
      valueListenable: experienceRevision,
      builder: (context, revision, child) {
        oculumProgressProfileCount('expWidgetRebuilds');
        final exp = expCorrente();
        final expPerLivello = normalizedCampaignDifficulty() == 'oculum'
            ? 1369
            : 1000;
        final ratio = (exp / expPerLivello).clamp(0.0, 1.0);
        return RepaintBoundary(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '$exp / $expPerLivello',
                style: const TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.w900,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 10),
              ClipRRect(
                borderRadius: BorderRadius.circular(14),
                child: SizedBox(
                  height: 22,
                  child: ColoredBox(
                    color: Colors.black45,
                    child: Align(
                      alignment: Alignment.centerLeft,
                      child: FractionallySizedBox(
                        widthFactor: ratio,
                        heightFactor: 1,
                        child: ColoredBox(color: tertiaryColor),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget experiencePanelContent() {
    final expPerLivello = normalizedCampaignDifficulty() == 'oculum'
        ? 1369
        : 1000;
    final expName = expDisplayName();

    return gothicPanel(
      borderColor: tertiaryColor,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            expName,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: tertiaryColor,
              fontSize: 20,
              fontWeight: FontWeight.bold,
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 8),
          smallInfoText(
            t(
              'Ogni $expPerLivello $expName ottieni 1 livello. Nei Personaggi i livelli creano level up da assegnare; nei Mostri generano punti mostro.',
              'Every $expPerLivello $expName grants 1 level. For Characters, levels create level ups to assign; for Monsters, they generate monster points.',
            ),
          ),
          const SizedBox(height: 8),
          smallInfoText(
            t(
              'Allenamento: se perdi ottieni EXP pari ai danni subiti meno le stats; se vinci pari ai danni fatti. Questa EXP si può ricevere una volta ogni 3 ore.',
              'Training: if you lose, gain $expName equal to damage taken minus stats; if you win, gain $expName equal to damage dealt. This $expName can be received once every 3 hours.',
            ),
            color: Colors.grey.shade300,
          ),
          const SizedBox(height: 8),
          observationExpPanel(),
          const SizedBox(height: 12),
          experienceProgress(),
          const SizedBox(height: 14),
          campoTesto(
            label: t('$expName attuale manuale', 'Manual current $expName'),
            controller: expController,
          ),
          const SizedBox(height: 12),
          campoTesto(
            label: t('$expName base da aggiungere', 'Base $expName to add'),
            controller: expDaAggiungereController,
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            initialValue: fonteExpSelezionata,
            dropdownColor: const Color(0xFF10121A),
            decoration: fieldDecoration(t('Fonte $expName', '$expName source')),
            items: [
              DropdownMenuItem(
                value: 'normale',
                child: Text(t('Nemico normale x1', 'Normal enemy x1')),
              ),
              DropdownMenuItem(
                value: 'miniboss',
                child: Text(
                  'Mini-Boss x${oculumEnemyExpMultiplier(source: 'miniboss', difficulty: normalizedCampaignDifficulty()).toStringAsFixed(1)}',
                ),
              ),
              DropdownMenuItem(
                value: 'boss',
                child: Text(
                  'Boss x${oculumEnemyExpMultiplier(source: 'boss', difficulty: normalizedCampaignDifficulty()).toStringAsFixed(1)}',
                ),
              ),
            ],
            onChanged: (value) {
              setState(() => fonteExpSelezionata = value ?? 'normale');
              programmaSalvataggio();
            },
          ),
          const SizedBox(height: 12),
          campoTesto(
            label: t('Grado nemico', 'Enemy grade'),
            controller: enemyGradeExpController,
          ),
          const SizedBox(height: 8),
          smallInfoText(
            t(
              'Anteprima $expName finale: ${expFinalePreview()} (${expSourceLabel()}, grado x${expGradeMultiplier().toStringAsFixed(2)}, ${expGradeBonusLabel()}).',
              'Final $expName preview: ${expFinalePreview()} (${expSourceLabel()}, grade x${expGradeMultiplier().toStringAsFixed(2)}, ${expGradeBonusLabel()}).',
            ),
            color: tertiaryColor,
          ),
          const SizedBox(height: 12),
          ElevatedButton.icon(
            onPressed: aggiungiEsperienza,
            icon: const Icon(Icons.add),
            style: ElevatedButton.styleFrom(
              backgroundColor: tertiaryColor,
              foregroundColor: tertiaryColor.computeLuminance() > 0.45
                  ? Colors.black
                  : Colors.white,
              minimumSize: const Size.fromHeight(48),
            ),
            label: Text(t('Aggiungi $expName', 'Add $expName')),
          ),
          const SizedBox(height: 18),
          SwitchListTile(
            value: rebirthato,
            activeThumbColor: tertiaryColor,
            title: Text(
              'Rebirth',
              style: TextStyle(
                color: primaryColor,
                fontWeight: FontWeight.bold,
              ),
            ),
            subtitle: Text(
              t(
                'Riduce le soglie dei Gradi e permette crescita più rapida.',
                'Reduces Grade thresholds and allows faster growth.',
              ),
            ),
            onChanged: toggleRebirth,
          ),
          ElevatedButton.icon(
            onPressed: aggiornaGradoAutomatico,
            icon: const Icon(Icons.auto_fix_high),
            style: ElevatedButton.styleFrom(
              backgroundColor: secondaryColor,
              foregroundColor: Colors.white,
              minimumSize: const Size.fromHeight(44),
            ),
            label: Text(t('Controlla Grado Automatico', 'Check Auto Grade')),
          ),
          const SizedBox(height: 18),
          Text(
            t(
              'Strumento Master per livelli alti',
              'Master tool for high-level sheets',
            ),
            style: TextStyle(color: primaryColor, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          campoTesto(
            label: t('Livelli rapidi da aggiungere', 'Quick levels to add'),
            controller: livelliRapidiController,
          ),
          const SizedBox(height: 12),
          ElevatedButton.icon(
            onPressed: aggiungiLivelliRapidi,
            icon: const Icon(Icons.keyboard_double_arrow_up),
            style: ElevatedButton.styleFrom(
              backgroundColor: secondaryColor,
              foregroundColor: Colors.white,
              minimumSize: const Size.fromHeight(48),
            ),
            label: Text(t('Aggiungi livelli rapidi', 'Add quick levels')),
          ),
          const SizedBox(height: 12),
          ElevatedButton.icon(
            onPressed: randomizzaStatsBilanciate,
            icon: const Icon(Icons.casino),
            style: ElevatedButton.styleFrom(
              backgroundColor: primaryColor,
              foregroundColor: primaryColor.computeLuminance() > 0.45
                  ? Colors.black
                  : Colors.white,
              minimumSize: const Size.fromHeight(48),
            ),
            label: Text(
              t('Randomizza stats bilanciate', 'Randomize balanced stats'),
            ),
          ),
          if (!isMostro() && levelUpDaAssegnare > 0) ...[
            const SizedBox(height: 18),
            levelUpPanel(),
          ],
          if (isMostro()) ...[const SizedBox(height: 18), monsterGrowthPanel()],
        ],
      ),
    );
  }

  Widget observationExpPanel() {
    final observationAvailable = osservazionePuntiDisponibili();
    final observationTheoretical = osservazionePuntiTeorici();
    final observationAssigned = osservazionePuntiAssegnatiTotali();
    final observationAssignments = osservazionePuntiAssegnatiSicuri();
    final assignmentText = osservazioneAssegnazioniTesto();

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: 0.24),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: tertiaryColor.withValues(alpha: 0.55)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          campoTesto(
            label: t('Nome EXP personalizzato', 'Custom EXP name'),
            controller: expNomePersonalizzatoController,
            numero: false,
            helper: t('Vuoto = EXP.', 'Empty = EXP.'),
            onChanged: (_) {
              if (mounted) setState(() {});
            },
          ),
          const SizedBox(height: 8),
          Material(
            color: Colors.transparent,
            child: SwitchListTile(
              contentPadding: EdgeInsets.zero,
              value: puoEssereOsservato,
              activeThumbColor: tertiaryColor,
              title: Text(
                t('Puo essere osservato', 'Can be observed'),
                style: TextStyle(
                  color: tertiaryColor,
                  fontWeight: FontWeight.w900,
                ),
              ),
              subtitle: Text(
                puoEssereOsservato
                    ? t(
                        '$observationAvailable disponibili su $observationTheoretical totali. Assegnati: $observationAssigned.',
                        '$observationAvailable available out of $observationTheoretical total. Assigned: $observationAssigned.',
                      )
                    : t(
                        'Se attiva, concede 1 punto stat extra per ogni livello totale, anche retroattivo.',
                        'When active, grants 1 extra stat point per total level, including past levels.',
                      ),
              ),
              onChanged: togglePuoEssereOsservato,
            ),
          ),
          if (puoEssereOsservato) ...[
            const SizedBox(height: 8),
            smallInfoText(
              assignmentText.isEmpty
                  ? t(
                      'Nessun punto osservazione assegnato.',
                      'No observation points assigned.',
                    )
                  : t(
                      'Assegnati: $assignmentText.',
                      'Assigned: $assignmentText.',
                    ),
              color: tertiaryColor,
            ),
            const SizedBox(height: 8),
            statDropdown(
              label: t('Stat osservazione +1', 'Observation stat +1'),
              value: osservazioneStatScelta,
              onChanged: (value) {
                setState(() {
                  osservazioneStatScelta = normalizeObservationStat(value);
                });
                programmaSalvataggio();
              },
            ),
            const SizedBox(height: 10),
            ElevatedButton.icon(
              onPressed: observationAvailable > 0
                  ? assegnaPuntoOsservazione
                  : null,
              icon: const Icon(Icons.remove_red_eye),
              style: ElevatedButton.styleFrom(
                backgroundColor: tertiaryColor,
                foregroundColor: tertiaryColor.computeLuminance() > 0.45
                    ? Colors.black
                    : Colors.white,
                minimumSize: const Size.fromHeight(44),
              ),
              label: Text(
                t(
                  'Assegna punto osservazione ($observationAvailable)',
                  'Assign observation point ($observationAvailable)',
                ),
              ),
            ),
            if (observationAssigned > 0) ...[
              const SizedBox(height: 10),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                crossAxisAlignment: WrapCrossAlignment.center,
                children: [
                  for (final entry in observationAssignments.entries)
                    if (entry.value > 0)
                      InputChip(
                        avatar: const Icon(Icons.remove_red_eye, size: 16),
                        label: Text(
                          '+${entry.value} ${observationStatLabel(entry.key)}',
                        ),
                        backgroundColor: tertiaryColor.withValues(alpha: 0.14),
                        side: BorderSide(color: tertiaryColor),
                        labelStyle: TextStyle(
                          color: tertiaryColor,
                          fontWeight: FontWeight.bold,
                        ),
                        onDeleted: () =>
                            rimuoviPuntoOsservazioneAssegnato(entry.key),
                        deleteIcon: Icon(
                          Icons.remove_circle_outline,
                          color: tertiaryColor,
                          size: 18,
                        ),
                        tooltip: t(
                          'Rimuovi un punto da ${observationStatLabel(entry.key)}',
                          'Remove one point from ${observationStatLabel(entry.key)}',
                        ),
                      ),
                ],
              ),
            ],
          ],
        ],
      ),
    );
  }

  Widget levelUpPanel() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: 0.35),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: primaryColor.withValues(alpha: 0.75),
          width: 1.2,
        ),
        boxShadow: [
          BoxShadow(
            color: primaryColor.withValues(alpha: 0.08),
            blurRadius: 8,
            spreadRadius: 0.5,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            t(
              'Level up da assegnare: $levelUpDaAssegnare',
              'Level ups to assign: $levelUpDaAssegnare',
            ),
            style: TextStyle(
              color: primaryColor,
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 10),
          smallInfoText(
            t(
              'Scegli una statistica da +3 e una diversa da +2. Le altre due prendono +1. Ogni livello dà anche +6 Scudo e refulla gli HP.',
              'Choose one stat for +3 and a different one for +2. The other two get +1. Each level also gives +6 Shield and refills HP.',
            ),
          ),
          const SizedBox(height: 14),
          statDropdown(
            label: t('Statistica da +3', 'Stat +3'),
            value: levelUpStatTre,
            onChanged: (value) {
              levelUpStatTre = value;

              if (levelUpStatDue == levelUpStatTre) {
                levelUpStatDue = statsLevelUp.firstWhere(
                  (x) => x != levelUpStatTre,
                  orElse: () => 'Volontà',
                );
              }
            },
          ),
          const SizedBox(height: 12),
          statDropdown(
            label: t('Statistica da +2', 'Stat +2'),
            value: levelUpStatDue,
            onChanged: (value) {
              levelUpStatDue = value;

              if (levelUpStatTre == levelUpStatDue) {
                levelUpStatTre = statsLevelUp.firstWhere(
                  (x) => x != levelUpStatDue,
                  orElse: () => 'Resilienza',
                );
              }
            },
          ),
          const SizedBox(height: 14),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              statChip('RES', bonusLevelUpPerStat('Resilienza')),
              statChip('VOL', bonusLevelUpPerStat('Volontà')),
              statChip('MAT', bonusLevelUpPerStat('Materia')),
              statChip('OCU', bonusLevelUpPerStat('Oculum')),
              statChip('SCUDO', 6),
            ],
          ),
          const SizedBox(height: 16),
          ElevatedButton.icon(
            onPressed: () => applicaLevelUp(tutti: false),
            icon: const Icon(Icons.check_circle),
            style: ElevatedButton.styleFrom(
              backgroundColor: tertiaryColor,
              foregroundColor: tertiaryColor.computeLuminance() > 0.45
                  ? Colors.black
                  : Colors.white,
              minimumSize: const Size.fromHeight(48),
            ),
            label: Text(t('Applica 1 level up', 'Apply 1 level up')),
          ),
          const SizedBox(height: 10),
          ElevatedButton.icon(
            onPressed: () => applicaLevelUp(tutti: true),
            icon: const Icon(Icons.copy_all),
            style: ElevatedButton.styleFrom(
              backgroundColor: primaryColor,
              foregroundColor: primaryColor.computeLuminance() > 0.45
                  ? Colors.black
                  : Colors.white,
              minimumSize: const Size.fromHeight(48),
            ),
            label: Text(
              t(
                'Copia questa scelta su tutti i livelli in sospeso',
                'Copy this choice on all pending levels',
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget monsterGrowthPanel() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: 0.35),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: tertiaryColor.withValues(alpha: 0.75),
          width: 1.2,
        ),
        boxShadow: [
          BoxShadow(
            color: tertiaryColor.withValues(alpha: 0.08),
            blurRadius: 8,
            spreadRadius: 0.5,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            t(
              'Punti Mostro disponibili: $monsterStatPoints',
              'Available Monster Points: $monsterStatPoints',
            ),
            style: TextStyle(
              color: tertiaryColor,
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 10),
          smallInfoText(
            t(
              'I Mostri ricevono 9 punti statistica per livello. Ogni Grado può dare +10 × Grado a una statistica scelta.',
              'Monsters get 9 stat points per level. Each Grade may give +10 × Grade to one chosen stat.',
            ),
          ),
          const SizedBox(height: 14),
          statDropdown(
            label: t('Statistica Mostro', 'Monster Stat'),
            value: monsterSelectedStat,
            onChanged: (value) => monsterSelectedStat = value,
          ),
          const SizedBox(height: 12),
          campoTesto(
            label: t('Punti da assegnare', 'Points to assign'),
            controller: monsterPointAmountController,
          ),
          const SizedBox(height: 12),
          ElevatedButton.icon(
            onPressed: assegnaPuntiMostro,
            icon: const Icon(Icons.add_chart),
            style: ElevatedButton.styleFrom(
              backgroundColor: tertiaryColor,
              foregroundColor: tertiaryColor.computeLuminance() > 0.45
                  ? Colors.black
                  : Colors.white,
              minimumSize: const Size.fromHeight(48),
            ),
            label: Text(t('Assegna punti mostro', 'Assign monster points')),
          ),
          const SizedBox(height: 18),
          statDropdown(
            label: t('Statistica bonus Grado', 'Grade bonus stat'),
            value: monsterGradeStat,
            onChanged: (value) => monsterGradeStat = value,
          ),
          const SizedBox(height: 12),
          ElevatedButton.icon(
            onPressed: applicaBonusGradoMostro,
            icon: const Icon(Icons.auto_fix_high),
            style: ElevatedButton.styleFrom(
              backgroundColor: secondaryColor,
              foregroundColor: Colors.white,
              minimumSize: const Size.fromHeight(48),
            ),
            label: Text(t('Applica +10 × Grado', 'Apply +10 × Grade')),
          ),
        ],
      ),
    );
  }

  // =====================================================
  // PAGINA SCHEDA
  // =====================================================

  Widget dropdownSection({
    required String title,
    required IconData icon,
    required Color borderColor,
    required Widget child,
    bool initiallyExpanded = false,
    String? subtitle,
    String? sectionId,
  }) {
    final cleanTitle = cleanUiText(title);
    final cleanSubtitle = subtitle == null ? null : cleanUiText(subtitle);
    final compact = lightweightUi;
    final expanded =
        initiallyExpanded ||
        (sectionId != null && _expandedFunctionSections.contains(sectionId));
    final storageId = sectionId ?? cleanTitle;

    return gothicPanel(
      borderColor: borderColor,
      padding: EdgeInsets.zero,
      child: Theme(
        data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
        child: Material(
          type: MaterialType.transparency,
          child: ExpansionTile(
            // Keep expansion state away from Flutter PageStorage. Scroll offsets
            // and ExpansionTile booleans can otherwise collide after hot reload
            // or navigation changes and crash with bool/double casts.
            key: sheetExpansionKey(storageId),
            initiallyExpanded: expanded,
            onExpansionChanged: sectionId == null
                ? null
                : (value) {
                    if (!mounted) return;
                    setState(() {
                      if (value) {
                        _expandedFunctionSections.add(sectionId);
                      } else {
                        _expandedFunctionSections.remove(sectionId);
                      }
                    });
                  },
            iconColor: borderColor,
            collapsedIconColor: borderColor,
            tilePadding: EdgeInsets.symmetric(
              horizontal: compact ? 8 : 12,
              vertical: 0,
            ),
            childrenPadding: EdgeInsets.fromLTRB(
              compact ? 8 : 12,
              0,
              compact ? 8 : 12,
              compact ? 8 : 12,
            ),
            leading: Icon(icon, color: borderColor, size: compact ? 18 : 22),
            title: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  cleanTitle,
                  maxLines: compact ? 1 : 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: borderColor,
                    fontWeight: FontWeight.w900,
                    fontSize: compact ? 13.5 : null,
                  ),
                ),
                if (cleanSubtitle != null && !compact) ...[
                  const SizedBox(height: 3),
                  Text(
                    cleanSubtitle,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Color(0xFFBFB7DD),
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      height: 1.15,
                    ),
                  ),
                ],
              ],
            ),
            trailing: Container(
              width: 30,
              height: 30,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: borderColor.withValues(alpha: 0.13),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(Icons.expand_more, color: borderColor, size: 20),
            ),
            children: [child],
          ),
        ),
      ),
    );
  }

  Widget quickIndexButtonsPanel() {
    if (!mostraTastiRapidiIndice) return const SizedBox.shrink();

    final entries = <Map<String, dynamic>>[
      {
        'label': t('Scheda', 'Sheet'),
        'page': 0,
        'icon': Icons.visibility_outlined,
        'anchorId': 'sheet_identity',
      },
      {
        'label': t('Borsa', 'Bag'),
        'page': 6,
        'icon': Icons.backpack_outlined,
        'anchorId': 'inventory_root',
      },
      {
        'label': t('Regole', 'Rules'),
        'page': 8,
        'icon': Icons.rule_outlined,
        'anchorId': 'rules_root',
      },
      {
        'label': t('Party', 'Party'),
        'page': 0,
        'icon': Icons.groups,
        'anchorId': 'sheet_party',
      },
      {
        'label': t('Opzioni', 'Options'),
        'page': _OculumHomePageState.settingsPageIndex,
        'icon': Icons.settings_outlined,
        'anchorId': 'settings_root',
      },
    ];

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: [
          for (final entry in entries) ...[
            ElevatedButton.icon(
              onPressed: () {
                vaiAllaFunzione(
                  page: readIntValue(entry['page']),
                  anchorId: '${entry['anchorId'] ?? ''}',
                  logTitle: entry['label'] as String,
                );
              },
              icon: Icon(entry['icon'] as IconData, size: 18),
              style: ElevatedButton.styleFrom(
                backgroundColor: secondaryColor,
                foregroundColor: primaryColor,
                side: BorderSide(color: tertiaryColor.withValues(alpha: 0.45)),
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 8,
                ),
              ),
              label: Text('${entry['label']}'),
            ),
            const SizedBox(width: 8),
          ],
        ],
      ),
    );
  }

  Widget quickAdjustButton({
    required IconData icon,
    required String tooltip,
    required Color color,
    required VoidCallback onPressed,
  }) {
    final compact = lightweightUi;
    final background = const Color(0xFF080A12);
    final accent = readableOnTheme(color, background: background, minRatio: 3);
    final size = compact ? 24.0 : 28.0;

    return Tooltip(
      message: cleanUiText(tooltip),
      child: IconButton(
        onPressed: onPressed,
        constraints: BoxConstraints.tightFor(width: size, height: size),
        padding: EdgeInsets.zero,
        visualDensity: VisualDensity.compact,
        style: IconButton.styleFrom(
          backgroundColor: accent.withValues(alpha: 0.16),
          foregroundColor: accent,
          side: BorderSide(color: accent.withValues(alpha: 0.45)),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(compact ? 6 : 7),
          ),
        ),
        icon: Icon(icon, size: compact ? 14 : 16),
      ),
    );
  }

  void modificaHpRapido(int delta) {
    if (delta == 0) return;
    setState(() {
      final before = hpCorrenti();
      final next = (before + delta).clamp(0, maxHp()).toInt();
      currentHpController.text = next.toString();
      risultato =
          'HP attuali: ${next - before >= 0 ? '+' : ''}${next - before} ($next/${maxHp()}).';
      aggiungiLog(risultato);
    });
    recordCurrentVitalsProgress();
    programmaSalvataggio(invalidateCaches: false);
    sendRealtimeHpChanged();
  }

  void modificaHpTempRapido(int delta) {
    if (delta == 0) return;
    setState(() {
      final before = hpTemp();
      final next = max(0, before + delta);
      impostaHpTempTotali(next);
      risultato =
          'HP Temp: ${next - before >= 0 ? '+' : ''}${next - before} ($next).';
      aggiungiLog(risultato);
    });
    recordCurrentVitalsProgress();
    programmaSalvataggio(invalidateCaches: false);
    sendRealtimeHpChanged();
  }

  void modificaScudoRapido(int delta) {
    if (delta == 0) return;
    setState(() {
      final before = scudo();
      final next = max(0, before + delta);
      impostaScudoTotale(next);
      risultato =
          '${t('Scudo', 'Shield')}: ${next - before >= 0 ? '+' : ''}${next - before} ($next).';
      aggiungiLog(risultato);
    });
    recordCurrentVitalsProgress();
    programmaSalvataggio(invalidateCaches: false);
    sendRealtimeHpChanged();
  }

  void modificaScudoCriticoRapido(int delta) {
    if (delta == 0) return;
    setState(() {
      final before = scudoCritico();
      final next = max(0, before + delta);
      scudoCriticoController.text = next.toString();
      risultato =
          '${t('Scudo Critico', 'Critical Shield')}: ${next - before >= 0 ? '+' : ''}${next - before} ($next).';
      aggiungiLog(risultato);
    });
    recordCurrentVitalsProgress();
    programmaSalvataggio(invalidateCaches: false);
    sendRealtimeHpChanged();
  }

  void modificaControllerNumericoRapido(
    TextEditingController controller,
    int delta, {
    required String label,
    bool allowNegative = false,
    VoidCallback? afterChange,
  }) {
    if (delta == 0) return;
    setState(() {
      final before = readIntValue(controller.text);
      final next = allowNegative ? before + delta : max(0, before + delta);
      controller.text = next.toString();
      afterChange?.call();
      risultato =
          '$label: ${next - before >= 0 ? '+' : ''}${next - before} ($next).';
      aggiungiLog(risultato);
    });
    programmaSalvataggio();
  }

  void modificaBuffMalusRapido({
    required String rawKey,
    required String label,
    required int delta,
    bool log = true,
    bool save = true,
  }) {
    if (delta == 0) return;

    setState(() {
      final text = buffMalusRapidiController.text.trim();
      final pattern = RegExp(
        '(^|\\s)@${RegExp.escape(rawKey)}([+-]\\d+)(?=\\s|\$)',
        caseSensitive: false,
      );
      final match = pattern.firstMatch(text);
      final current = match == null
          ? 0
          : int.tryParse(match.group(2) ?? '0') ?? 0;
      final next = current + delta;
      final token = '@$rawKey${next >= 0 ? '+' : ''}$next';
      String nextText;

      if (match == null) {
        nextText = next == 0
            ? text
            : [text, token].where((part) => part.trim().isNotEmpty).join(' ');
      } else {
        final prefix = match.group(1) ?? '';
        nextText = text.replaceRange(
          match.start,
          match.end,
          next == 0 ? prefix : '$prefix$token',
        );
      }

      buffMalusRapidiController.text = nextText
          .replaceAll(RegExp(r'\s+'), ' ')
          .trim();
      if (log) {
        risultato =
            '$label rapido ${delta > 0 ? '+' : ''}$delta. Bonus $label: $next.';
        aggiungiLog(risultato);
      }
    });

    if (save) programmaSalvataggio();
  }

  Widget quickStatTile({
    required String label,
    required String value,
    String Function()? valueBuilder,
    required IconData icon,
    required Color color,
    VoidCallback? onTap,
    VoidCallback? onRoll,
    VoidCallback? onDecrease,
    VoidCallback? onIncrease,
    OculumConditionTarget? conditionTarget,
    String? baseValue,
    String? permanentValue,
    String? temporaryValue,
    bool conditionScoped = false,
  }) {
    final effectiveConditionTarget =
        conditionTarget ?? conditionTargetForUiLabel(label);
    if (!conditionScoped && effectiveConditionTarget != null) {
      return ValueListenableBuilder<int>(
        valueListenable: conditionRevisionFor(effectiveConditionTarget),
        builder: (context, revision, child) => quickStatTile(
          label: label,
          value:
              valueBuilder?.call() ??
              currentConditionTargetValue(effectiveConditionTarget, value),
          valueBuilder: valueBuilder,
          icon: icon,
          color: color,
          onTap: onTap,
          onRoll: onRoll,
          onDecrease: onDecrease,
          onIncrease: onIncrease,
          conditionTarget: effectiveConditionTarget,
          baseValue: baseValue,
          permanentValue: permanentValue,
          temporaryValue: temporaryValue,
          conditionScoped: true,
        ),
      );
    }
    final compact = lightweightUi;
    final spec = currentThemeDecorationSpec();
    final guiStyle = currentThemeVisualIdentity().mainSheetGuiStyle.id;
    final clippedTile = <String>{
      'phobia',
      'postea',
      'kingi',
      'medieval',
      'rank_hud',
      'sigil',
      'archive',
      'relic',
    }.contains(guiStyle);
    final tileBackground = switch (guiStyle) {
      'phobia' => Color.lerp(
        spec.backgroundBottom,
        const Color(0xFF071527),
        0.44,
      )!,
      'postea' || 'kingi' || 'medieval' => Color.lerp(
        spec.backgroundBottom,
        const Color(0xFF102334),
        0.48,
      )!,
      'botanical' => Color.lerp(
        spec.backgroundBottom,
        const Color(0xFF101C13),
        0.38,
      )!,
      'lunar' || 'soft_orbital' => Color.lerp(
        spec.backgroundBottom,
        const Color(0xFF11152A),
        0.42,
      )!,
      'archive' || 'relic' => Color.lerp(
        spec.backgroundBottom,
        const Color(0xFF17130D),
        0.34,
      )!,
      'rank_hud' || 'sigil' => Color.lerp(
        spec.backgroundBottom,
        const Color(0xFF120C28),
        0.44,
      )!,
      _ => const Color(0xFF080A12),
    };
    final accent = readableOnTheme(
      color,
      background: tileBackground,
      minRatio: 3.5,
    );
    final labelColor = readableOnTheme(
      const Color(0xFFBFB7DD),
      background: tileBackground,
    );
    final hasControls =
        onRoll != null || onDecrease != null || onIncrease != null;
    final tileRadius = switch (guiStyle) {
      'phobia' => compact ? 4.0 : 6.0,
      'postea' || 'kingi' || 'medieval' => compact ? 5.0 : 7.0,
      'botanical' => compact ? 12.0 : 14.0,
      'lunar' || 'soft_orbital' => compact ? 14.0 : 16.0,
      _ => compact ? 8.0 : 10.0,
    };
    final tileGradient = switch (guiStyle) {
      'phobia' => LinearGradient(
        colors: [
          tileBackground,
          Color.lerp(tileBackground, spec.accent, 0.16)!,
          Colors.black.withValues(alpha: 0.96),
        ],
        stops: const [0.0, 0.58, 1.0],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ),
      'postea' || 'kingi' || 'medieval' => LinearGradient(
        colors: [
          Color.lerp(tileBackground, spec.primary, 0.09)!,
          tileBackground,
          Color.lerp(tileBackground, spec.accent, 0.10)!,
        ],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ),
      'botanical' => LinearGradient(
        colors: [
          Color.lerp(tileBackground, spec.secondary, 0.13)!,
          tileBackground,
          Color.lerp(tileBackground, spec.primary, 0.08)!,
        ],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ),
      _ => LinearGradient(colors: [tileBackground, tileBackground]),
    };

    Widget valueText({bool centered = false}) {
      return GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: onRoll ?? onTap,
        child: FittedBox(
          fit: BoxFit.scaleDown,
          alignment: centered ? Alignment.center : Alignment.centerLeft,
          child: Text(
            value,
            textAlign: centered ? TextAlign.center : TextAlign.start,
            maxLines: 1,
            softWrap: false,
            style: TextStyle(
              color: accent,
              fontSize: compact ? 14.5 : 19,
              fontWeight: FontWeight.w900,
              shadows: readableTextShadow(accent, background: tileBackground),
            ),
          ),
        ),
      );
    }

    final tileContent = Container(
      constraints: BoxConstraints(
        minWidth: hasControls ? (compact ? 104 : 136) : (compact ? 78 : 108),
      ),
      padding: EdgeInsets.symmetric(
        horizontal: compact ? 8 : 11,
        vertical: compact ? 7 : 11,
      ),
      decoration: BoxDecoration(
        gradient: tileGradient,
        borderRadius: BorderRadius.circular(tileRadius),
        border: Border.all(color: accent.withValues(alpha: 0.45)),
        boxShadow: compact
            ? const <BoxShadow>[]
            : [
                BoxShadow(
                  color: accent.withValues(
                    alpha: guiStyle == 'phobia' ? 0.16 : 0.08,
                  ),
                  blurRadius: guiStyle == 'phobia' ? 10 : 6,
                  offset: const Offset(0, 2),
                ),
              ],
      ),
      child: Stack(
        children: [
          if (clippedTile)
            Positioned.fill(
              child: IgnorePointer(
                child: CustomPaint(
                  painter: _OculumThemePanelChromePainter(
                    spec: spec,
                    guiStyle: guiStyle,
                    borderColor: accent,
                    compact: true,
                    clipped: clippedTile,
                  ),
                ),
              ),
            ),
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, color: accent, size: compact ? 14 : 18),
              SizedBox(width: compact ? 5 : 8),
              Flexible(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Flexible(
                          child: Text(
                            label,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: labelColor,
                              fontSize: compact ? 9.2 : 11,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                        if (effectiveConditionTarget != null) ...[
                          const SizedBox(width: 4),
                          conditionImpactIndicator(
                            target: effectiveConditionTarget,
                            baseValue: baseValue,
                            permanentValue: permanentValue,
                            temporaryValue: temporaryValue,
                            finalValue: value,
                          ),
                        ],
                      ],
                    ),
                    SizedBox(height: compact ? 0 : 2),
                    if (hasControls)
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          if (onDecrease != null)
                            quickAdjustButton(
                              icon: Icons.remove,
                              tooltip: '-1 $label',
                              color: accent,
                              onPressed: onDecrease,
                            ),
                          if (onDecrease != null) const SizedBox(width: 3),
                          Flexible(child: valueText(centered: true)),
                          if (onIncrease != null) const SizedBox(width: 3),
                          if (onIncrease != null)
                            quickAdjustButton(
                              icon: Icons.add,
                              tooltip: '+1 $label',
                              color: accent,
                              onPressed: onIncrease,
                            ),
                        ],
                      )
                    else
                      valueText(),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
    final tile = clippedTile
        ? ClipPath(
            clipper: _OculumThemePanelClipper(
              guiStyle: guiStyle,
              compact: true,
            ),
            child: tileContent,
          )
        : tileContent;

    final contextualTile = quickContextMenuAnchor(
      label: label,
      child: tile,
      onEdit: onTap,
      onRoll: onRoll,
      onDecrease: onDecrease,
      onIncrease: onIncrease,
      conditionTarget: effectiveConditionTarget,
    );

    if (onTap == null) return contextualTile;

    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(tileRadius),
        onTap: onTap,
        child: contextualTile,
      ),
    );
  }

  Widget quickContextMenuAnchor({
    required String label,
    required Widget child,
    VoidCallback? onEdit,
    VoidCallback? onRoll,
    VoidCallback? onDecrease,
    VoidCallback? onIncrease,
    String? manualQuery,
    OculumConditionTarget? conditionTarget,
  }) {
    if (onEdit == null &&
        onRoll == null &&
        onDecrease == null &&
        onIncrease == null) {
      return child;
    }

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onSecondaryTapDown: (details) => showQuickContextMenu(
        label: label,
        position: details.globalPosition,
        onEdit: onEdit,
        onRoll: onRoll,
        onDecrease: onDecrease,
        onIncrease: onIncrease,
        manualQuery: manualQuery,
        conditionTarget: conditionTarget,
      ),
      onLongPressStart: (details) => showQuickContextMenu(
        label: label,
        position: details.globalPosition,
        onEdit: onEdit,
        onRoll: onRoll,
        onDecrease: onDecrease,
        onIncrease: onIncrease,
        manualQuery: manualQuery,
        conditionTarget: conditionTarget,
      ),
      child: child,
    );
  }

  Future<void> showQuickContextMenu({
    required String label,
    required Offset position,
    VoidCallback? onEdit,
    VoidCallback? onRoll,
    VoidCallback? onDecrease,
    VoidCallback? onIncrease,
    String? manualQuery,
    OculumConditionTarget? conditionTarget,
  }) async {
    final cleanLabel = cleanUiText(label).trim();
    final choice = await showMenu<String>(
      context: context,
      color: const Color(0xFF10121A),
      position: RelativeRect.fromLTRB(
        position.dx,
        position.dy,
        position.dx,
        position.dy,
      ),
      items: [
        if (onRoll != null)
          PopupMenuItem<String>(
            value: 'roll',
            child: Row(
              children: [
                Icon(Icons.casino, color: tertiaryColor, size: 18),
                const SizedBox(width: 10),
                Text(t('Tira $cleanLabel', 'Roll $cleanLabel')),
              ],
            ),
          ),
        if (onEdit != null)
          PopupMenuItem<String>(
            value: 'edit',
            child: Row(
              children: [
                Icon(Icons.edit, color: primaryColor, size: 18),
                const SizedBox(width: 10),
                Text(t('Modifica', 'Edit')),
              ],
            ),
          ),
        PopupMenuItem<String>(
          value: 'manual',
          child: Row(
            children: [
              Icon(Icons.menu_book, color: primaryColor, size: 18),
              const SizedBox(width: 10),
              Text(t('Vedi nel manuale', 'View in manual')),
            ],
          ),
        ),
        if (conditionTarget != null &&
            conditionsAffecting(conditionTarget).isNotEmpty)
          PopupMenuItem<String>(
            value: 'conditions',
            child: Row(
              children: [
                Icon(Icons.bolt, color: tertiaryColor, size: 18),
                const SizedBox(width: 10),
                Text(t('Effetti condizioni', 'Condition effects')),
              ],
            ),
          ),
        if (onDecrease != null || onIncrease != null) const PopupMenuDivider(),
        if (onDecrease != null)
          PopupMenuItem<String>(
            value: 'decrease',
            child: Row(
              children: [
                const Icon(Icons.remove, color: Colors.redAccent, size: 18),
                const SizedBox(width: 10),
                Text('-1 $cleanLabel'),
              ],
            ),
          ),
        if (onIncrease != null)
          PopupMenuItem<String>(
            value: 'increase',
            child: Row(
              children: [
                const Icon(Icons.add, color: Colors.greenAccent, size: 18),
                const SizedBox(width: 10),
                Text('+1 $cleanLabel'),
              ],
            ),
          ),
      ],
    );

    if (!mounted || choice == null) return;
    switch (choice) {
      case 'roll':
        onRoll?.call();
        break;
      case 'edit':
        onEdit?.call();
        break;
      case 'manual':
        openManualForQuickTerm(manualQuery ?? cleanLabel);
        break;
      case 'conditions':
        if (conditionTarget != null) {
          showConditionImpactDialog(target: conditionTarget);
        }
        break;
      case 'decrease':
        onDecrease?.call();
        break;
      case 'increase':
        onIncrease?.call();
        break;
    }
  }

  void openManualForQuickTerm(String rawTerm) {
    final term = cleanUiText(rawTerm).trim();
    if (term.isEmpty) return;
    final normalizedTerm = term.toLowerCase();
    final matchIndex = activeManualSections.indexWhere((section) {
      final haystack =
          '${manualTitle(section)} ${manualContent(section)} ${section.titleIt} ${section.titleEn} ${section.contentIt} ${section.contentEn}'
              .toLowerCase();
      return haystack.contains(normalizedTerm);
    });

    manualSearchController.text = term;
    manualSearchText = term;
    vaiAllaFunzione(
      page: 8,
      manualIndex: matchIndex >= 0 ? matchIndex : null,
      logTitle: t('Manuale: $term', 'Manual: $term'),
    );
  }

  Widget quickCommandButton({
    required String label,
    required IconData icon,
    required Color color,
    required VoidCallback onPressed,
  }) {
    final cleanLabel = cleanUiText(label);
    final compact = lightweightUi;
    final spec = currentThemeDecorationSpec();
    final guiStyle = currentThemeVisualIdentity().mainSheetGuiStyle.id;
    final clippedButton = <String>{
      'phobia',
      'postea',
      'kingi',
      'medieval',
      'rank_hud',
      'sigil',
      'archive',
      'relic',
    }.contains(guiStyle);
    final buttonBackground = switch (guiStyle) {
      'phobia' => Color.lerp(
        spec.backgroundBottom,
        const Color(0xFF18060A),
        0.58,
      )!,
      'postea' || 'kingi' || 'medieval' => Color.lerp(
        spec.backgroundBottom,
        const Color(0xFF102638),
        0.46,
      )!,
      'botanical' => Color.lerp(
        spec.backgroundBottom,
        const Color(0xFF102016),
        0.40,
      )!,
      'lunar' || 'soft_orbital' => Color.lerp(
        spec.backgroundBottom,
        const Color(0xFF11162C),
        0.42,
      )!,
      'archive' || 'relic' => Color.lerp(
        spec.backgroundBottom,
        const Color(0xFF18110B),
        0.40,
      )!,
      'rank_hud' || 'sigil' => Color.lerp(
        spec.backgroundBottom,
        const Color(0xFF12092B),
        0.48,
      )!,
      _ => const Color(0xFF0B0D16),
    };
    final foreground = readableOnTheme(
      color,
      background: buttonBackground,
      minRatio: 3.6,
    );
    final radius = switch (guiStyle) {
      'phobia' => compact ? 4.0 : 5.0,
      'postea' || 'kingi' || 'medieval' => compact ? 5.0 : 7.0,
      'botanical' => compact ? 13.0 : 15.0,
      'lunar' || 'soft_orbital' => compact ? 14.0 : 16.0,
      _ => compact ? 8.0 : 10.0,
    };
    final Gradient gradient = switch (guiStyle) {
      'phobia' => LinearGradient(
        colors: [
          Colors.black.withValues(alpha: 0.96),
          Color.lerp(buttonBackground, spec.accent, 0.16)!,
          buttonBackground,
        ],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ),
      'postea' || 'kingi' || 'medieval' => LinearGradient(
        colors: [
          Color.lerp(buttonBackground, spec.primary, 0.14)!,
          buttonBackground,
          Color.lerp(buttonBackground, spec.accent, 0.14)!,
        ],
        stops: const [0.0, 0.54, 1.0],
        begin: Alignment.centerLeft,
        end: Alignment.centerRight,
      ),
      'botanical' => LinearGradient(
        colors: [
          Color.lerp(buttonBackground, spec.secondary, 0.18)!,
          buttonBackground,
        ],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ),
      'lunar' || 'soft_orbital' => RadialGradient(
        colors: [
          Color.lerp(buttonBackground, spec.accent, 0.14)!,
          buttonBackground,
        ],
        center: Alignment.topLeft,
        radius: 1.3,
      ),
      _ => LinearGradient(colors: [buttonBackground, buttonBackground]),
    };

    final buttonBody = ConstrainedBox(
      constraints: BoxConstraints(
        minHeight: compact ? 36 : 42,
        maxWidth: compact ? 164 : 210,
      ),
      child: Container(
        padding: EdgeInsets.symmetric(
          horizontal: compact ? 10 : 13,
          vertical: compact ? 7 : 9,
        ),
        decoration: BoxDecoration(
          gradient: gradient,
          borderRadius: BorderRadius.circular(radius),
          border: Border.all(color: foreground.withValues(alpha: 0.58)),
          boxShadow: compact
              ? const <BoxShadow>[]
              : [
                  BoxShadow(
                    color: foreground.withValues(
                      alpha: guiStyle == 'phobia' ? 0.16 : 0.08,
                    ),
                    blurRadius:
                        guiStyle == 'postea' ||
                            guiStyle == 'kingi' ||
                            guiStyle == 'medieval'
                        ? 12
                        : 8,
                  ),
                ],
        ),
        child: Stack(
          children: [
            if (clippedButton)
              Positioned.fill(
                child: IgnorePointer(
                  child: CustomPaint(
                    painter: _OculumThemePanelChromePainter(
                      spec: spec,
                      guiStyle: guiStyle,
                      borderColor: foreground,
                      compact: true,
                      clipped: clippedButton,
                    ),
                  ),
                ),
              ),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(icon, color: foreground, size: compact ? 14 : 17),
                SizedBox(width: compact ? 5 : 7),
                Flexible(
                  child: FittedBox(
                    fit: BoxFit.scaleDown,
                    alignment: Alignment.centerLeft,
                    child: Text(
                      cleanLabel,
                      maxLines: 1,
                      softWrap: false,
                      style: TextStyle(
                        color: foreground,
                        fontWeight: FontWeight.w900,
                        fontSize: compact ? 11.2 : 13.2,
                        shadows: readableTextShadow(
                          foreground,
                          background: buttonBackground,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
    final button = clippedButton
        ? ClipPath(
            clipper: _OculumThemePanelClipper(
              guiStyle: guiStyle,
              compact: true,
            ),
            child: buttonBody,
          )
        : buttonBody;

    return Semantics(
      button: true,
      label: cleanLabel,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(radius),
          onTap: onPressed,
          child: button,
        ),
      ),
    );
  }

  Widget equippedTitlesStrip({bool compact = false}) {
    final equipped = <MapEntry<OculumTitle, bool>>[
      for (final titolo in titoli.where((titolo) => titolo.equipaggiato))
        MapEntry(titolo, false),
      for (final titolo in trattiRazziali.where(
        (titolo) => titolo.equipaggiato,
      ))
        MapEntry(titolo, true),
    ];

    if (equipped.isEmpty) {
      return smallInfoText(
        t('Nessun titolo indossato.', 'No equipped title.'),
        color: Colors.grey.shade400,
      );
    }

    return Wrap(
      spacing: compact ? 6 : 8,
      runSpacing: compact ? 6 : 8,
      children: [
        for (final entry in equipped.take(compact ? 4 : 7))
          ActionChip(
            avatar: Icon(
              entry.key.openAttiva
                  ? Icons.lock_open
                  : entry.key.evoluto
                  ? Icons.auto_awesome
                  : Icons.workspace_premium,
              size: compact ? 15 : 17,
              color: entry.key.openAttiva ? Colors.black : tertiaryColor,
            ),
            label: Text(
              cleanUiText(entry.key.nome),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            tooltip: cleanUiText(
              entry.key.openAttiva
                  ? '${t('Open attiva', 'Open active')}: ${entry.key.openName.isEmpty ? entry.key.nome : entry.key.openName}'
                  : entry.key.tipo,
            ),
            backgroundColor: entry.key.openAttiva
                ? tertiaryColor
                : secondaryColor.withValues(alpha: 0.65),
            side: BorderSide(
              color: entry.key.openAttiva
                  ? tertiaryColor
                  : primaryColor.withValues(alpha: 0.55),
            ),
            labelStyle: TextStyle(
              color: entry.key.openAttiva ? Colors.black : primaryColor,
              fontWeight: FontWeight.w900,
              fontSize: compact ? 11 : 12,
            ),
            onPressed: () => vaiAllaFunzione(
              page: 2,
              anchorId: titleEditorAnchorId(
                entry.key,
                trattoRazziale: entry.value,
              ),
              logTitle: cleanUiText(entry.key.nome),
            ),
          ),
      ],
    );
  }

  Widget sheetCommandCenter() {
    final compact = lightweightUi;
    return gothicPanel(
      borderColor: tertiaryColor,
      padding: EdgeInsets.all(compact ? 10 : 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                Icons.auto_awesome,
                color: tertiaryColor,
                size: compact ? 18 : 24,
              ),
              SizedBox(width: compact ? 8 : 10),
              Expanded(
                child: Text(
                  t('Combattimento e centro partita', 'Combat and play center'),
                  style: TextStyle(
                    color: tertiaryColor,
                    fontSize: compact ? 15 : 18,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
              conditionImpactIndicator(
                target: OculumConditionTarget.combattimento,
              ),
              const SizedBox(width: 6),
              FilterChip(
                selected: modalitaVeloce,
                showCheckmark: false,
                avatar: Icon(
                  modalitaVeloce ? Icons.bolt : Icons.menu_book,
                  size: compact ? 14 : 16,
                  color: modalitaVeloce ? Colors.black : tertiaryColor,
                ),
                label: Text(
                  modalitaVeloce ? t('Veloce', 'Fast') : t('Guidata', 'Guided'),
                ),
                selectedColor: tertiaryColor,
                backgroundColor: const Color(0xFF0B0D16),
                labelStyle: TextStyle(
                  color: modalitaVeloce ? Colors.black : tertiaryColor,
                  fontWeight: FontWeight.w900,
                ),
                side: BorderSide(color: tertiaryColor.withValues(alpha: 0.65)),
                onSelected: (value) {
                  setState(() {
                    modalitaVeloce = value;
                    risultato = modalitaVeloce
                        ? t(
                            'Modalità veloce attiva: la scheda mostra prima le azioni essenziali.',
                            'Fast mode active: the sheet shows essential actions first.',
                          )
                        : t(
                            'Modalità guidata attiva: la scheda mostra più spiegazioni.',
                            'Guided mode active: the sheet shows more explanations.',
                          );
                    aggiungiLog(risultato);
                  });
                  programmaSalvataggio();
                },
              ),
            ],
          ),
          SizedBox(height: compact ? 7 : 10),
          if (!modalitaVeloce) ...[
            guidedExplanation(
              title: t('Cosa faccio adesso?', 'What do I do now?'),
              explanation: t(
                '1. Guarda HP e risorse. 2. Di al Master cosa vuoi fare. 3. Se serve un tiro, premi la statistica indicata. 4. Leggi il risultato e racconta cosa fa il personaggio. I pulsanti meno e piu correggono un valore a mano.',
                '1. Check HP and resources. 2. Tell the Game Master what you want to do. 3. If a roll is needed, press the requested stat. 4. Read the result and describe what your character does. Minus and plus adjust a value by hand.',
              ),
              example: t(
                'Esempio: vuoi colpire un mostro. Il Master chiede VC: premi VC, poi comunica il risultato.',
                'Example: you want to hit a monster. The Game Master asks for VC: press VC, then report the result.',
              ),
              icon: Icons.explore_outlined,
            ),
            SizedBox(height: compact ? 8 : 12),
          ],
          Wrap(
            spacing: compact ? 6 : 8,
            runSpacing: compact ? 6 : 8,
            children: [
              quickStatTile(
                label: 'HP',
                value: hpReadoutProtetto(),
                icon: vitaAfonaAttiva()
                    ? Icons.dangerous_rounded
                    : Icons.favorite,
                color: vitaAfonaAttiva() ? Colors.black : Colors.redAccent,
                onTap: vitaAfonaAttiva()
                    ? () => showConditionImpactDialog(
                        target: OculumConditionTarget.hp,
                        baseValue: '☠',
                        temporaryValue: '☠',
                        finalValue: '☠',
                      )
                    : () => apriDannoCuraDalCentroPartita(target: 'hp'),
                onRoll: vitaAfonaAttiva()
                    ? null
                    : () => tiraValoreSpeciale('HP', hpCorrenti()),
                onDecrease: vitaAfonaAttiva()
                    ? null
                    : () => modificaHpRapido(-1),
                onIncrease: vitaAfonaAttiva()
                    ? null
                    : () => modificaHpRapido(1),
              ),
              quickStatTile(
                label: t('Scudo', 'Shield'),
                value: '${scudo()}',
                icon: Icons.shield,
                color: Colors.lightBlueAccent,
                onTap: () => vaiAllaFunzione(
                  page: 0,
                  anchorId: 'sheet_shield',
                  logTitle: t('Scudo', 'Shield'),
                ),
                onRoll: () => tiraValoreSpeciale(t('Scudo', 'Shield'), scudo()),
                onDecrease: () => modificaScudoRapido(-1),
                onIncrease: () => modificaScudoRapido(1),
              ),
              if (shouldShowScudoOculum())
                quickStatTile(
                  label: t('Scudo Oculum', 'Oculum Shield'),
                  value: '${scudoOculum()}/${scudoOculumMax()}',
                  valueBuilder: () => '${scudoOculum()}/${scudoOculumMax()}',
                  icon: Icons.visibility,
                  color: eyePupilGlowColor,
                  onTap: () => vaiAllaFunzione(
                    page: 0,
                    anchorId: 'sheet_hp',
                    logTitle: t('Scudo Oculum', 'Oculum Shield'),
                  ),
                  onRoll: () => tiraValoreSpeciale(
                    t('Scudo Oculum', 'Oculum Shield'),
                    scudoOculum(),
                  ),
                  onDecrease: () {
                    setState(() {
                      modificaScudoOculum(-1);
                      risultato = t(
                        'Scudo Oculum -1: ${scudoOculum()}/${scudoOculumMax()}.',
                        'Oculum Shield -1: ${scudoOculum()}/${scudoOculumMax()}.',
                      );
                      aggiungiLog(risultato);
                    });
                    programmaSalvataggio();
                    sendRealtimeHpChanged();
                  },
                  onIncrease: () {
                    setState(() {
                      modificaScudoOculum(1);
                      risultato = t(
                        'Scudo Oculum +1: ${scudoOculum()}/${scudoOculumMax()}.',
                        'Oculum Shield +1: ${scudoOculum()}/${scudoOculumMax()}.',
                      );
                      aggiungiLog(risultato);
                    });
                    programmaSalvataggio();
                    sendRealtimeHpChanged();
                  },
                ),
              quickStatTile(
                label: 'VC',
                value: '${vc()}',
                icon: Icons.flash_on,
                color: tertiaryColor,
                onTap: () => vaiAllaFunzione(
                  page: 0,
                  anchorId: 'sheet_editable_values_volonta',
                ),
                onRoll: () => tiraValoreSpeciale(
                  'VC',
                  vc(),
                  applyGlobalRollModifier: false,
                ),
              ),
              quickStatTile(
                label: 'CM',
                value: '${cm()}',
                icon: Icons.security,
                color: primaryColor,
                onTap: () => vaiAllaFunzione(
                  page: 0,
                  anchorId: 'sheet_editable_values_materia',
                ),
                onRoll: () => tiraValoreSpeciale(
                  'CM',
                  cm(),
                  applyGlobalRollModifier: false,
                ),
              ),
              quickStatTile(
                label: t('Danno', 'Damage'),
                value: '${dannoTotale()}',
                icon: Icons.close,
                color: elementColor(elementoDannoDominante()),
                onTap: () => apriDannoCuraDalCentroPartita(target: 'damage'),
                onRoll: () =>
                    tiraValoreSpeciale(t('Danno', 'Damage'), dannoTotale()),
                onDecrease: () => modificaBuffMalusRapido(
                  rawKey: 'Danni',
                  label: t('Danno', 'Damage'),
                  delta: -1,
                ),
                onIncrease: () => modificaBuffMalusRapido(
                  rawKey: 'Danni',
                  label: t('Danno', 'Damage'),
                  delta: 1,
                ),
              ),
              Builder(
                builder: (context) {
                  final domDif = elementoDifesaDominante();
                  final labelDifesa =
                      t('Difesa', 'Defense') +
                      (domDif.isNotEmpty
                          ? ' — ${elementDisplayName(domDif)}'
                          : '');
                  return quickStatTile(
                    label: labelDifesa,
                    value: '${difesa()}',
                    icon: Icons.shield_outlined,
                    color: domDif.isNotEmpty
                        ? elementColor(domDif)
                        : Colors.lightGreenAccent,
                    onTap: () => vaiAllaFunzione(
                      page: 0,
                      anchorId: 'sheet_defense_bonus',
                      logTitle: t('Difesa', 'Defense'),
                    ),
                    onRoll: () =>
                        tiraValoreSpeciale(t('Difesa', 'Defense'), difesa()),
                    onDecrease: () => modificaDifesaRapida(-1),
                    onIncrease: () => modificaDifesaRapida(1),
                  );
                },
              ),
              quickStatTile(
                label: t('Reazioni', 'Reactions'),
                value: reazioniVelociTotali() > 0
                    ? '${reazioniTotali()} +${reazioniVelociTotali()}V'
                    : '${reazioniTotali()}',
                valueBuilder: () => reazioniVelociTotali() > 0
                    ? '${reazioniTotali()} +${reazioniVelociTotali()}V'
                    : '${reazioniTotali()}',
                icon: Icons.reply_all,
                color: Colors.orangeAccent,
                onTap: mostraModificaRapida,
                onRoll: () => tiraValoreSpeciale(
                  t('Reazioni', 'Reactions'),
                  reazioniTotali(),
                ),
                onDecrease: () => modificaControllerNumericoRapido(
                  reazioniController,
                  -1,
                  label: t('Reazioni', 'Reactions'),
                ),
                onIncrease: () => modificaControllerNumericoRapido(
                  reazioniController,
                  1,
                  label: t('Reazioni', 'Reactions'),
                ),
              ),
            ],
          ),
          SizedBox(height: compact ? 8 : 12),
          Row(
            children: [
              Icon(
                Icons.workspace_premium,
                color: primaryColor,
                size: compact ? 16 : 18,
              ),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  t('Titoli indossati', 'Equipped titles'),
                  style: TextStyle(
                    color: primaryColor,
                    fontWeight: FontWeight.w900,
                    fontSize: compact ? 12 : 13,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 7),
          equippedTitlesStrip(compact: compact),
          SizedBox(height: compact ? 8 : 12),
          Wrap(
            spacing: compact ? 6 : 8,
            runSpacing: compact ? 6 : 8,
            children: [
              quickCommandButton(
                label: t('Tira VC', 'Roll VC'),
                icon: Icons.casino,
                color: tertiaryColor,
                onPressed: () => tiraValoreSpeciale(
                  'VC',
                  vc(),
                  applyGlobalRollModifier: false,
                ),
              ),
              quickCommandButton(
                label: t('Tira CM', 'Roll CM'),
                icon: Icons.security,
                color: primaryColor,
                onPressed: () => tiraValoreSpeciale(
                  'CM',
                  cm(),
                  applyGlobalRollModifier: false,
                ),
              ),
              quickCommandButton(
                label: compact ? '+ATK' : '+1 Attacco',
                icon: Icons.flash_on,
                color: Colors.orangeAccent,
                onPressed: () => modificaAttaccoRapido(1),
              ),
              quickCommandButton(
                label: compact ? '+DIF' : '+1 Difesa',
                icon: Icons.shield_outlined,
                color: Colors.lightGreenAccent,
                onPressed: () => modificaDifesaRapida(1),
              ),
              quickCommandButton(
                label: t('Aiuta compagno', 'Help ally'),
                icon: Icons.volunteer_activism,
                color: const Color(0xFF7EE7C8),
                onPressed: tiraAiutaCompagno,
              ),
              quickCommandButton(
                label: scannerRiposiLunghi >= 3
                    ? 'Scanner'
                    : 'Scanner $scannerRiposiLunghi/3',
                icon: Icons.document_scanner_outlined,
                color: scannerRiposiLunghi >= 3
                    ? Colors.cyanAccent
                    : Colors.white38,
                onPressed: usaScannerCentroPartita,
              ),
              quickCommandButton(
                label: t('Modifica', 'Edit'),
                icon: Icons.tune,
                color: primaryColor,
                onPressed: mostraModificaRapida,
              ),
              if (!compact) ...[
                quickCommandButton(
                  label: t('Riposo', 'Rest'),
                  icon: Icons.hotel,
                  color: const Color(0xFF7EE7C8),
                  onPressed: () {
                    vaiAllaFunzione(
                      page: 1,
                      anchorId: 'rest_root',
                      logTitle: t('Riposo', 'Rest'),
                    );
                  },
                ),
                quickCommandButton(
                  label: t('Cerca regola', 'Find rule'),
                  icon: Icons.search,
                  color: Colors.lightBlueAccent,
                  onPressed: mostraCerca,
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }

  Future<void> usaScannerCentroPartita() async {
    if (scannerRiposiLunghi < 3) {
      setState(() {
        risultato = t(
          'Scanner non pronto: $scannerRiposiLunghi/3 riposi lunghi.',
          'Scanner not ready: $scannerRiposiLunghi/3 long rests.',
        );
        aggiungiLog(risultato);
      });
      return;
    }

    var areaDelProprioGrado = false;
    final confermato = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          backgroundColor: const Color(0xFF10121A),
          title: Row(
            children: [
              Icon(Icons.document_scanner_outlined, color: tertiaryColor),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  t('Usare lo Scanner?', 'Use the Scanner?'),
                  style: TextStyle(
                    color: tertiaryColor,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                t(
                  'Sei sicuro? Lo Scanner tornerà disponibile soltanto dopo 3 riposi lunghi.',
                  'Are you sure? The Scanner will become available again only after 3 long rests.',
                ),
                style: const TextStyle(fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 12),
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.orange.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.orangeAccent),
                ),
                child: Text(
                  t(
                    'Regola importante: puoi usare lo Scanner soltanto in un area del tuo stesso Grado.',
                    'Important rule: you may use the Scanner only in an area of your own Grade.',
                  ),
                ),
              ),
              const SizedBox(height: 10),
              CheckboxListTile(
                contentPadding: EdgeInsets.zero,
                value: areaDelProprioGrado,
                controlAffinity: ListTileControlAffinity.leading,
                title: Text(
                  t(
                    'Confermo di essere in un area del mio Grado.',
                    'I confirm that I am in an area of my Grade.',
                  ),
                ),
                onChanged: (value) =>
                    setDialogState(() => areaDelProprioGrado = value ?? false),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext, false),
              child: Text(t('Annulla', 'Cancel')),
            ),
            FilledButton.icon(
              onPressed: areaDelProprioGrado
                  ? () => Navigator.pop(dialogContext, true)
                  : null,
              icon: const Icon(Icons.document_scanner_outlined),
              label: Text(t('Usa Scanner', 'Use Scanner')),
            ),
          ],
        ),
      ),
    );
    if (confermato != true || !mounted) return;

    final fortunaStat = hiddenEyeStats.firstWhere(
      (stat) => stat.id == 'fortuna',
      orElse: () =>
          HiddenEyeStat(id: 'fortuna', nome: 'Fortuna', descrizione: ''),
    );
    final fortuna = max(0, hiddenEyeTotal(fortunaStat));
    final naturale = Random.secure().nextInt(20) + 1;
    final totaleScanner = naturale + fortuna;
    var obserOttenuta = 0;
    var esito = '';
    var creaTitoloItem = false;
    var bonusGradoTitolo = 0;

    if (naturale == 1) {
      esito = t('scontro obbligato difficile', 'mandatory difficult encounter');
    } else if (naturale <= 3) {
      esito = t('scontro obbligato', 'mandatory encounter');
    } else {
      final (facce, bonus) = switch (naturale) {
        <= 8 => (10, 0),
        <= 10 => (12, 3),
        <= 12 => (20, 5),
        <= 16 => (50, 10),
        <= 19 => (100, 15),
        _ => (120, 30),
      };
      final tiroObser = Random.secure().nextInt(facce) + 1;
      obserOttenuta = tiroObser + bonus;
      esito = '1d$facce${bonus > 0 ? '+$bonus' : ''} OBSER = $obserOttenuta';
      if (naturale >= 17) {
        creaTitoloItem = true;
        bonusGradoTitolo = naturale == 20 ? 1 : 0;
      }
    }

    final gradoTitolo = max(0, leggiNumero(gradoController)) + bonusGradoTitolo;
    final ascensionDustDaFortuna = fortuna > 0 ? max(1, fortuna ~/ 10) : 0;
    setState(() {
      scannerRiposiLunghi = 0;
      if (obserOttenuta > 0) {
        obserController.text = (leggiNumero(obserController) + obserOttenuta)
            .toString();
      }
      if (creaTitoloItem) {
        inventario.add(
          InventoryItem(
            nome: t(
              'Titolo Item Scanner — Grado $gradoTitolo',
              'Scanner Title Item — Grade $gradoTitolo',
            ),
            peso: 0,
            quantita: 1,
            note: t(
              'Ottenuto con Scanner. Da riferire al Master.',
              'Obtained with Scanner. Report it to the Master.',
            ),
            gradoOggetto: gradoTitolo,
          ),
        );
      }
      if (ascensionDustDaFortuna > 0) {
        ascensionDustController.text =
            (leggiNumero(ascensionDustController) + ascensionDustDaFortuna)
                .toString();
      }
      dadoMostrato = '$naturale + $fortuna = $totaleScanner';
      dadoMostratoFacce = 20;
      risultato = t(
        'Scanner: d20 naturale $naturale + Fortuna $fortuna = $totaleScanner. Esito sul solo dado naturale: $esito'
            '${ascensionDustDaFortuna > 0 ? '; Fortuna non contata nell’esito: +$ascensionDustDaFortuna Ascension Dust' : ''}'
            '${creaTitoloItem ? '; Titolo Item Grado $gradoTitolo aggiunto e da riferire al Master' : ''}.',
        'Scanner: natural d20 $naturale + Luck $fortuna = $totaleScanner. Outcome uses only the natural die: $esito'
            '${ascensionDustDaFortuna > 0 ? '; Luck not counted in the outcome: +$ascensionDustDaFortuna Ascension Dust' : ''}'
            '${creaTitoloItem ? '; Grade $gradoTitolo Title Item added and to be reported to the Master' : ''}.',
      );
      aggiungiLog(risultato);
    });
    mostraDadoCentrale(
      valore: '$naturale + $fortuna = $totaleScanner',
      criticoUno: naturale == 1,
      criticoVenti: naturale == 20,
    );
    programmaSalvataggio();
    notifyDiceResultChanged();
  }

  Widget quickGlanceCell(
    String label,
    String value,
    Color color, {
    VoidCallback? onTap,
  }) {
    final cell = Container(
      constraints: const BoxConstraints(minWidth: 86),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.10),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withValues(alpha: 0.42)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: color,
              fontSize: 10,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 3),
          Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 14,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
    if (onTap == null) return cell;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: cell,
    );
  }

  void showFortunaQuickEditor() {
    final fortunaController = TextEditingController(text: '$fortuna');
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: const Color(0xFF10121A),
      builder: (sheetContext) {
        return StatefulBuilder(
          builder: (context, setSheetState) {
            void applyFortunaValue(int value) {
              final next = max(0, value);
              setSheetState(() {
                fortuna = next;
                fortunaController.text = '$next';
                fortunaController.selection = TextSelection.collapsed(
                  offset: fortunaController.text.length,
                );
              });
              scheduleInputUiRefresh(delay: const Duration(milliseconds: 80));
              programmaSalvataggio();
            }

            return SafeArea(
              child: Padding(
                padding: EdgeInsets.fromLTRB(
                  12,
                  12,
                  12,
                  12 + MediaQuery.of(sheetContext).viewInsets.bottom,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      children: [
                        const Icon(
                          Icons.auto_awesome,
                          color: Color(0xFF9BE564),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            '${t('Fortuna', 'Luck')}: $fortuna',
                            style: const TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                        ),
                        IconButton(
                          tooltip: t('Diminuisci', 'Decrease'),
                          onPressed: () {
                            applyFortunaValue(fortuna - 1);
                            Navigator.pop(sheetContext);
                          },
                          icon: const Icon(Icons.remove_circle_outline),
                        ),
                        IconButton(
                          tooltip: t('Aumenta', 'Increase'),
                          onPressed: () {
                            applyFortunaValue(fortuna + 1);
                            Navigator.pop(sheetContext);
                          },
                          icon: const Icon(Icons.add_circle_outline),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: fortunaController,
                      keyboardType: const TextInputType.numberWithOptions(
                        signed: true,
                      ),
                      style: TextStyle(
                        fontSize: uiScale(16),
                        color: Colors.white,
                      ),
                      decoration: fieldDecoration(t('Fortuna', 'Luck')),
                      onChanged: (value) {
                        final parsed = int.tryParse(value.trim()) ?? 0;
                        setSheetState(() => fortuna = max(0, parsed));
                        scheduleInputUiRefresh(
                          delay: const Duration(milliseconds: 80),
                        );
                        programmaSalvataggio();
                      },
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    ).whenComplete(() {
      fortunaController.dispose();
      if (!mounted) return;
      setState(() {});
      programmaSalvataggio();
    });
  }

  void openReputationManagerSheet() {
    setState(ensureReputationDefaults);
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF10121A),
      builder: (sheetContext) {
        return StatefulBuilder(
          builder: (context, setSheetState) {
            return SafeArea(
              child: Padding(
                padding: EdgeInsets.fromLTRB(
                  12,
                  10,
                  12,
                  12 + MediaQuery.of(sheetContext).viewInsets.bottom,
                ),
                child: ConstrainedBox(
                  constraints: BoxConstraints(
                    maxHeight: MediaQuery.of(sheetContext).size.height * 0.82,
                  ),
                  child: ListView(
                    shrinkWrap: true,
                    children: [
                      ListTile(
                        leading: Icon(
                          Icons.location_city,
                          color: tertiaryColor,
                        ),
                        title: Text(
                          t('Reputazioni', 'Reputations'),
                          style: TextStyle(
                            color: tertiaryColor,
                            fontWeight: FontWeight.w900,
                          ),
                        ),
                        subtitle: Text(
                          t(
                            'Modifica manualmente ogni citta e il valore da -100 a +100.',
                            'Manually edit every city and its -100 to +100 value.',
                          ),
                          style: const TextStyle(color: Colors.white70),
                        ),
                      ),
                      for (var i = 0; i < reputations.length; i++) ...[
                        gothicPanel(
                          borderColor: Colors.amber.withValues(alpha: 0.55),
                          padding: const EdgeInsets.all(10),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Expanded(
                                    flex: 2,
                                    child: campoModello(
                                      fieldKey: ValueKey('rep_city_modal_$i'),
                                      label: t('Citta', 'City'),
                                      initialValue: reputations[i].cityName,
                                      onChanged: (value) {
                                        reputations[i].cityName = cleanUiText(
                                          value,
                                        );
                                        reputations[i].userModified = true;
                                      },
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  Expanded(
                                    child: campoModello(
                                      fieldKey: ValueKey('rep_value_modal_$i'),
                                      label: t('Valore', 'Value'),
                                      initialValue: '${reputations[i].value}',
                                      onChanged: (value) {
                                        final next =
                                            (int.tryParse(value.trim()) ?? 0)
                                                .clamp(-100, 100)
                                                .toInt();
                                        reputations[i].value = next;
                                        reputations[i].baseValue = next;
                                        reputations[i].userModified = true;
                                      },
                                    ),
                                  ),
                                  IconButton(
                                    tooltip: t('Cancella', 'Delete'),
                                    onPressed: () {
                                      setSheetState(() {
                                        reputations.removeAt(i);
                                        reputationsManuallyCleared =
                                            reputations.isEmpty;
                                      });
                                      setState(() {});
                                      programmaSalvataggio();
                                    },
                                    icon: const Icon(
                                      Icons.delete_outline,
                                      color: Colors.redAccent,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 8),
                              campoModello(
                                fieldKey: ValueKey('rep_desc_modal_$i'),
                                label: t('Descrizione', 'Description'),
                                initialValue: reputations[i].description,
                                maxLines: 2,
                                onChanged: (value) {
                                  reputations[i].description = cleanUiText(
                                    value,
                                  );
                                  reputations[i].userModified = true;
                                },
                              ),
                              const SizedBox(height: 6),
                              Text(
                                reputationLabel(reputations[i].value),
                                style: TextStyle(
                                  color: Colors.amber.shade200,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 8),
                      ],
                      Align(
                        alignment: Alignment.centerLeft,
                        child: OutlinedButton.icon(
                          onPressed: () {
                            setSheetState(() {
                              reputationsManuallyCleared = false;
                              reputations.add(
                                ReputationEntry(
                                  cityName: t('Nuova citta', 'New city'),
                                  description: '',
                                  value: 0,
                                  userModified: true,
                                ),
                              );
                            });
                            programmaSalvataggio();
                          },
                          icon: const Icon(Icons.add_location_alt),
                          label: Text(
                            t('Aggiungi reputazione', 'Add reputation'),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    ).whenComplete(() {
      if (mounted) setState(() {});
      programmaSalvataggio();
    });
  }

  void openHiddenEyeManagerSheet() {
    if (!hiddenEyeDefaultsReady()) {
      setState(ensureHiddenEyeDefaults);
    }
    var editedBaseValues = false;
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF10121A),
      builder: (sheetContext) {
        return StatefulBuilder(
          builder: (context, setSheetState) {
            return ValueListenableBuilder<int>(
              valueListenable: hiddenEyeListRevision,
              builder: (context, revision, child) {
                final visibleStats = hiddenEyeStatsForGroup(
                  hiddenEyeManagerSelectedGroup,
                );
                return SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
                    child: ConstrainedBox(
                      constraints: BoxConstraints(
                        maxHeight:
                            MediaQuery.of(sheetContext).size.height * 0.82,
                      ),
                      child: ListView(
                        controller: hiddenEyeManagerScrollController,
                        key: const PageStorageKey<String>(
                          'hidden_eye_manager_scroll',
                        ),
                        shrinkWrap: true,
                        children: [
                          ListTile(
                            leading: Icon(
                              Icons.remove_red_eye,
                              color: eyePupilGlowColor,
                            ),
                            title: Text(
                              t('Sottotratti dell\'Oculus', 'Oculus subtraits'),
                              style: TextStyle(
                                color: eyePupilGlowColor,
                                fontWeight: FontWeight.w900,
                              ),
                            ),
                            subtitle: Text(
                              t(
                                'Scegli la statistica base e tira 1d20 + sottotratto dell\'Oculus.',
                                'Choose the base stat and roll 1d20 + Oculus subtrait.',
                              ),
                              style: const TextStyle(color: Colors.white70),
                            ),
                          ),
                          Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            children: [
                              for (final group in const [
                                'resilienza',
                                'volonta',
                                'materia',
                                'oculum',
                                'altro',
                              ])
                                ChoiceChip(
                                  selected:
                                      hiddenEyeManagerSelectedGroup == group,
                                  label: Text(hiddenEyeGroupLabel(group)),
                                  onSelected: (_) {
                                    setSheetState(() {
                                      hiddenEyeManagerSelectedGroup = group;
                                    });
                                  },
                                ),
                            ],
                          ),
                          const SizedBox(height: 10),
                          hiddenEyeStatsGrid(
                            sheetContext: sheetContext,
                            group: hiddenEyeManagerSelectedGroup,
                            visibleStats: visibleStats,
                            onBaseEdited: () {
                              editedBaseValues = true;
                            },
                          ),
                          if (hiddenEyeManagerSelectedGroup == 'altro' &&
                              modalitaMaster) ...[
                            const SizedBox(height: 10),
                            OutlinedButton.icon(
                              onPressed: showCreateHomebrewSubtraitDialog,
                              icon: const Icon(Icons.add),
                              label: Text(
                                t(
                                  'Crea sottotratto Homebrew',
                                  'Create Homebrew subtrait',
                                ),
                              ),
                            ),
                          ],
                        ],
                      ),
                    ),
                  ),
                );
              },
            );
          },
        );
      },
    ).whenComplete(() {
      if (!mounted) return;
      if (!editedBaseValues) return;
      scheduleInputUiRefresh(delay: const Duration(milliseconds: 80));
      programmaSalvataggio();
    });
  }

  Widget hiddenEyeStatsGrid({
    required BuildContext sheetContext,
    required String group,
    required List<HiddenEyeStat> visibleStats,
    required VoidCallback onBaseEdited,
  }) {
    if (visibleStats.isEmpty) {
      return smallInfoText(
        t(
          'Nessun sottotratto dell\'Oculus in questa categoria.',
          'No Oculus subtrait in this category.',
        ),
      );
    }

    final rowHeight = uiScale(
      visibleStats.any((stat) => stat.homebrew) ? 208 : 172,
    );
    return GridView.builder(
      key: PageStorageKey<String>('hidden_eye_grid_$group'),
      primary: false,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: visibleStats.length,
      gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
        maxCrossAxisExtent: 258,
        mainAxisExtent: rowHeight,
        crossAxisSpacing: 8,
        mainAxisSpacing: 8,
      ),
      itemBuilder: (context, index) {
        final stat = visibleStats[index];
        return KeyedSubtree(
          key: ValueKey<String>(
            'hidden_eye_stat_${currentSheetScrollId()}_${stat.id}',
          ),
          child: hiddenEyeStatManagerCard(
            sheetContext: sheetContext,
            stat: stat,
            onBaseEdited: onBaseEdited,
          ),
        );
      },
    );
  }

  Future<void> showCreateHomebrewSubtraitDialog() async {
    final name = TextEditingController();
    final description = TextEditingController();
    final base = TextEditingController(text: '0');
    final created = await showDialog<HiddenEyeStat>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(t('Nuovo sottotratto Homebrew', 'New Homebrew subtrait')),
        content: SizedBox(
          width: 480,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: name,
                decoration: InputDecoration(labelText: t('Nome', 'Name')),
              ),
              TextField(
                controller: description,
                minLines: 2,
                maxLines: 5,
                decoration: InputDecoration(
                  labelText: t('Descrizione', 'Description'),
                ),
              ),
              TextField(
                controller: base,
                keyboardType: const TextInputType.numberWithOptions(
                  signed: true,
                ),
                decoration: InputDecoration(
                  labelText: t('Valore base', 'Base value'),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(t('Annulla', 'Cancel')),
          ),
          FilledButton(
            onPressed: () {
              final visibleName = name.text.trim();
              if (visibleName.isEmpty) return;
              final slug = oculumNormalizeText(visibleName)
                  .replaceAll(RegExp(r'[^a-z0-9]+'), '_')
                  .replaceAll(RegExp(r'^_+|_+$'), '');
              Navigator.pop(
                context,
                HiddenEyeStat(
                  id: 'homebrew_${slug}_${DateTime.now().millisecondsSinceEpoch}',
                  nome: visibleName,
                  descrizione: description.text.trim(),
                  valore: int.tryParse(base.text.trim()) ?? 0,
                  category: 'altro',
                  homebrew: true,
                ),
              );
            },
            child: Text(t('Crea', 'Create')),
          ),
        ],
      ),
    );
    name.dispose();
    description.dispose();
    base.dispose();
    if (created == null) return;
    hiddenEyeStats.add(created);
    hiddenEyeManagerSelectedGroup = 'altro';
    invalidateHiddenEyeDerivedCaches();
    programmaSalvataggio();
  }

  Widget hiddenEyeStatDynamic({
    required HiddenEyeStat stat,
    required Widget Function(BuildContext context) builder,
  }) {
    return ValueListenableBuilder<int>(
      valueListenable: hiddenEyeStatListenable(stat),
      builder: (context, revision, child) => builder(context),
    );
  }

  Widget hiddenEyeStatRollButton({
    required BuildContext sheetContext,
    required HiddenEyeStat stat,
  }) {
    return ElevatedButton.icon(
      onPressed: () {
        hiddenEyeManagerSelectedGroup = hiddenEyeStatGroup(stat.id);
        hiddenEyeManagerSelectedStatId = stat.id;
        Navigator.pop(sheetContext);
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (!mounted) return;
          unawaited(tiraSottotrattoOcchio(stat));
        });
      },
      icon: const Icon(Icons.add),
      label: hiddenEyeStatDynamic(
        stat: stat,
        builder: (context) {
          return Text('${stat.nome} +${hiddenEyeTotal(stat)}');
        },
      ),
      style: ElevatedButton.styleFrom(
        backgroundColor: eyePupilGlowColor,
        foregroundColor: eyePupilGlowColor.computeLuminance() > 0.45
            ? Colors.black
            : Colors.white,
      ),
    );
  }

  Widget hiddenEyeStatProgressBar(HiddenEyeStat stat) {
    return hiddenEyeStatDynamic(
      stat: stat,
      builder: (context) {
        return ClipRRect(
          borderRadius: BorderRadius.circular(999),
          child: SizedBox(
            height: 5,
            child: LinearProgressIndicator(
              value: oculusSubtraitMasteryFraction(
                progress: stat.masteryProgress,
                grade: stat.valore,
              ),
              backgroundColor: Colors.white.withValues(alpha: 0.10),
              valueColor: AlwaysStoppedAnimation<Color>(eyePupilGlowColor),
            ),
          ),
        );
      },
    );
  }

  Widget hiddenEyeStatBaseControls({
    required HiddenEyeStat stat,
    required VoidCallback onBaseEdited,
  }) {
    void applyBaseDelta(int delta) {
      stat.valore += delta;
      onBaseEdited();
      notifyHiddenEyeStatChanged(stat);
      scheduleHiddenEyeProgressSave();
    }

    return Row(
      children: [
        IconButton(
          tooltip: t('Riduci base', 'Lower base'),
          onPressed: () => applyBaseDelta(-1),
          icon: const Icon(Icons.remove_circle_outline),
        ),
        Expanded(
          child: hiddenEyeStatDynamic(
            stat: stat,
            builder: (context) {
              return Text(
                '${t('Base', 'Base')} ${stat.valore}\n${t('Totale', 'Total')} ${hiddenEyeTotal(stat)}',
                textAlign: TextAlign.center,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: Colors.white70,
                  fontWeight: FontWeight.bold,
                ),
              );
            },
          ),
        ),
        IconButton(
          tooltip: t('Aumenta base', 'Raise base'),
          onPressed: () => applyBaseDelta(1),
          icon: const Icon(Icons.add_circle_outline),
        ),
      ],
    );
  }

  Widget hiddenEyeStatDescription(HiddenEyeStat stat) {
    return smallInfoText(stat.descrizione, color: Colors.grey.shade400);
  }

  Widget hiddenEyeStatManagerCard({
    required BuildContext sheetContext,
    required HiddenEyeStat stat,
    required VoidCallback onBaseEdited,
  }) {
    return RepaintBoundary(
      child: gothicPanel(
        borderColor: hiddenEyeManagerSelectedStatId == stat.id
            ? tertiaryColor
            : eyePupilGlowColor,
        padding: const EdgeInsets.all(8),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (stat.homebrew)
              Align(
                alignment: Alignment.centerRight,
                child: Chip(
                  visualDensity: VisualDensity.compact,
                  label: Text(t('Homebrew', 'Homebrew')),
                ),
              ),
            hiddenEyeStatRollButton(sheetContext: sheetContext, stat: stat),
            const SizedBox(height: 8),
            hiddenEyeStatProgressBar(stat),
            hiddenEyeStatBaseControls(stat: stat, onBaseEdited: onBaseEdited),
            hiddenEyeStatDescription(stat),
          ],
        ),
      ),
    );
  }

  Widget occhiataVeloceRaWidget() {
    return dropdownSection(
      title: t('Occhiata veloce', 'Quick glance'),
      subtitle: t(
        'Nome, fase, risorse, karma e sottotratti dell\'Oculus sbloccati.',
        'Name, phase, resources, karma and unlocked Oculus subtraits.',
      ),
      icon: Icons.visibility,
      borderColor: const Color(0xFFC9A44C),
      sectionId: 'sheet_quick_glance',
      initiallyExpanded: false,
      child: ValueListenableBuilder<int>(
        valueListenable: activeSheetSummaryRevision,
        builder: (context, revision, child) => _occhiataVeloceContent(),
      ),
    );
  }

  Widget _occhiataVeloceContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          cleanUiText(nomeController.text).trim().isEmpty
              ? '???'
              : cleanUiText(nomeController.text),
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
            color: primaryColor,
            fontSize: 22,
            fontWeight: FontWeight.w900,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          '${razzaVisibile()} | ${t('Livello', 'Level')} ${leggiNumero(livelloController)} | Rebirth ${rebirthato ? t('si', 'yes') : t('no', 'no')}',
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(
            color: Colors.white70,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 10),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            quickGlanceCell('RES', '${resilienzaTotale()}', Colors.redAccent),
            quickGlanceCell('VOL', '${volontaTotale()}', tertiaryColor),
            quickGlanceCell('MAT', '${materiaTotale()}', Colors.lightBlue),
            quickGlanceCell('OCU', '${oculumTotale()}', eyePupilGlowColor),
            quickGlanceCell('KARMA', karmaStateLabel(), Colors.amber),
            quickGlanceCell('OBSER', obserController.text, Colors.orange),
            quickGlanceCell(
              t('Fase', 'Phase'),
              oculumCurrentDayController.text,
              const Color(0xFF7EE7C8),
            ),
            quickGlanceCell(
              t('Fortuna', 'Luck'),
              '$fortuna',
              const Color(0xFF9BE564),
              onTap: showFortunaQuickEditor,
            ),
          ],
        ),
        const SizedBox(height: 10),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            for (final difficulty in const [
              'oculum',
              'difficile',
              'normale',
              'facile',
            ])
              ChoiceChip(
                selected: normalizedCampaignDifficulty() == difficulty,
                label: Text(
                  '${campaignDifficultyLabel(difficulty)} · ${t('Crit', 'Crit')} +${oculumCriticalDamageBonusForDifficulty(difficulty)}',
                ),
                onSelected: (_) {
                  setState(() {
                    handleDifficultyChange(difficulty);
                    campaignDifficulty = difficulty;
                    final starterShield = applyFirstEasyDifficultyShieldReward(
                      difficulty,
                    );
                    risultato = t(
                      'Difficolta campagna: ${campaignDifficultyLabel(difficulty)}.$starterShield',
                      'Campaign difficulty: ${campaignDifficultyLabel(difficulty)}.$starterShield',
                    );
                    aggiungiLog(risultato);
                  });
                  for (var i = 0; i < arti.length; i++) {
                    notifyArtActivationAvailableChanged(i);
                  }
                  final fightDifficulty = getCondition(
                    'aumento_difficolta',
                  )?.metadata['enemyDifficulty'];
                  if (fightDifficulty != null) {
                    setFightEnemyDifficulty('$fightDifficulty');
                  }
                  notifyConditionsChanged(
                    activeConditions
                        .where(
                          (instance) =>
                              oculumConditionDefinition(
                                    instance.conditionType,
                                  )?.polarity ==
                                  OculumConditionPolarity.positive ||
                              instance.conditionType == 'aumento_difficolta',
                        )
                        .expand(conditionTargetsFor),
                  );
                  programmaSalvataggio();
                },
              ),
          ],
        ),
        const SizedBox(height: 8),
        smallInfoText(
          normalizedCampaignDifficulty() == 'oculum'
              ? t(
                  'Sfortuna Oculum: 3% che un danno diventi critico; 5% che infligga +100% danni a Scudo e Scudo Oculum.',
                  'Oculum Misfortune: 3% for damage to become critical; 5% for +100% damage to Shield and Oculum Shield.',
                )
              : normalizedCampaignDifficulty() == 'difficile'
              ? t(
                  'Sfortuna Difficile: 1% che un danno diventi critico; 2% che infligga +50% danni allo Scudo.',
                  'Hard Misfortune: 1% for damage to become critical; 2% for +50% damage to Shield.',
                )
              : t(
                  'La Sfortuna si attiva da Difficile in su.',
                  'Misfortune activates from Hard difficulty onward.',
                ),
        ),
        const SizedBox(height: 8),
        ExpansionTile(
          tilePadding: EdgeInsets.zero,
          childrenPadding: EdgeInsets.zero,
          leading: const Icon(Icons.search),
          title: Text(
            t('Lente GUI', 'GUI lens'),
            style: TextStyle(color: primaryColor, fontWeight: FontWeight.w900),
          ),
          subtitle: Text(
            '${(userGuiScale * 100).round()}%',
            style: const TextStyle(color: Colors.white70),
          ),
          children: [
            Slider(
              min: 0.82,
              max: 1.18,
              divisions: 18,
              value: userGuiScale.clamp(0.82, 1.18).toDouble(),
              label: '${(userGuiScale * 100).round()}%',
              onChanged: (value) {
                setState(
                  () => userGuiScale = value.clamp(0.82, 1.18).toDouble(),
                );
              },
              onChangeEnd: (_) => programmaSalvataggio(),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: [
            OutlinedButton.icon(
              onPressed: openReputationManagerSheet,
              icon: const Icon(Icons.location_city),
              label: Text(t('Reputazioni', 'Reputations')),
            ),
            OutlinedButton.icon(
              onPressed: openHiddenEyeManagerSheet,
              icon: const Icon(Icons.remove_red_eye),
              label: Text(t('Sottotratti Oculus', 'Oculus subtraits')),
            ),
          ],
        ),
      ],
    );
  }

  Widget editableMainValuesDropdown() {
    if (!mostraValoriEditabiliScheda) return const SizedBox.shrink();

    return dropdownSection(
      title: t('Valori principali modificabili', 'Editable main values'),
      subtitle: t(
        'Numeri che cambiano spesso durante la sessione.',
        'Numbers that often change during play.',
      ),
      icon: Icons.tune,
      borderColor: tertiaryColor,
      sectionId: 'sheet_editable_values',
      initiallyExpanded: false,
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: campoTesto(
                  label: t('Livello', 'Level'),
                  controller: livelloController,
                  helper: t(
                    'Aumenta esperienza, tiri e bonus di grado.',
                    'Raises experience, rolls and grade bonuses.',
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: campoTesto(
                  label: t('Grado', 'Grade'),
                  controller: gradoController,
                  helper: t(
                    'Scala molti bonus: ogni grado pesa molto.',
                    'Scales many bonuses: each grade matters a lot.',
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: campoTesto(
                  label: t('HP Attuali', 'Current HP'),
                  controller: currentHpController,
                  helper: t('La vita reale rimasta.', 'Real health remaining.'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: campoTesto(
                  label: 'HP Temp',
                  controller: hpTempController,
                  helper: t(
                    'Vita provvisoria prima degli HP reali.',
                    'Temporary health before real HP.',
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: functionAnchor(
                  'sheet_shield',
                  campoTesto(
                    label: t('Scudo', 'Shield'),
                    controller: scudoController,
                    focusNode: scudoFocusNode,
                    helper: t(
                      'Assorbe danni prima degli HP.',
                      'Absorbs damage before HP.',
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: campoTesto(
                  label: t('Scudo Critico', 'Critical Shield'),
                  controller: scudoCriticoController,
                  helper: t(
                    'Dimezza i danni finché resta attivo.',
                    'Halves damage while active.',
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: functionAnchor(
                  'sheet_attack_bonus',
                  campoTesto(
                    label: t('Bonus VC', 'VC Bonus'),
                    controller: attaccoRapidoController,
                    focusNode: attaccoRapidoFocusNode,
                    helper: t(
                      'Modifica soltanto VC; i bonus danno restano separati.',
                      'Changes VC only; damage bonuses stay separate.',
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: functionAnchor(
                  'sheet_defense_bonus',
                  campoTesto(
                    label: t('Bonus Difesa', 'Defense Bonus'),
                    controller: difesaRapidaController,
                    focusNode: difesaRapidaFocusNode,
                    helper: t(
                      'Modifica rapida alla Difesa totale.',
                      'Quick modifier to total Defense.',
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          campoTesto(
            label: t('Bonus CM', 'CM Bonus'),
            controller: cmRapidoController,
            helper: t(
              'Bonus testuale/numerico rapido al tiro CM.',
              'Quick textual/numeric bonus to CM rolls.',
            ),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: campoTesto(
                  label: t('Resilienza', 'Resilience'),
                  controller: resilienzaController,
                  focusNode: resilienzaFocusNode,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: campoTesto(
                  label: t('Volontà', 'Will'),
                  controller: volontaController,
                  focusNode: volontaFocusNode,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: campoTesto(
                  label: 'Materia',
                  controller: materiaController,
                  focusNode: materiaFocusNode,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: campoTesto(
                  label: 'Oculum',
                  controller: oculumController,
                  focusNode: oculumFocusNode,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          smallInfoText(
            t(
              'Le stats attuali possono scendere quando le spendi. I totali visibili coincidono con le statistiche e includono i buff attivi.',
              'Current stats can drop when spent. Visible totals match the stats and include active buffs.',
            ),
            color: tertiaryColor,
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: campoStatAttualeVisibile(
                  label: t('Resilienza attuale', 'Current Resilience'),
                  key: 'resilienza',
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: campoStatAttualeVisibile(
                  label: t('Volontà attuale', 'Current Will'),
                  key: 'volonta',
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: campoStatAttualeVisibile(
                  label: t('Materia attuale', 'Current Materia'),
                  key: 'materia',
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: campoStatAttualeVisibile(
                  label: t('Oculum attuale', 'Current Oculum'),
                  key: 'oculum',
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              quickCommandButton(
                label: '+1 Attacco',
                icon: Icons.flash_on,
                color: Colors.orangeAccent,
                onPressed: () => modificaAttaccoRapido(1),
              ),
              quickCommandButton(
                label: '-1 Attacco',
                icon: Icons.flash_off,
                color: Colors.orangeAccent,
                onPressed: () => modificaAttaccoRapido(-1),
              ),
              quickCommandButton(
                label: '+1 Difesa',
                icon: Icons.shield_outlined,
                color: Colors.lightGreenAccent,
                onPressed: () => modificaDifesaRapida(1),
              ),
              quickCommandButton(
                label: '-1 Difesa',
                icon: Icons.shield,
                color: Colors.lightGreenAccent,
                onPressed: () => modificaDifesaRapida(-1),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Color karmaUiColor() {
    final k = karmaTotale();
    if (k > 0) return Colors.greenAccent;
    if (k < 0) return Colors.redAccent;
    return tertiaryColor;
  }

  Widget karmaInfoBox() {
    return Expanded(
      child: gothicPanel(
        borderColor: karmaUiColor(),
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            Text(
              'Karma',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: karmaUiColor(),
                fontWeight: FontWeight.bold,
                fontSize: 14,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              '${karmaTotale()}',
              style: TextStyle(
                color: karmaUiColor(),
                fontSize: 25,
                fontWeight: FontWeight.w900,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget compactNumericEditField({
    required String label,
    required TextEditingController controller,
    Color? color,
    String? helper,
    String? displayValue,
    VoidCallback? onSaved,
  }) {
    final fieldColor = color ?? primaryColor;

    Future<void> editValue() async {
      final temp = TextEditingController(text: controller.text);
      try {
        await showDialog<void>(
          context: context,
          builder: (dialogContext) {
            return AlertDialog(
              backgroundColor: const Color(0xFF10121A),
              title: Text(
                cleanUiText(label),
                style: TextStyle(
                  color: fieldColor,
                  fontWeight: FontWeight.w900,
                ),
              ),
              content: TextField(
                controller: temp,
                autofocus: true,
                keyboardType: TextInputType.number,
                textAlign: TextAlign.center,
                cursorColor: fieldColor,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.w900,
                ),
                decoration: fieldDecoration(t('Valore', 'Value')),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(dialogContext),
                  child: Text(t('Annulla', 'Cancel')),
                ),
                ElevatedButton(
                  onPressed: () {
                    controller.text = max(
                      0,
                      readIntValue(temp.text),
                    ).toString();
                    onSaved?.call();
                    if (mounted) setState(() {});
                    programmaSalvataggio();
                    Navigator.pop(dialogContext);
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: fieldColor,
                    foregroundColor: fieldColor.computeLuminance() > 0.45
                        ? Colors.black
                        : Colors.white,
                  ),
                  child: Text(t('Salva', 'Save')),
                ),
              ],
            );
          },
        );
      } finally {
        temp.dispose();
      }
    }

    final fieldTile = quickContextMenuAnchor(
      label: label,
      onEdit: editValue,
      child: Container(
        constraints: const BoxConstraints(minHeight: 54),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: const Color(0xFF07080D),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: fieldColor.withValues(alpha: 0.66)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              cleanUiText(label),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: fieldColor,
                fontSize: 11,
                fontWeight: FontWeight.w900,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              displayValue ?? '${max(0, readIntValue(controller.text))}',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 17,
                fontWeight: FontWeight.w900,
                height: 1,
              ),
            ),
            if (helper != null && helper.trim().isNotEmpty) ...[
              const SizedBox(height: 4),
              Text(
                cleanUiText(helper),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: Colors.grey.shade400,
                  fontSize: 9.5,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ],
        ),
      ),
    );

    return Tooltip(
      message: t('Tocca per modificare', 'Tap to edit'),
      child: InkWell(
        onTap: editValue,
        borderRadius: BorderRadius.circular(10),
        child: fieldTile,
      ),
    );
  }

  Widget compactScudoOculumEditField() {
    return compactNumericEditField(
      label: t('Scudo Oculum', 'Oculum Shield'),
      controller: scudoOculumController,
      color: eyePupilGlowColor,
      displayValue: '${scudoOculum()}/${scudoOculumMax()}',
      helper: t('Prima degli altri scudi.', 'Before other shields.'),
      onSaved: () {
        final current = max(0, readIntValue(scudoOculumController.text));
        final maximum = scudoOculumMax();
        if (current > maximum) {
          final bonus = scudoOculumBonusMassimo();
          scudoOculumMaxController.text = max(0, current - bonus).toString();
        }
      },
    );
  }

  Widget compactScudoOculumMaxEditField() {
    return compactNumericEditField(
      label: t('Max Scudo Oculum', 'Max Oculum Shield'),
      controller: scudoOculumMaxController,
      color: eyePupilGlowColor,
      displayValue: scudoOculumMax().toString(),
      helper: scudoOculumBonusMassimo() == 0
          ? t('Massimo manuale.', 'Manual maximum.')
          : '${t('Manuale + buff', 'Manual + buff')}: ${scudoOculumMassimoManuale()} ${scudoOculumBonusMassimo() >= 0 ? '+' : ''}${scudoOculumBonusMassimo()}',
      onSaved: () {
        final maximum = scudoOculumMax();
        final current = max(0, readIntValue(scudoOculumController.text));
        if (maximum <= 0) {
          scudoOculumController.text = '0';
        } else if (current > maximum) {
          scudoOculumController.text = maximum.toString();
        }
      },
    );
  }

  Widget hpModePanel() {
    return dropdownSection(
      title: t('Vita: barra o modifica', 'HP: bar or edit'),
      subtitle: t(
        'Controllo rapido di HP, HP temp e scudi.',
        'Quick control for HP, temp HP and shields.',
      ),
      icon: Icons.favorite,
      borderColor: primaryColor,
      sectionId: 'sheet_hp',
      child: Column(
        children: [
          reportedTurnCard(),
          activeStructuredEffectsCard(),
          const SizedBox(height: 10),
          SwitchListTile(
            value: usaBarraVita,
            activeThumbColor: tertiaryColor,
            title: Text(t('Mostra barra vita', 'Show HP bar')),
            subtitle: Text(
              usaBarraVita
                  ? t(
                      'Vedi la vita come barra grafica.',
                      'View HP as a visual bar.',
                    )
                  : t(
                      'Modifica la vita con campi numerici.',
                      'Edit HP with numeric fields.',
                    ),
            ),
            onChanged: (value) {
              setState(() => usaBarraVita = value);
              programmaSalvataggio();
            },
          ),
          if (usaBarraVita) ...[
            const SizedBox(height: 8),
            if (!modalitaVeloce)
              Align(
                alignment: Alignment.centerLeft,
                child: OutlinedButton.icon(
                  onPressed: showLifeBarStyleGallery,
                  icon: const Icon(Icons.palette_outlined),
                  label: Text(
                    '${t('Stile Vita', 'Health style')}: ${lifeBarStyleLabel(stileBarraVita)}',
                  ),
                ),
              ),
          ],
          if (usaBarraVita) lifeBarWithStyleContextMenu(),
          if (usaBarraVita) ...[
            const SizedBox(height: 10),
            savingShieldPanel(dense: stileBarraVita == 'oculum_alternativa'),
          ],
          if (usaBarraVita && stileBarraVita != 'oculum_alternativa')
            oculumShieldPanel(),
          if (!usaBarraVita) ...[
            LayoutBuilder(
              builder: (context, constraints) {
                final compact = constraints.maxWidth < 520;
                final singleColumn = constraints.maxWidth < 360;
                final fields = [
                  compactNumericEditField(
                    label: t('HP Attuali', 'Current HP'),
                    controller: currentHpController,
                    color: Colors.redAccent,
                    helper: t('Vita reale rimasta.', 'Real HP left.'),
                  ),
                  compactNumericEditField(
                    label: 'HP Temp',
                    controller: hpTempController,
                    color: const Color(0xFF7EE7C8),
                    helper: t('Prima degli HP.', 'Before real HP.'),
                  ),
                  compactNumericEditField(
                    label: t('Scudo', 'Shield'),
                    controller: scudoController,
                    color: const Color(0xFF44A7FF),
                    helper: t('Prima degli HP Temp.', 'Before temp HP.'),
                  ),
                  if (shouldShowScudoOculum()) ...[
                    compactScudoOculumEditField(),
                    compactScudoOculumMaxEditField(),
                  ],
                ];

                if (singleColumn) {
                  return Column(
                    children: [
                      for (var i = 0; i < fields.length; i++) ...[
                        fields[i],
                        if (i < fields.length - 1) const SizedBox(height: 8),
                      ],
                    ],
                  );
                }

                if (compact) {
                  return Column(
                    children: [
                      for (var i = 0; i < fields.length; i += 2) ...[
                        Row(
                          children: [
                            Expanded(child: fields[i]),
                            if (i + 1 < fields.length) ...[
                              const SizedBox(width: 8),
                              Expanded(child: fields[i + 1]),
                            ] else
                              const Spacer(),
                          ],
                        ),
                        if (i + 2 < fields.length) const SizedBox(height: 8),
                      ],
                    ],
                  );
                }

                final columns = fields.length.clamp(3, 5).toInt();

                return Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    for (final field in fields)
                      SizedBox(
                        width:
                            (constraints.maxWidth - (columns - 1) * 8) /
                            columns,
                        child: field,
                      ),
                  ],
                );
              },
            ),
            const SizedBox(height: 10),
            savingShieldPanel(),
          ],
          const SizedBox(height: 10),
          impactOptionsPanel(),
          const SizedBox(height: 10),
          Align(
            alignment: Alignment.centerLeft,
            child: ElevatedButton.icon(
              onPressed: refullVita,
              icon: const Icon(Icons.favorite),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.redAccent.shade700,
                foregroundColor: Colors.white,
              ),
              label: Text(t('Refull Vita', 'Refill HP')),
            ),
          ),
        ],
      ),
    );
  }

  Widget impactOptionsPanel() {
    return gothicPanel(
      borderColor: eyePupilGlowColor,
      padding: const EdgeInsets.all(10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            t('Opzioni impatto', 'Impact options'),
            style: TextStyle(
              color: eyePupilGlowColor,
              fontSize: 13,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 8),
          LayoutBuilder(
            builder: (context, constraints) {
              Widget compactCheck({
                required String label,
                required bool value,
                required ValueChanged<bool?> onChanged,
              }) {
                return CheckboxListTile(
                  dense: true,
                  visualDensity: VisualDensity.compact,
                  contentPadding: EdgeInsets.zero,
                  controlAffinity: ListTileControlAffinity.leading,
                  activeColor: tertiaryColor,
                  checkColor: tertiaryColor.computeLuminance() > 0.45
                      ? Colors.black
                      : Colors.white,
                  title: Text(
                    label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 12,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  value: value,
                  onChanged: onChanged,
                );
              }

              final checks = [
                compactCheck(
                  label: t('Oltre difesa', 'Beyond defense'),
                  value: dannoOltreDifesa,
                  onChanged: (value) {
                    setState(() => dannoOltreDifesa = value ?? false);
                    programmaSalvataggio(invalidateCaches: false);
                  },
                ),
                compactCheck(
                  label: t('Oltre scudi', 'Beyond shields'),
                  value: dannoOltreScudi,
                  onChanged: (value) {
                    setState(() => dannoOltreScudi = value ?? false);
                    programmaSalvataggio(invalidateCaches: false);
                  },
                ),
              ];

              if (constraints.maxWidth < 420) return Column(children: checks);
              return Row(
                children: [
                  Expanded(child: checks[0]),
                  const SizedBox(width: 10),
                  Expanded(child: checks[1]),
                ],
              );
            },
          ),
          const SizedBox(height: 8),
          campoTesto(
            label: t('Bonus danno agli scudi %', 'Shield damage bonus %'),
            controller: dannoBonusScudoPercentController,
            helper: t(
              'Solo per colpi che danneggiano meglio gli scudi. 0 = nessun bonus.',
              'Only for hits that damage shields better. 0 = no bonus.',
            ),
          ),
        ],
      ),
    );
  }

  void addIncomingDamageRule(String command, String element) {
    final current = buffMalusRapidiController.text.trim();
    final rule = '@$command $element';
    setState(() {
      buffMalusRapidiController.text = current.isEmpty
          ? rule
          : '$current\n$rule';
      risultato = t(
        'Regola danni subiti attiva: $rule.',
        'Incoming damage rule active: $rule.',
      );
      aggiungiLog(risultato);
    });
    programmaSalvataggio();
  }

  void clearIncomingDamageRules() {
    final cleaned = buffMalusRapidiController.text
        .replaceAll(
          RegExp(
            r'\s*@(ResistenzaImpenetrabile|Resistenza|FragilitaVera|Fragilita|Fragilit[aà]Vera|Fragilit[aà]|DanniSubiti)\s*[+-]?\s*\d*\s*%?\s*[^@\n,;]*',
            caseSensitive: false,
          ),
          '',
        )
        .trim();
    setState(() {
      buffMalusRapidiController.text = cleaned;
      risultato = t(
        'Resistenze rapide tornate a Normale.',
        'Quick resistances returned to Normal.',
      );
      aggiungiLog(risultato);
    });
    programmaSalvataggio();
  }

  Widget incomingDamageRulesQuickPanel() {
    return const SizedBox.shrink();
  }

  void setTypeSwitchElement(String elementId) {
    final id = oculumNormalizeElementId(elementId);
    if (id.isEmpty || !allDamageElementIds().contains(id)) return;

    final label = elementDisplayName(id);
    final cleaned = buffMalusRapidiController.text
        .replaceAll(
          RegExp(
            r'\s*@(?:type\s*switch|typeswitch|tipo\s*switch|cambio\s*tipo)\s*[:=]?\s*[^@,;\n]+',
            caseSensitive: false,
          ),
          '',
        )
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();

    setState(() {
      buffMalusRapidiController.text = [
        cleaned,
        '@TypeSwitch $label',
      ].where((part) => part.trim().isNotEmpty).join(' ');
      risultato = t(
        'TypeSwitch attivo: il danno originario ora e $label.',
        'TypeSwitch active: original damage is now $label.',
      );
      aggiungiLog(risultato);
    });
    programmaSalvataggio();
  }

  void clearTypeSwitchElement() {
    final cleaned = buffMalusRapidiController.text
        .replaceAll(
          RegExp(
            r'\s*@(?:type\s*switch|typeswitch|tipo\s*switch|cambio\s*tipo)\s*[:=]?\s*[^@,;\n]+',
            caseSensitive: false,
          ),
          '',
        )
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
    setState(() {
      buffMalusRapidiController.text = cleaned;
      risultato = t('TypeSwitch rimosso.', 'TypeSwitch removed.');
      aggiungiLog(risultato);
    });
    programmaSalvataggio();
  }

  Widget typeSwitchQuickPanel() {
    final ids = allDamageElementIds();
    final active = activeTypeSwitchElement();
    final rawDamage = danniPerElemento(applyTypeSwitch: false);
    final quickIds = <String>{
      for (final entry
          in rawDamage.entries.toList()
            ..sort((a, b) => b.value.compareTo(a.value)))
        entry.key,
      if (active.isNotEmpty) active,
    }.where((id) => ids.contains(id)).take(8).toList();

    return gothicPanel(
      borderColor: active.isEmpty
          ? Colors.white24
          : elementColor(active).withValues(alpha: 0.85),
      padding: const EdgeInsets.all(10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                Icons.swap_horiz,
                color: active.isEmpty ? Colors.white70 : elementColor(active),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  t('TypeSwitch danno', 'Damage TypeSwitch'),
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
              if (active.isNotEmpty)
                IconButton(
                  tooltip: t('Rimuovi TypeSwitch', 'Remove TypeSwitch'),
                  onPressed: clearTypeSwitchElement,
                  icon: const Icon(Icons.close),
                ),
            ],
          ),
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(
            initialValue: active.isNotEmpty && ids.contains(active)
                ? active
                : null,
            isExpanded: true,
            decoration: InputDecoration(
              labelText: t('Tipo sbloccato', 'Unlocked type'),
              helperText: t(
                '@TypeSwitch cambia solo il tipo del danno posseduto, non il valore.',
                '@TypeSwitch changes only the type of owned damage, not its value.',
              ),
            ),
            items: [
              for (final id in ids)
                DropdownMenuItem<String>(
                  value: id,
                  child: Text(elementDisplayName(id)),
                ),
            ],
            onChanged: (value) {
              if (value != null) setTypeSwitchElement(value);
            },
          ),
          if (quickIds.isNotEmpty) ...[
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final id in quickIds)
                  ChoiceChip(
                    selected: active == id,
                    label: Text(elementDisplayName(id)),
                    onSelected: (_) => setTypeSwitchElement(id),
                  ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  Widget damageHealPanel() {
    if (!mostraDannoCuraScheda) return const SizedBox.shrink();

    return dropdownSection(
      title: t('Danno / Cura', 'Damage / Healing'),
      subtitle: t(
        'Inserisci un numero, scegli il modificatore, poi applica. Il danno totale usa il colore dell’elemento dominante.',
        'Enter a number, choose the modifier, then apply. Total damage uses the dominant element color.',
      ),
      icon: Icons.healing,
      borderColor: tertiaryColor,
      sectionId: 'sheet_damage_heal',
      initiallyExpanded: true,
      child: Column(
        children: [
          functionAnchor(
            'sheet_damage_heal_input',
            campoTesto(
              label: t('Danno subito / Cura', 'Damage taken / Healing'),
              controller: dannoSubitoController,
              focusNode: dannoCuraFocusNode,
              helper: t(
                'Numero o formula: 10+100-20. Il pulsante decide danno o cura.',
                'Number or formula: 10+100-20. The button decides damage or healing.',
              ),
            ),
          ),
          const SizedBox(height: 12),
          gothicPanel(
            borderColor: elementColor(elementoDannoDominante()),
            padding: const EdgeInsets.all(10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${t('Tipo danno', 'Damage type')}: ${elementDisplayName(elementoDannoDominante())}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: elementColor(elementoDannoDominante()),
                    fontSize: 20,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                if (elementiDannoTesto().isNotEmpty &&
                    elementiDannoTesto() !=
                        elementDisplayName(elementoDannoDominante()))
                  Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Text(
                      '${t('Elementi', 'Elements')}: ${elementiDannoTesto()}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: elementColor(
                          elementoDannoDominante(),
                        ).withValues(alpha: 0.85),
                        fontSize: 11,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 0.4,
                      ),
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          typeSwitchQuickPanel(),
          const SizedBox(height: 12),
          advantageModifierDropdown(),
          const SizedBox(height: 12),
          rollDifficultyField(),
          const SizedBox(height: 12),
          damageModifierDropdown(),
          if (mostraSempreColpito || hasCondition('vampirismo')) ...[
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: showReportedHitDialog,
                icon: const Icon(Icons.bloodtype_rounded),
                label: Text(
                  hasCondition('vampirismo')
                      ? t(
                          'Colpito • cura Vampirismo',
                          'Hit • Vampirism healing',
                        )
                      : t('Colpito • invia al Master', 'Hit • send to Master'),
                ),
              ),
            ),
          ],
          const SizedBox(height: 12),
          LayoutBuilder(
            builder: (context, constraints) {
              Widget actionButton({
                required String label,
                required Color backgroundColor,
                required Color foregroundColor,
                required VoidCallback onPressed,
              }) {
                return SizedBox(
                  width: constraints.maxWidth < 430
                      ? (constraints.maxWidth - 8) / 2
                      : null,
                  child: ElevatedButton(
                    onPressed: onPressed,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: backgroundColor,
                      foregroundColor: foregroundColor,
                      minimumSize: const Size.fromHeight(42),
                    ),
                    child: FittedBox(fit: BoxFit.scaleDown, child: Text(label)),
                  ),
                );
              }

              final buttons = [
                if (hasPinepineExplosion)
                  actionButton(
                    label: t('Esplosione Pinepine', 'Pinepine explosion'),
                    backgroundColor: Colors.deepOrange.shade800,
                    foregroundColor: Colors.white,
                    onPressed: applicaEsplosionePinepine,
                  ),
                functionAnchor(
                  'sheet_damage',
                  actionButton(
                    label: t('Danno', 'Damage'),
                    backgroundColor: Colors.redAccent.shade700,
                    foregroundColor: Colors.white,
                    onPressed: () => applicaDannoSubito(),
                  ),
                ),
                actionButton(
                  label: t('Critico', 'Critical'),
                  backgroundColor: tertiaryColor,
                  foregroundColor: tertiaryColor.computeLuminance() > 0.45
                      ? Colors.black
                      : Colors.white,
                  onPressed: () => applicaDannoSubito(critico: true),
                ),
                functionAnchor(
                  'sheet_heal',
                  actionButton(
                    label: t('Cura', 'Heal'),
                    backgroundColor: Colors.green.shade700,
                    foregroundColor: Colors.white,
                    onPressed: curaHp,
                  ),
                ),
                actionButton(
                  label: t('Refull', 'Refill'),
                  backgroundColor: primaryColor,
                  foregroundColor: primaryColor.computeLuminance() > 0.45
                      ? Colors.black
                      : Colors.white,
                  onPressed: refullVita,
                ),
              ];

              if (constraints.maxWidth < 430) {
                return Wrap(spacing: 8, runSpacing: 8, children: buttons);
              }

              return Row(
                children: [
                  for (var i = 0; i < buttons.length; i++) ...[
                    Expanded(child: buttons[i]),
                    if (i < buttons.length - 1) const SizedBox(width: 8),
                  ],
                ],
              );
            },
          ),
        ],
      ),
    );
  }

  Widget partyPanel() {
    if (!mostraPartyScheda) return const SizedBox.shrink();

    return dropdownSection(
      title: t('Party', 'Party'),
      subtitle: t(
        'Alleati, NPC e persone importanti sempre a portata.',
        'Allies, NPCs and important people close at hand.',
      ),
      icon: Icons.groups,
      borderColor: const Color(0xFF7EE7C8),
      sectionId: 'sheet_party',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          smallInfoText(
            t(
              'Segna qui il party, gli alleati, gli NPC importanti o chi sta viaggiando con te.',
              'Track your party, allies, important NPCs or who is traveling with you here.',
            ),
          ),
          const SizedBox(height: 12),
          gothicPanel(
            borderColor: tertiaryColor,
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  t(
                    'Party Master dalle schede salvate',
                    'Master party from saved sheets',
                  ),
                  style: TextStyle(
                    color: tertiaryColor,
                    fontWeight: FontWeight.w900,
                    fontSize: 16,
                  ),
                ),
                const SizedBox(height: 8),
                smallInfoText(
                  t(
                    'Questi membri sono schede vere: puoi aprirle, modificarle e tirare rapidamente dal Master.',
                    'These members are real sheets: you can open them, edit them and roll quickly from Master.',
                  ),
                ),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 10,
                  runSpacing: 12,
                  children: [
                    for (final index in masterPartyIndexes())
                      masterPartyHexBadge(index),
                  ],
                ),
                if (masterPartyIndexes().isNotEmpty) ...[
                  const SizedBox(height: 10),
                  smallInfoText(
                    t(
                      'Conteggio stats: scegli chi entra nella media del party. I nemici non contano.',
                      'Stats count: choose who enters the party average. Enemies do not count.',
                    ),
                  ),
                  const SizedBox(height: 6),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      for (final index in masterPartyIndexes())
                        if (!isEnemySheetAt(index))
                          FilterChip(
                            selected: sheetCountsForPartyStatsAt(index),
                            label: Text(nomeSchedaPersonaggio(index)),
                            onSelected: (value) =>
                                cambiaConteggioStatsParty(index, value),
                          ),
                    ],
                  ),
                ],
                if (masterPartyIndexes().isEmpty)
                  smallInfoText(
                    t(
                      'Nessuna scheda collegata al party Master.',
                      'No sheet linked to the Master party.',
                    ),
                  ),
                const SizedBox(height: 10),
                ElevatedButton.icon(
                  onPressed: () => cambiaSchedaMasterParty(
                    schedaCorrente,
                    !sheetInMasterPartyAt(schedaCorrente),
                  ),
                  icon: Icon(
                    sheetInMasterPartyAt(schedaCorrente)
                        ? Icons.group_remove
                        : Icons.group_add,
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: sheetInMasterPartyAt(schedaCorrente)
                        ? Colors.redAccent.shade700
                        : tertiaryColor,
                    foregroundColor: sheetInMasterPartyAt(schedaCorrente)
                        ? Colors.white
                        : tertiaryColor.computeLuminance() > 0.45
                        ? Colors.black
                        : Colors.white,
                  ),
                  label: Text(
                    sheetInMasterPartyAt(schedaCorrente)
                        ? t(
                            'Togli questa scheda dal party',
                            'Remove this sheet from party',
                          )
                        : t(
                            'Aggiungi questa scheda al party',
                            'Add this sheet to party',
                          ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          campoTesto(
            label: t('Nome membro', 'Member name'),
            controller: partyNomeController,
            numero: false,
          ),
          const SizedBox(height: 10),
          campoTesto(
            label: t('Ruolo', 'Role'),
            controller: partyRuoloController,
            numero: false,
          ),
          const SizedBox(height: 10),
          campoTesto(
            label: t('Note', 'Notes'),
            controller: partyNoteController,
            numero: false,
            maxLines: 2,
          ),
          const SizedBox(height: 10),
          ElevatedButton.icon(
            onPressed: aggiungiMembroParty,
            icon: const Icon(Icons.person_add),
            style: ElevatedButton.styleFrom(
              backgroundColor: tertiaryColor,
              foregroundColor: tertiaryColor.computeLuminance() > 0.45
                  ? Colors.black
                  : Colors.white,
              minimumSize: const Size.fromHeight(44),
            ),
            label: Text(t('Aggiungi al party', 'Add to party')),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              ElevatedButton.icon(
                onPressed: tiraAiutaCompagno,
                icon: const Icon(Icons.volunteer_activism),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF7EE7C8),
                  foregroundColor: Colors.black,
                ),
                label: Text(t('Aiuta compagno', 'Help ally')),
              ),
              Chip(
                avatar: const Icon(Icons.casino, size: 16),
                label: Text('1d10 + Lv + Grado x6'),
                backgroundColor: secondaryColor.withValues(alpha: 0.62),
                side: BorderSide(color: tertiaryColor.withValues(alpha: 0.55)),
                labelStyle: TextStyle(
                  color: tertiaryColor,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          if (partyMembri.isEmpty)
            smallInfoText(t('Nessun membro segnato.', 'No member tracked.'))
          else
            for (int i = 0; i < partyMembri.length; i++)
              Card(
                color: const Color(0xFF10121A),
                child: ListTile(
                  title: Text(
                    '${partyMembri[i]['nome'] ?? '???'}',
                    style: TextStyle(
                      color: primaryColor,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  subtitle: Text(
                    '${partyMembri[i]['ruolo'] ?? ''}\n${partyMembri[i]['note'] ?? ''}',
                    style: const TextStyle(color: Colors.white70),
                  ),
                  isThreeLine: true,
                  trailing: IconButton(
                    icon: const Icon(Icons.delete, color: Colors.redAccent),
                    onPressed: () {
                      setState(() => partyMembri.removeAt(i));
                      programmaSalvataggio();
                    },
                  ),
                ),
              ),
        ],
      ),
    );
  }

  void aggiungiMembroParty() {
    final nome = partyNomeController.text.trim();
    if (nome.isEmpty) return;

    setState(() {
      partyMembri.add({
        'nome': nome,
        'ruolo': partyRuoloController.text.trim(),
        'note': partyNoteController.text.trim(),
      });
      partyNomeController.clear();
      partyRuoloController.text = 'Alleato';
      partyNoteController.clear();
      risultato = t('Membro party aggiunto.', 'Party member added.');
      aggiungiLog(risultato);
    });

    programmaSalvataggio();
  }

  Widget manualQuickToolsPanel() {
    if (!mostraStrumentiManualeRapidi) return const SizedBox.shrink();

    return dropdownSection(
      title: t('Strumenti rapidi manuale', 'Manual quick tools'),
      subtitle: t(
        'Apri subito le regole più usate.',
        'Jump straight to the most used rules.',
      ),
      icon: Icons.menu_book,
      borderColor: primaryColor,
      initiallyExpanded: false,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (int i = 0; i < min(activeManualSections.length, 8); i++)
                ElevatedButton(
                  onPressed: () {
                    vaiAllaFunzione(
                      page: 8,
                      anchorId: 'rules_open_section',
                      manualIndex: i,
                      logTitle: manualTitle(activeManualSections[i]),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: secondaryColor,
                    foregroundColor: primaryColor,
                    side: BorderSide(
                      color: tertiaryColor.withValues(alpha: 0.45),
                    ),
                  ),
                  child: Text(
                    '${i + 1}. ${manualTitle(activeManualSections[i]).split('.').last.trim()}',
                  ),
                ),
            ],
          ),
          const SizedBox(height: 14),
          Divider(color: tertiaryColor.withValues(alpha: 0.35)),
          const SizedBox(height: 8),
          Text(
            t('Parole Rune', 'Rune Words'),
            style: TextStyle(
              color: primaryColor,
              fontSize: 16,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 6),
          smallInfoText(
            t(
              'Tutte le parole Rune sono visibili. Ogni Libro Runico ne rende selezionabili altre sei. Il tasto Rune Art spende il costo Oculum selezionato e aggiunge la DT della formula.',
              'All Rune words are visible. Every Runic Book makes six more selectable. The Rune Art button spends the selected Oculum cost and adds the formula DT.',
            ),
          ),
          const SizedBox(height: 10),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              ElevatedButton.icon(
                onPressed: openRuneQuickWordsDialog,
                icon: const Icon(Icons.tune),
                style: ElevatedButton.styleFrom(
                  backgroundColor: primaryColor,
                  foregroundColor: primaryColor.computeLuminance() > 0.45
                      ? Colors.black
                      : Colors.white,
                ),
                label: Text(t('Parole Rune', 'Rune Words')),
              ),
              ElevatedButton.icon(
                onPressed: learnRuneBookForSheet,
                icon: const Icon(Icons.menu_book),
                style: ElevatedButton.styleFrom(
                  backgroundColor: tertiaryColor,
                  foregroundColor: tertiaryColor.computeLuminance() > 0.45
                      ? Colors.black
                      : Colors.white,
                ),
                label: Text(t('Libro Runico +6', 'Runic Book +6')),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget inventoryQuickDropdownPanel() {
    if (!mostraBorsaCompatta) return const SizedBox.shrink();

    final principali = inventario.take(8).toList();

    return dropdownSection(
      title: t('Borsa rapida / Oggetti principali', 'Quick bag / Main items'),
      subtitle: t(
        'I primi oggetti della borsa con + e - rapidi.',
        'First bag items with quick + and - controls.',
      ),
      icon: Icons.backpack,
      borderColor: tertiaryColor,
      initiallyExpanded: true,
      child: Column(
        children: [
          if (principali.isEmpty)
            smallInfoText(t('Nessun oggetto in borsa.', 'No item in bag.'))
          else
            for (final item in principali)
              Card(
                color: const Color(0xFF10121A),
                child: ListTile(
                  title: Text(
                    cleanUiText(item.nome),
                    style: TextStyle(
                      color: primaryColor,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  subtitle: Text(
                    [
                      'x${item.quantita}',
                      '${item.peso.toStringAsFixed(1)} kg',
                      if (item.arma) 'DMG +${itemAttackBonus(item)}',
                      if (item.protegge) 'DIF +${itemDefenseBonus(item)}',
                      if (item.protegge) 'SCU +${itemShieldBonus(item)}',
                      if (item.note.trim().isNotEmpty) cleanUiText(item.note),
                    ].join(' • '),
                    style: const TextStyle(color: Colors.white70),
                  ),
                  trailing: SizedBox(
                    width: 96,
                    child: Row(
                      children: [
                        IconButton(
                          onPressed: () {
                            setState(() {
                              item.quantita = max(0, item.quantita - 1);
                            });
                            programmaSalvataggio();
                          },
                          icon: const Icon(
                            Icons.remove_circle,
                            color: Colors.redAccent,
                          ),
                        ),
                        IconButton(
                          onPressed: () {
                            setState(() {
                              item.quantita++;
                            });
                            programmaSalvataggio();
                          },
                          icon: const Icon(
                            Icons.add_circle,
                            color: Colors.greenAccent,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
        ],
      ),
    );
  }

  bool testoModificatoVisibile(String value) {
    final clean = cleanUiText(value).trim();
    if (clean.isEmpty) return false;
    final lower = clean.toLowerCase();
    return lower != '???' && lower != 'nessuno' && lower != 'none';
  }

  List<Widget> desktopArtSkillTextCards() {
    final cards = <Widget>[];
    final baseArts = artiBase();

    void addCard(
      String title,
      String body,
      Color color, {
      required VoidCallback onTap,
    }) {
      if (!testoModificatoVisibile(body)) return;
      cards.add(
        MouseRegion(
          cursor: SystemMouseCursors.click,
          child: GestureDetector(
            onTap: onTap,
            child: Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: const Color(0xFF10121A),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: color.withValues(alpha: 0.45)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          cleanUiText(title),
                          style: TextStyle(
                            color: color,
                            fontWeight: FontWeight.w900,
                            fontSize: 13,
                          ),
                        ),
                      ),
                      Icon(Icons.open_in_new, color: color, size: 15),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    cleanUiText(body),
                    maxLines: 5,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: Colors.white70, height: 1.25),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    }

    void openArt(int index) {
      vaiAllaFunzione(
        page: 3,
        anchorId: 'art_$index',
        logTitle: '${t('Art', 'Art')} ${index + 1}',
      );
    }

    void openArtOpen(int index) {
      vaiAllaFunzione(
        page: 3,
        anchorId: 'art_${index}_open',
        logTitle: '${t('Open Art', 'Art Open')} ${index + 1}',
      );
    }

    void openArtSkill(int artIndex, int skillIndex) {
      vaiAllaFunzione(
        page: 3,
        anchorId: 'art_${artIndex}_skill_$skillIndex',
        logTitle:
            '${t('Art', 'Art')} ${artIndex + 1} / ${t('Skill', 'Skill')} ${skillIndex + 1}',
      );
    }

    void openFreeSkill(int index) {
      vaiAllaFunzione(
        page: 4,
        anchorId: 'free_skill_$index',
        logTitle: '${t('Skill', 'Skill')} ${index + 1}',
      );
    }

    for (int i = 0; i < arti.length; i++) {
      final art = arti[i];
      final base = i < baseArts.length ? baseArts[i] : null;
      final color = elementColor(art.tipo);

      if (base == null || art.descrizione.trim() != base.descrizione.trim()) {
        addCard(
          'Art: ${art.nome}',
          art.descrizione,
          color,
          onTap: () => openArt(i),
        );
      }

      for (final field in [
        (
          label: 'Open',
          value: art.openDescription,
          base: base?.openDescription ?? '',
        ),
        (label: 'Open Buff', value: art.openBuff, base: base?.openBuff ?? ''),
        (
          label: 'Open Skill',
          value: art.openSkill,
          base: base?.openSkill ?? '',
        ),
      ]) {
        if (field.value.trim() != field.base.trim()) {
          addCard(
            '${field.label}: ${art.nome}',
            field.value,
            color,
            onTap: () => openArtOpen(i),
          );
        }
      }

      for (int j = 0; j < art.skills.length; j++) {
        final skill = art.skills[j];
        final baseSkill = base != null && j < base.skills.length
            ? base.skills[j]
            : null;
        for (final field in [
          (label: 'I', value: skill.evo1, base: baseSkill?.evo1 ?? ''),
          (label: 'II', value: skill.evo2, base: baseSkill?.evo2 ?? ''),
          (label: 'III', value: skill.evo3, base: baseSkill?.evo3 ?? ''),
        ]) {
          if (field.value.trim() != field.base.trim()) {
            addCard(
              'Art ${art.nome} / ${skill.nome} ${field.label}',
              field.value,
              color,
              onTap: () => openArtSkill(i, j),
            );
          }
        }
      }
    }

    for (int i = 0; i < skills.length; i++) {
      final skill = skills[i];
      final parts = [
        if (testoModificatoVisibile(skill.tipo)) skill.tipo,
        if (testoModificatoVisibile(skill.costo)) 'Costo: ${skill.costo}',
        if (testoModificatoVisibile(skill.cooldown))
          'Cooldown: ${skill.cooldown}',
        if (testoModificatoVisibile(skill.descrizione)) skill.descrizione,
      ].join('\n');
      addCard(
        'Skill: ${skill.nome}',
        parts,
        primaryColor,
        onTap: () => openFreeSkill(i),
      );
    }

    return cards;
  }

  Widget desktopQuickBagSidePanel() {
    final principali = inventario.take(6).toList();
    return gothicPanel(
      borderColor: tertiaryColor,
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            t('Borsa rapida laterale', 'Side quick bag'),
            style: TextStyle(
              color: tertiaryColor,
              fontWeight: FontWeight.w900,
              fontSize: 17,
            ),
          ),
          const SizedBox(height: 8),
          if (principali.isEmpty)
            smallInfoText(t('Nessun oggetto in borsa.', 'No item in bag.'))
          else
            for (final item in principali)
              ListTile(
                dense: true,
                contentPadding: EdgeInsets.zero,
                title: Text(
                  cleanUiText(item.nome),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: primaryColor,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                subtitle: Text(
                  [
                    'x${item.quantita}',
                    '${item.peso.toStringAsFixed(1)} kg',
                    if (item.arma) 'DMG +${itemAttackBonus(item)}',
                    if (item.protegge) 'DIF +${itemDefenseBonus(item)}',
                    if (item.protegge) 'SCU +${itemShieldBonus(item)}',
                  ].join(' • '),
                  style: const TextStyle(color: Colors.white70),
                ),
                trailing: Wrap(
                  spacing: 2,
                  children: [
                    IconButton(
                      visualDensity: VisualDensity.compact,
                      onPressed: () {
                        setState(() {
                          item.quantita = max(0, item.quantita - 1);
                        });
                        programmaSalvataggio();
                      },
                      icon: const Icon(
                        Icons.remove_circle,
                        color: Colors.redAccent,
                      ),
                    ),
                    IconButton(
                      visualDensity: VisualDensity.compact,
                      onPressed: () {
                        setState(() => item.quantita++);
                        programmaSalvataggio();
                      },
                      icon: const Icon(
                        Icons.add_circle,
                        color: Colors.greenAccent,
                      ),
                    ),
                  ],
                ),
              ),
          const SizedBox(height: 8),
          ElevatedButton.icon(
            onPressed: () => vaiAllaFunzione(
              page: 6,
              anchorId: 'inventory_root',
              logTitle: t('Borsa completa', 'Full bag'),
            ),
            icon: const Icon(Icons.open_in_full),
            style: ElevatedButton.styleFrom(
              backgroundColor: secondaryColor,
              foregroundColor: primaryColor,
              minimumSize: const Size.fromHeight(42),
            ),
            label: Text(t('Apri borsa completa', 'Open full bag')),
          ),
        ],
      ),
    );
  }

  Widget desktopArtSkillTextSidePanel() {
    final cards = desktopArtSkillTextCards();
    return gothicPanel(
      borderColor: primaryColor,
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            t('Art e Skill modificate', 'Edited Arts and Skills'),
            style: TextStyle(
              color: primaryColor,
              fontWeight: FontWeight.w900,
              fontSize: 17,
            ),
          ),
          const SizedBox(height: 8),
          smallInfoText(
            t(
              'Mostra solo testi modificati rispetto alla base e Skill con testo compilato.',
              'Shows only text changed from the base and Skills with filled text.',
            ),
          ),
          const SizedBox(height: 10),
          if (cards.isEmpty)
            smallInfoText(
              t(
                'Nessun testo Art/Skill modificato da mostrare.',
                'No edited Art/Skill text to show.',
              ),
            )
          else
            ...cards.take(8),
        ],
      ),
    );
  }

  Widget desktopSheetSidePanels() {
    if (!modalitaDesktop) return const SizedBox.shrink();

    return LayoutBuilder(
      builder: (context, constraints) {
        if (constraints.maxWidth < 900) return const SizedBox.shrink();
        return Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(child: desktopQuickBagSidePanel()),
            const SizedBox(width: 12),
            Expanded(child: desktopArtSkillTextSidePanel()),
          ],
        );
      },
    );
  }

  Widget sheetIdentityEditorPanel({bool dense = false}) {
    final spacing = dense ? 8.0 : 12.0;
    return gothicPanel(
      borderColor: tertiaryColor,
      padding: EdgeInsets.all(dense ? 10 : 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.badge, color: tertiaryColor, size: dense ? 18 : 22),
              SizedBox(width: dense ? 7 : 9),
              Expanded(
                child: Text(
                  t('Identità scheda', 'Sheet identity'),
                  style: TextStyle(
                    color: tertiaryColor,
                    fontWeight: FontWeight.w900,
                    fontSize: dense ? 15 : 18,
                  ),
                ),
              ),
              Container(
                padding: EdgeInsets.symmetric(
                  horizontal: dense ? 8 : 10,
                  vertical: dense ? 4 : 5,
                ),
                decoration: BoxDecoration(
                  color: secondaryColor,
                  borderRadius: BorderRadius.circular(999),
                  border: Border.all(
                    color: primaryColor.withValues(alpha: 0.42),
                  ),
                ),
                child: Text(
                  '${t('Lv', 'Lv')} ${livelloController.text} • ${t('Gr', 'Gr')} ${gradoController.text}',
                  style: TextStyle(
                    color: primaryColor,
                    fontSize: dense ? 11 : 12,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ],
          ),
          SizedBox(height: spacing),
          tipoSchedaDropdown(
            value: tipoSchedaController.text,
            onChanged: cambiaTipoScheda,
          ),
          SizedBox(height: spacing),
          campoTesto(
            label: t('Nome Scheda', 'Sheet Name'),
            controller: nomeController,
            numero: false,
            helper: dense
                ? null
                : t(
                    'Nome del personaggio, mostro o NPC.',
                    'Name of the character, monster or NPC.',
                  ),
          ),
          SizedBox(height: spacing),
          Row(
            children: [
              Expanded(
                child: campoTesto(
                  label: t('Livello', 'Level'),
                  controller: livelloController,
                ),
              ),
              SizedBox(width: spacing),
              Expanded(
                child: campoTesto(
                  label: t('Grado', 'Grade'),
                  controller: gradoController,
                ),
              ),
            ],
          ),
          SizedBox(height: dense ? 2 : 6),
          SwitchListTile(
            dense: dense,
            contentPadding: EdgeInsets.zero,
            value: rebirthato,
            activeThumbColor: tertiaryColor,
            title: const Text('Rebirth'),
            subtitle: dense
                ? null
                : Text(
                    t(
                      'Attivalo se la scheda è rebirthata.',
                      'Turn on if this sheet is rebirthed.',
                    ),
                  ),
            onChanged: toggleRebirth,
          ),
        ],
      ),
    );
  }

  Widget combatOverviewPanel({bool dense = false}) {
    final indicators = <Widget>[
      quickStatTile(
        label: t('Iniziativa', 'Initiative'),
        value: '+${iniziativa()}',
        valueBuilder: () => '+${iniziativa()}',
        icon: Icons.directions_run,
        color: const Color(0xFF7EE7C8),
        onTap: () => tiraValoreSpeciale(
          t('Iniziativa', 'Initiative'),
          iniziativa(),
          applyGlobalRollModifier: false,
        ),
        onRoll: () => tiraValoreSpeciale(
          t('Iniziativa', 'Initiative'),
          iniziativa(),
          applyGlobalRollModifier: false,
        ),
      ),
      quickStatTile(
        label: t('Movimento', 'Movement'),
        value: '${movimento()}m',
        valueBuilder: () => '${movimento()}m',
        icon: Icons.directions_walk,
        color: Colors.cyanAccent,
        onTap: () => vaiAllaFunzione(
          page: 0,
          anchorId: 'sheet_editable_values_materia',
          logTitle: t('Movimento', 'Movement'),
        ),
      ),
      quickStatTile(
        label: t('Schivata Oculum', 'Oculum Dodge'),
        value: '${schivateOculumDisponibili()}/${schivateOculumTotali()}',
        valueBuilder: () =>
            '${schivateOculumDisponibili()}/${schivateOculumTotali()}',
        icon: Icons.visibility,
        color: eyePupilGlowColor,
        conditionTarget: OculumConditionTarget.combattimento,
        onTap: mostraMenuSchivataOculum,
      ),
      if (!dense || !modalitaVeloce)
        quickStatTile(
          label: t('Bonus livello/grado', 'Level/grade bonus'),
          value: '+${bonusLivelloGrado()}',
          icon: Icons.military_tech,
          color: Colors.amberAccent,
        ),
    ];
    return Semantics(
      label: t(
        'Indicatori del centro combattimento',
        'Combat center indicators',
      ),
      child: LayoutBuilder(
        builder: (context, constraints) {
          final spacing = dense ? 8.0 : 10.0;
          final columns = constraints.maxWidth < 420
              ? 2
              : constraints.maxWidth < 760
              ? 3
              : 4;
          final width =
              (constraints.maxWidth - spacing * (columns - 1)) / columns;
          return Padding(
            padding: EdgeInsets.only(top: dense ? 6 : 8),
            child: Wrap(
              spacing: spacing,
              runSpacing: spacing,
              children: [
                for (final indicator in indicators)
                  SizedBox(width: width, child: indicator),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget statMiniTile({
    required String label,
    required int value,
    int Function()? valueBuilder,
    required int buff,
    required int temp,
    required VoidCallback onRoll,
    required VoidCallback onEdit,
    required Color color,
    int? massimo,
    int bonusSkillForma = 0,
    OculumConditionTarget? conditionTarget,
    int? baseValue,
    bool conditionScoped = false,
    String? criticalExperienceKey,
    VoidCallback? onDecrease,
    VoidCallback? onIncrease,
  }) {
    if (!conditionScoped && conditionTarget != null) {
      return ValueListenableBuilder<int>(
        valueListenable: conditionRevisionFor(conditionTarget),
        builder: (context, revision, child) => statMiniTile(
          label: label,
          value: valueBuilder?.call() ?? value,
          valueBuilder: valueBuilder,
          buff: buff,
          temp: temp,
          onRoll: onRoll,
          onEdit: onEdit,
          color: color,
          massimo: massimo,
          bonusSkillForma: bonusSkillForma,
          conditionTarget: conditionTarget,
          baseValue: baseValue,
          conditionScoped: true,
          criticalExperienceKey: criticalExperienceKey,
          onDecrease: onDecrease,
          onIncrease: onIncrease,
        ),
      );
    }
    final rollBonus = oculumStatRollBonus(
      statValue: value,
      levelGradeBonus: bonusLivelloGrado(),
      quickBonus: statRollQuickBonus(label),
    );
    final criticalExperience = criticalExperienceKey == null
        ? 0
        : max(0, esperienzaCriticaStatistiche[criticalExperienceKey] ?? 0);
    final criticalExperienceProgress = (criticalExperience / 1000)
        .clamp(0.0, 1.0)
        .toDouble();
    final hasExtra = buff != 0 || temp != 0 || bonusSkillForma != 0;
    final compact = lightweightUi;
    final diceButtonSize = compact ? 38.0 : 44.0;
    final diceIconSize = compact ? 20.0 : 23.0;
    final spec = currentThemeDecorationSpec();
    final guiStyle = currentThemeVisualIdentity().mainSheetGuiStyle.id;
    final clippedTile = <String>{
      'phobia',
      'postea',
      'kingi',
      'medieval',
      'rank_hud',
      'sigil',
      'archive',
      'relic',
    }.contains(guiStyle);
    final tileBackground = switch (guiStyle) {
      'phobia' => Color.lerp(
        spec.backgroundBottom,
        const Color(0xFF06111D),
        0.52,
      )!,
      'postea' || 'kingi' || 'medieval' => Color.lerp(
        spec.backgroundBottom,
        const Color(0xFF102839),
        0.48,
      )!,
      'botanical' => Color.lerp(
        spec.backgroundBottom,
        const Color(0xFF0D1C13),
        0.42,
      )!,
      'lunar' || 'soft_orbital' => Color.lerp(
        spec.backgroundBottom,
        const Color(0xFF11142A),
        0.42,
      )!,
      'archive' || 'relic' => Color.lerp(
        spec.backgroundBottom,
        const Color(0xFF18110A),
        0.38,
      )!,
      'rank_hud' || 'sigil' => Color.lerp(
        spec.backgroundBottom,
        const Color(0xFF110927),
        0.46,
      )!,
      _ => const Color(0xFF080A12),
    };
    final accent = readableOnTheme(
      color,
      background: tileBackground,
      minRatio: 3.5,
    );
    final labelColor = readableOnTheme(
      Color.lerp(
        Colors.white,
        spec.accent,
        guiStyle == 'phobia' ? 0.26 : 0.16,
      )!,
      background: tileBackground,
      minRatio: 4.0,
    );
    final tileRadius = switch (guiStyle) {
      'phobia' => compact ? 4.0 : 6.0,
      'postea' || 'kingi' || 'medieval' => compact ? 5.0 : 7.0,
      'botanical' => compact ? 13.0 : 16.0,
      'lunar' || 'soft_orbital' => compact ? 16.0 : 18.0,
      _ => compact ? 9.0 : 12.0,
    };
    final Gradient tileGradient = switch (guiStyle) {
      'phobia' => LinearGradient(
        colors: [
          Colors.black.withValues(alpha: 0.98),
          Color.lerp(tileBackground, spec.primary, 0.18)!,
          Color.lerp(tileBackground, spec.accent, 0.10)!,
        ],
        stops: const [0.0, 0.48, 1.0],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ),
      'postea' || 'kingi' || 'medieval' => LinearGradient(
        colors: [
          Color.lerp(tileBackground, spec.primary, 0.16)!,
          tileBackground,
          Color.lerp(tileBackground, spec.accent, 0.12)!,
        ],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ),
      'botanical' => RadialGradient(
        colors: [
          Color.lerp(tileBackground, spec.secondary, 0.16)!,
          tileBackground,
        ],
        center: Alignment.topRight,
        radius: 1.4,
      ),
      'lunar' || 'soft_orbital' => RadialGradient(
        colors: [
          Color.lerp(tileBackground, spec.accent, 0.14)!,
          tileBackground,
        ],
        center: Alignment.topLeft,
        radius: 1.2,
      ),
      'archive' || 'relic' => LinearGradient(
        colors: [
          Color.lerp(tileBackground, spec.secondary, 0.12)!,
          tileBackground,
        ],
        begin: Alignment.centerLeft,
        end: Alignment.centerRight,
      ),
      _ => LinearGradient(colors: [tileBackground, tileBackground]),
    };

    Widget rollBadge({bool tight = false}) {
      return Container(
        padding: EdgeInsets.symmetric(
          horizontal: tight ? 6 : 7,
          vertical: compact ? 3 : 4,
        ),
        decoration: BoxDecoration(
          color: accent.withValues(alpha: 0.16),
          borderRadius: BorderRadius.circular(guiStyle == 'phobia' ? 5 : 999),
          border:
              guiStyle == 'postea' ||
                  guiStyle == 'kingi' ||
                  guiStyle == 'medieval'
              ? Border.all(color: accent.withValues(alpha: 0.30))
              : null,
        ),
        child: Text(
          '1d20 +$rollBonus',
          maxLines: 1,
          softWrap: false,
          style: TextStyle(
            color: accent,
            fontSize: compact ? 9.5 : 10.5,
            fontWeight: FontWeight.w900,
          ),
        ),
      );
    }

    Widget valueControlText() {
      return GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: onRoll,
        child: FittedBox(
          fit: BoxFit.scaleDown,
          alignment: onDecrease != null || onIncrease != null
              ? Alignment.center
              : Alignment.centerLeft,
          child: Text(
            massimo == null ? '$value' : '$value/$massimo',
            textAlign: onDecrease != null || onIncrease != null
                ? TextAlign.center
                : TextAlign.start,
            maxLines: 1,
            softWrap: false,
            style: TextStyle(
              color: readableOnTheme(Colors.white, background: tileBackground),
              fontSize: compact ? 21 : 25,
              fontWeight: FontWeight.w900,
              height: 1,
              shadows: readableTextShadow(
                Colors.white,
                background: tileBackground,
              ),
            ),
          ),
        ),
      );
    }

    Widget valueControlsRow({required bool includeRollBadge}) {
      return Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          if (onDecrease != null) ...[
            quickAdjustButton(
              icon: Icons.remove,
              tooltip: '-1 $label',
              color: accent,
              onPressed: onDecrease,
            ),
            SizedBox(width: compact ? 4 : 5),
          ],
          Expanded(child: valueControlText()),
          if (onIncrease != null) ...[
            SizedBox(width: compact ? 4 : 5),
            quickAdjustButton(
              icon: Icons.add,
              tooltip: '+1 $label',
              color: accent,
              onPressed: onIncrease,
            ),
          ],
          if (includeRollBadge) ...[const SizedBox(width: 6), rollBadge()],
        ],
      );
    }

    final tileBody = Container(
      padding: EdgeInsets.all(compact ? 7 : 10),
      decoration: BoxDecoration(
        gradient: tileGradient,
        borderRadius: BorderRadius.circular(tileRadius),
        border: Border.all(
          color: accent.withValues(alpha: guiStyle == 'phobia' ? 0.78 : 0.62),
        ),
        boxShadow: compact
            ? const <BoxShadow>[]
            : [
                BoxShadow(
                  color: accent.withValues(
                    alpha: guiStyle == 'phobia' ? 0.18 : 0.10,
                  ),
                  blurRadius: guiStyle == 'phobia' ? 12 : 8,
                  offset: const Offset(0, 2),
                ),
              ],
      ),
      child: Stack(
        children: [
          if (clippedTile)
            Positioned.fill(
              child: IgnorePointer(
                child: CustomPaint(
                  painter: _OculumThemePanelChromePainter(
                    spec: spec,
                    guiStyle: guiStyle,
                    borderColor: accent,
                    compact: true,
                    clipped: clippedTile,
                  ),
                ),
              ),
            ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      cleanUiText(label),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: labelColor,
                        fontWeight: FontWeight.w900,
                        fontSize: compact ? 11.5 : 13,
                        shadows: readableTextShadow(
                          labelColor,
                          background: tileBackground,
                        ),
                      ),
                    ),
                  ),
                  if (conditionTarget != null) ...[
                    const SizedBox(width: 4),
                    conditionImpactIndicator(
                      target: conditionTarget,
                      baseValue: '${baseValue ?? value}',
                      permanentValue:
                          '${buff + bonusSkillForma >= 0 ? '+' : ''}${buff + bonusSkillForma}',
                      temporaryValue: '${temp >= 0 ? '+' : ''}$temp',
                      finalValue:
                          '$value · 1d20 ${rollBonus >= 0 ? '+' : ''}$rollBonus',
                    ),
                  ],
                  const SizedBox(width: 6),
                  IconButton(
                    tooltip: t('Tira $label', 'Roll $label'),
                    onPressed: onRoll,
                    constraints: BoxConstraints.tightFor(
                      width: diceButtonSize,
                      height: diceButtonSize,
                    ),
                    padding: EdgeInsets.zero,
                    style: IconButton.styleFrom(
                      backgroundColor: accent.withValues(alpha: 0.17),
                      foregroundColor: accent,
                      side: BorderSide(color: accent.withValues(alpha: 0.45)),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(
                          guiStyle == 'postea' ||
                                  guiStyle == 'kingi' ||
                                  guiStyle == 'medieval'
                              ? 7
                              : 12,
                        ),
                      ),
                    ),
                    icon: Icon(Icons.casino, size: diceIconSize),
                  ),
                ],
              ),
              SizedBox(height: compact ? 3 : 6),
              valueControlsRow(includeRollBadge: !compact),
              if (compact) ...[
                const SizedBox(height: 3),
                Align(
                  alignment: Alignment.centerRight,
                  child: rollBadge(tight: true),
                ),
              ],
              if (criticalExperienceKey != null) ...[
                SizedBox(height: compact ? 4 : 6),
                Tooltip(
                  message: 'EXP critica: $criticalExperience / 1000',
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(99),
                    child: LinearProgressIndicator(
                      value: criticalExperienceProgress,
                      minHeight: compact ? 2 : 3,
                      color: accent,
                      backgroundColor: Colors.black.withValues(alpha: 0.38),
                    ),
                  ),
                ),
              ],
              if (hasExtra) ...[
                SizedBox(height: compact ? 3 : 5),
                Text(
                  [
                    if (buff != 0) 'Tit ${buff > 0 ? '+' : ''}$buff',
                    if (temp != 0) 'Temp ${temp > 0 ? '+' : ''}$temp',
                    if (bonusSkillForma != 0)
                      'Skill ${bonusSkillForma > 0 ? '+' : ''}$bonusSkillForma',
                  ].join(' • '),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: readableOnTheme(
                      Colors.grey.shade400,
                      background: tileBackground,
                    ),
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ],
          ),
        ],
      ),
    );
    final tile = clippedTile
        ? ClipPath(
            clipper: _OculumThemePanelClipper(
              guiStyle: guiStyle,
              compact: true,
            ),
            child: tileBody,
          )
        : tileBody;

    final contextualTile = quickContextMenuAnchor(
      label: label,
      child: tile,
      onEdit: onEdit,
      onRoll: onRoll,
      onDecrease: onDecrease,
      onIncrease: onIncrease,
      conditionTarget: conditionTarget,
    );

    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(tileRadius),
        onTap: onEdit,
        child: contextualTile,
      ),
    );
  }

  Widget statsOverviewPanel({bool dense = false}) {
    return ValueListenableBuilder<int>(
      valueListenable: activeSheetSummaryRevision,
      builder: (context, revision, child) =>
          _statsOverviewPanelContent(dense: dense),
    );
  }

  Widget _statsOverviewPanelContent({required bool dense}) {
    return gothicPanel(
      borderColor: primaryColor,
      padding: EdgeInsets.all(dense ? 10 : 14),
      child: LayoutBuilder(
        builder: (context, constraints) {
          final columns = constraints.maxWidth >= (dense ? 500 : 720) ? 4 : 2;
          final spacing = dense ? 6.0 : 9.0;
          final itemWidth =
              (constraints.maxWidth - spacing * (columns - 1)) / columns;
          final tiles = [
            statMiniTile(
              label: t('Resilienza', 'Resilience'),
              value: resilienzaTotale(),
              valueBuilder: resilienzaTotale,
              criticalExperienceKey: 'resilienza',
              baseValue: currentResilienza(),
              conditionTarget: OculumConditionTarget.resilienza,
              buff: buffResilienza(),
              temp: tempResilienza,
              massimo: resilienzaMassimo(),
              bonusSkillForma: skillFormaBonus('resilienza'),
              color: const Color(0xFF2ECC71),
              onRoll: () =>
                  tiraStat(t('Resilienza', 'Resilience'), resilienzaTotale()),
              onEdit: () => vaiAllaFunzione(
                page: 0,
                anchorId: 'sheet_editable_values_resilienza',
                logTitle: t('Resilienza', 'Resilience'),
              ),
              onDecrease: () => modificaStatAttuale('resilienza', -1),
              onIncrease: () => modificaStatAttuale('resilienza', 1),
            ),
            statMiniTile(
              label: t('Volontà', 'Will'),
              value: volontaTotale(),
              valueBuilder: volontaTotale,
              criticalExperienceKey: 'volonta',
              buff: buffVolonta(),
              baseValue: currentVolonta(),
              conditionTarget: OculumConditionTarget.volonta,
              temp: tempVolonta,
              massimo: volontaMassimo(),
              bonusSkillForma: skillFormaBonus('volonta'),
              color: const Color(0xFFE74C3C),
              onRoll: () => tiraStat(t('Volontà', 'Will'), volontaTotale()),
              onEdit: () => vaiAllaFunzione(
                page: 0,
                anchorId: 'sheet_editable_values_volonta',
                logTitle: t('Volontà', 'Will'),
              ),
              onDecrease: () => modificaStatAttuale('volonta', -1),
              onIncrease: () => modificaStatAttuale('volonta', 1),
            ),
            statMiniTile(
              label: 'Materia',
              value: materiaTotale(),
              valueBuilder: materiaTotale,
              criticalExperienceKey: 'materia',
              baseValue: currentMateria(),
              conditionTarget: OculumConditionTarget.materia,
              buff: buffMateria(),
              temp: tempMateria,
              massimo: materiaMassimo(),
              bonusSkillForma: skillFormaBonus('materia'),
              color: const Color(0xFF44A7FF),
              onRoll: () => tiraStat('Materia', materiaTotale()),
              onEdit: () => vaiAllaFunzione(
                page: 0,
                anchorId: 'sheet_editable_values_materia',
                logTitle: 'Materia',
              ),
              onDecrease: () => modificaStatAttuale('materia', -1),
              onIncrease: () => modificaStatAttuale('materia', 1),
            ),
            statMiniTile(
              label: 'Oculum',
              value: oculumTotale(),
              valueBuilder: oculumTotale,
              criticalExperienceKey: 'oculum',
              baseValue: normalCurrentOculum(),
              conditionTarget: OculumConditionTarget.oculum,
              buff: buffOculum(),
              temp: tempOculum + temporaryOculum,
              massimo: oculumMassimo(),
              bonusSkillForma: skillFormaBonus('oculum'),
              color: oculumStatFormulaColor,
              onRoll: () => tiraStat('Oculum', oculumTotale()),
              onEdit: () => vaiAllaFunzione(
                page: 0,
                anchorId: 'sheet_editable_values_oculum',
                logTitle: 'Oculum',
              ),
              onDecrease: () => modificaStatAttuale('oculum', -1),
              onIncrease: () => modificaStatAttuale('oculum', 1),
            ),
          ];

          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(Icons.auto_graph, color: primaryColor),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      t('Statistiche', 'Stats'),
                      style: TextStyle(
                        color: primaryColor,
                        fontWeight: FontWeight.w900,
                        fontSize: dense ? 16 : 19,
                      ),
                    ),
                  ),
                  Text(
                    t('tocca = modifica', 'tap = edit'),
                    style: TextStyle(
                      color: Colors.grey.shade400,
                      fontSize: 10.5,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              quickStatTile(
                label: t('Statistiche totali', 'Total stats'),
                value: '${statsMassimeTotali()}',
                icon: Icons.functions,
                color: tertiaryColor,
                onTap: () => vaiAllaFunzione(
                  page: 0,
                  anchorId: 'sheet_editable_values',
                  logTitle: t('Statistiche totali', 'Total stats'),
                ),
              ),
              SizedBox(height: dense ? 8 : 12),
              Wrap(
                spacing: spacing,
                runSpacing: spacing,
                children: [
                  for (final tile in tiles)
                    SizedBox(width: itemWidth, child: tile),
                ],
              ),
            ],
          );
        },
      ),
    );
  }

  Widget mainValuesOverviewPanel({bool dense = false}) {
    final domDif = elementoDifesaDominante();
    final domDan = elementoDannoDominante();
    final stackedVitals = themeUsesStackedVitalsHud();
    return gothicPanel(
      borderColor: const Color(0xFF7EE7C8),
      padding: EdgeInsets.all(dense ? 10 : 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.dashboard_customize, color: Color(0xFF7EE7C8)),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  t('Riepilogo rapido', 'Quick summary'),
                  style: const TextStyle(
                    color: Color(0xFF7EE7C8),
                    fontWeight: FontWeight.w900,
                    fontSize: 17,
                  ),
                ),
              ),
              Text(
                '${t('Peso', 'Weight')} ${pesoMassimo().toStringAsFixed(0)}kg',
                style: TextStyle(
                  color: primaryColor,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
          const SizedBox(height: 9),
          Wrap(
            spacing: dense ? 6 : 8,
            runSpacing: dense ? 6 : 8,
            children: [
              if (stackedVitals)
                SizedBox(
                  width: dense ? 276 : 340,
                  child: stackedVitalsHudPanel(dense: true, embedded: true),
                )
              else ...[
                quickStatTile(
                  label: 'HP',
                  value: hpReadoutProtetto(),
                  icon: vitaAfonaAttiva()
                      ? Icons.dangerous_rounded
                      : Icons.favorite,
                  color: vitaAfonaAttiva() ? Colors.black : Colors.redAccent,
                  onTap: vitaAfonaAttiva()
                      ? null
                      : () => apriDannoCuraDalCentroPartita(target: 'hp'),
                  onRoll: vitaAfonaAttiva()
                      ? null
                      : () => tiraValoreSpeciale('HP', hpCorrenti()),
                  onDecrease: vitaAfonaAttiva()
                      ? null
                      : () => modificaHpRapido(-1),
                  onIncrease: vitaAfonaAttiva()
                      ? null
                      : () => modificaHpRapido(1),
                ),
                quickStatTile(
                  label: 'Temp',
                  value: '${hpTemp()}',
                  icon: Icons.favorite_border,
                  color: Colors.greenAccent,
                  onTap: () => vaiAllaFunzione(page: 0, anchorId: 'sheet_hp'),
                  onRoll: () => tiraValoreSpeciale('HP Temp', hpTemp()),
                  onDecrease: () => modificaHpTempRapido(-1),
                  onIncrease: () => modificaHpTempRapido(1),
                ),
                quickStatTile(
                  label: t('Scudo', 'Shield'),
                  value: '${scudo()}',
                  icon: Icons.shield,
                  color: Colors.lightBlueAccent,
                  onTap: () =>
                      vaiAllaFunzione(page: 0, anchorId: 'sheet_shield'),
                  onRoll: () =>
                      tiraValoreSpeciale(t('Scudo', 'Shield'), scudo()),
                  onDecrease: () => modificaScudoRapido(-1),
                  onIncrease: () => modificaScudoRapido(1),
                ),
              ],
              quickStatTile(
                label: t('Scudo Crit.', 'Crit. Shield'),
                value: '${scudoCritico()}',
                icon: Icons.shield_moon,
                color: Colors.white,
                onTap: () => vaiAllaFunzione(page: 0, anchorId: 'sheet_hp'),
                onRoll: () => tiraValoreSpeciale(
                  t('Scudo Critico', 'Critical Shield'),
                  scudoCritico(),
                ),
                onDecrease: () => modificaScudoCriticoRapido(-1),
                onIncrease: () => modificaScudoCriticoRapido(1),
              ),
              quickStatTile(
                label: 'Karma',
                value: '${karmaTotale()}',
                icon: Icons.balance,
                color: karmaUiColor(),
                onTap: () => vaiAllaFunzione(
                  page: 7,
                  anchorId: 'resources_root',
                  logTitle: 'Karma',
                ),
              ),
              if (!dense || !modalitaVeloce)
                quickStatTile(
                  label: t('Movimento', 'Movement'),
                  value: '${movimento()}m',
                  valueBuilder: () => '${movimento()}m',
                  icon: Icons.directions_walk,
                  color: Colors.cyanAccent,
                  onTap: () => vaiAllaFunzione(
                    page: 0,
                    anchorId: 'sheet_editable_values_materia',
                    logTitle: t('Movimento', 'Movement'),
                  ),
                ),
              quickStatTile(
                label: t('Difesa', 'Defense'),
                value:
                    '${difesa()}${domDif.isNotEmpty ? ' ${elementDisplayName(domDif)}' : ''}',
                valueBuilder: () =>
                    '${difesa()}${domDif.isNotEmpty ? ' ${elementDisplayName(domDif)}' : ''}',
                icon: Icons.security,
                color: domDif.isEmpty ? primaryColor : elementColor(domDif),
                onTap: () => vaiAllaFunzione(
                  page: 0,
                  anchorId: 'sheet_defense_bonus',
                  logTitle: t('Difesa', 'Defense'),
                ),
                onRoll: () =>
                    tiraValoreSpeciale(t('Difesa', 'Defense'), difesa()),
                onDecrease: () => modificaDifesaRapida(-1),
                onIncrease: () => modificaDifesaRapida(1),
              ),
              quickStatTile(
                label: t('Reazioni', 'Reactions'),
                value: reazioniVelociTotali() > 0
                    ? '${reazioniTotali()} +${reazioniVelociTotali()}V'
                    : '${reazioniTotali()}',
                valueBuilder: () => reazioniVelociTotali() > 0
                    ? '${reazioniTotali()} +${reazioniVelociTotali()}V'
                    : '${reazioniTotali()}',
                icon: Icons.reply_all,
                color: Colors.orangeAccent,
                onTap: mostraModificaRapida,
                onRoll: () => tiraValoreSpeciale(
                  t('Reazioni', 'Reactions'),
                  reazioniTotali(),
                ),
                onDecrease: () => modificaControllerNumericoRapido(
                  reazioniController,
                  -1,
                  label: t('Reazioni', 'Reactions'),
                ),
                onIncrease: () => modificaControllerNumericoRapido(
                  reazioniController,
                  1,
                  label: t('Reazioni', 'Reactions'),
                ),
              ),
              quickStatTile(
                label: t('Danno', 'Damage'),
                value:
                    '${dannoTotale()}${domDan != 'sconosciuto' ? ' ${elementDisplayName(domDan)}' : ''}',
                valueBuilder: () =>
                    '${dannoTotale()}${domDan != 'sconosciuto' ? ' ${elementDisplayName(domDan)}' : ''}',
                icon: Icons.close,
                color: domDan == 'sconosciuto'
                    ? tertiaryColor
                    : elementColor(domDan),
                onTap: () => apriDannoCuraDalCentroPartita(target: 'damage'),
                onRoll: () =>
                    tiraValoreSpeciale(t('Danno', 'Damage'), dannoTotale()),
                onDecrease: () => modificaBuffMalusRapido(
                  rawKey: 'Danni',
                  label: t('Danno', 'Damage'),
                  delta: -1,
                ),
                onIncrease: () => modificaBuffMalusRapido(
                  rawKey: 'Danni',
                  label: t('Danno', 'Damage'),
                  delta: 1,
                ),
              ),
              if (!dense || !modalitaVeloce)
                quickStatTile(
                  label: t('Formula DIF', 'DEF formula'),
                  value: formulaDifesaDettagliata(),
                  icon: Icons.functions,
                  color: primaryColor,
                  onTap: () => vaiAllaFunzione(
                    page: 0,
                    anchorId: 'sheet_editable_values',
                    logTitle: t('Valori modificabili', 'Editable values'),
                  ),
                ),
              if ((!dense || !modalitaVeloce) &&
                  quickCommandRuntimeDetails('danni').isNotEmpty)
                quickStatTile(
                  label: t('Formula DAN', 'DMG formula'),
                  value: formulaDannoDettagliata(),
                  icon: Icons.functions,
                  color: tertiaryColor,
                  onTap: () => vaiAllaFunzione(
                    page: 0,
                    anchorId: 'sheet_editable_values',
                    logTitle: t('Danno', 'Damage'),
                  ),
                ),
            ],
          ),
        ],
      ),
    );
  }

  Widget gradeBonusActionButton() {
    return ElevatedButton.icon(
      onPressed: applicaBonusGradoPersonaggio,
      icon: const Icon(Icons.shield_moon),
      style: ElevatedButton.styleFrom(
        backgroundColor: tertiaryColor,
        foregroundColor: tertiaryColor.computeLuminance() > 0.45
            ? Colors.black
            : Colors.white,
        minimumSize: const Size.fromHeight(46),
      ),
      label: Text(t('Applica Bonus Grado', 'Apply Grade Bonus')),
    );
  }

  Widget sheetDiceDropdownPanel({bool dense = false}) {
    return dropdownSection(
      title: t('Dadi rapidi', 'Quick dice'),
      icon: Icons.casino,
      borderColor: tertiaryColor,
      sectionId: 'sheet_dice_quick',
      initiallyExpanded: false,
      child: Column(
        children: [
          sheetDiceRollControls(dense: dense, showTitle: false),
          const SizedBox(height: 10),
          tentaFortunaSlotSheetCard(),
        ],
      ),
    );
  }

  Widget themedSheetDesktopColumn({
    double? width,
    int flex = 1,
    required List<Widget> children,
  }) {
    final column = Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: children,
    );
    if (width != null) return SizedBox(width: width, child: column);
    return Expanded(flex: flex, child: column);
  }

  Widget themedSheetDesktopRow(List<Widget> children, {double gap = 8}) {
    final spaced = <Widget>[];
    for (var i = 0; i < children.length; i++) {
      if (i > 0) spaced.add(SizedBox(width: gap));
      spaced.add(children[i]);
    }
    return Row(crossAxisAlignment: CrossAxisAlignment.start, children: spaced);
  }

  Widget characterMobilePage() {
    final dense = lightweightUi || MediaQuery.sizeOf(context).width < 600;
    final layoutId =
        currentThemeVisualIdentity().mainSheetGuiStyle.sheetLayoutId;
    final builders = <Widget Function()>[];

    Widget command() =>
        functionAnchor('sheet_command_center', sheetCommandCenter());
    Widget combat() =>
        functionAnchor('sheet_combat_values', combatOverviewPanel(dense: true));
    Widget values() =>
        functionAnchor('sheet_values', mainValuesOverviewPanel(dense: true));
    Widget hp() => functionAnchor('sheet_hp', hpModePanel());
    Widget damage() => functionAnchor('sheet_damage_heal', damageHealPanel());
    Widget dice() =>
        functionAnchor('sheet_dice_quick', sheetDiceDropdownPanel(dense: true));
    Widget stats() =>
        functionAnchor('sheet_stats', statsOverviewPanel(dense: true));
    Widget editable() =>
        functionAnchor('sheet_editable_values', editableMainValuesDropdown());
    Widget eye() => functionAnchor('sheet_image', oculumEyeBox());
    Widget identity() =>
        functionAnchor('sheet_identity', sheetIdentityEditorPanel(dense: true));
    Widget race() => functionAnchor('sheet_race', raceIdentityPanel());
    Widget exp() => functionAnchor('sheet_exp', experiencePanel());
    Widget glance() =>
        functionAnchor('sheet_quick_glance', occhiataVeloceRaWidget());

    builders.add(glance);

    void addTrailingTools() {
      if (!modalitaVeloce) {
        builders
          ..add(quickIndexButtonsPanel)
          ..add(quickLoreButtonsPanel);
      }
      builders.add(() => functionAnchor('sheet_party', partyPanel()));
      if (!modalitaVeloce) builders.add(manualQuickToolsPanel);
      builders
        ..add(gradeBonusActionButton)
        ..add(() => const SizedBox(height: 12))
        ..add(diceResultPanel);
    }

    switch (layoutId) {
      case 'video_hud':
        builders.addAll([
          command,
          hp,
          combat,
          stats,
          damage,
          dice,
          oculumResourcePanel,
          values,
          editable,
          eye,
          identity,
          race,
          exp,
        ]);
        break;
      case 'tactical_board':
        builders.addAll([
          command,
          values,
          stats,
          combat,
          hp,
          damage,
          editable,
          oculumResourcePanel,
          dice,
          identity,
          race,
          eye,
          exp,
        ]);
        break;
      case 'battle_focus':
        builders.addAll([
          command,
          combat,
          hp,
          damage,
          dice,
          stats,
          oculumResourcePanel,
          values,
          editable,
          identity,
          race,
          eye,
          exp,
        ]);
        break;
      case 'quick_grimoire':
        builders.addAll([
          values,
          editable,
          stats,
          command,
          combat,
          hp,
          damage,
          dice,
          oculumResourcePanel,
          identity,
          race,
          eye,
          exp,
        ]);
        break;
      case 'soft_orbit':
        builders.addAll([
          eye,
          identity,
          oculumResourcePanel,
          command,
          stats,
          hp,
          damage,
          combat,
          dice,
          values,
          editable,
          race,
          exp,
        ]);
        break;
      case 'botanical':
      case 'lantern':
        builders.addAll([
          eye,
          identity,
          race,
          oculumResourcePanel,
          stats,
          hp,
          damage,
          combat,
          command,
          dice,
          values,
          editable,
          exp,
        ]);
        break;
      case 'machine':
        builders.addAll([
          command,
          values,
          editable,
          combat,
          stats,
          hp,
          damage,
          oculumResourcePanel,
          exp,
          eye,
          identity,
          race,
          dice,
        ]);
        break;
      case 'phobia':
        builders.addAll([
          command,
          combat,
          hp,
          damage,
          dice,
          stats,
          values,
          editable,
          eye,
          identity,
          race,
          oculumResourcePanel,
          exp,
        ]);
        break;
      case 'chapel':
      case 'altar':
      case 'medieval':
        builders.addAll([
          eye,
          command,
          hp,
          damage,
          combat,
          stats,
          dice,
          values,
          editable,
          identity,
          race,
          oculumResourcePanel,
          exp,
        ]);
        break;
      case 'archive':
      case 'sigil':
      case 'relic':
        builders.addAll([
          identity,
          race,
          values,
          editable,
          stats,
          oculumResourcePanel,
          exp,
          command,
          combat,
          hp,
          damage,
          dice,
          eye,
        ]);
        break;
      case 'orbital':
      case 'slime':
      case 'elemental':
        builders.addAll([
          eye,
          command,
          stats,
          hp,
          oculumResourcePanel,
          damage,
          combat,
          dice,
          values,
          editable,
          identity,
          race,
          exp,
        ]);
        break;
      case 'classic':
      default:
        builders.addAll([
          stats,
          command,
          combat,
          values,
          hp,
          damage,
          dice,
          editable,
          eye,
          identity,
          race,
          oculumResourcePanel,
          exp,
        ]);
    }
    addTrailingTools();

    final sections = ListView.builder(
      key: sheetScrollKey('sheet_mobile'),
      padding: EdgeInsets.fromLTRB(dense ? 8 : 12, 8, dense ? 8 : 12, 24),
      // Compatibilità Flutter 3.41/3.44: rinominato in scrollCacheExtent
      // solo nelle versioni più recenti.
      // ignore: deprecated_member_use
      cacheExtent: 420,
      keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
      itemCount: builders.length,
      itemBuilder: (context, index) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: builders[index](),
      ),
    );
    return Column(
      children: [
        Material(
          color: Theme.of(context).colorScheme.surface,
          child: SizedBox(
            height: 52,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 8),
              children: [
                TextButton.icon(
                  onPressed: mostraModificaRapida,
                  icon: const Icon(Icons.edit_outlined, size: 18),
                  label: const Text('Modifica'),
                ),
                TextButton.icon(
                  onPressed: () =>
                      vaiAllaFunzione(page: 0, anchorId: 'sheet_damage_heal'),
                  icon: const Icon(Icons.favorite_outline, size: 18),
                  label: const Text('Danno / Cura'),
                ),
                TextButton.icon(
                  onPressed: () =>
                      vaiAllaFunzione(page: 4, anchorId: 'skills_root'),
                  icon: const Icon(Icons.bolt_outlined, size: 18),
                  label: const Text('Skill'),
                ),
                TextButton.icon(
                  onPressed: () => vaiAllaFunzione(page: 3, anchorId: 'art_0'),
                  icon: const Icon(Icons.visibility_outlined, size: 18),
                  label: const Text('Art'),
                ),
                TextButton.icon(
                  onPressed: () =>
                      vaiAllaFunzione(page: 0, anchorId: 'sheet_exp'),
                  icon: const Icon(Icons.auto_graph, size: 18),
                  label: const Text('EXP'),
                ),
              ],
            ),
          ),
        ),
        Expanded(child: sections),
      ],
    );
  }

  Widget manuscriptLivingDesktopPage(BoxConstraints constraints) {
    const paper = Color(0xFFE0CCA0);
    const ink = Color(0xFF24180F);
    const brass = Color(0xFFB88A3B);
    const shell = Color(0xFF0B0908);
    final moss = statFormulaColor('resilienza');
    final blood = statFormulaColor('volonta');
    final matter = statFormulaColor('materia');
    final oculum = statFormulaColor('oculum');
    final wide = constraints.maxWidth >= 760;
    final compact = constraints.maxWidth < 1500;

    Widget frame(Widget child, {Color border = brass, Color color = shell}) =>
        Container(
          decoration: BoxDecoration(
            color: color,
            border: Border.all(color: border.withValues(alpha: .72)),
            borderRadius: BorderRadius.circular(3),
          ),
          child: Stack(
            children: [
              Padding(padding: const EdgeInsets.all(5), child: child),
              const Positioned.fill(
                child: IgnorePointer(child: OculumManuscriptFrameOverlay()),
              ),
            ],
          ),
        );

    Widget stat(String label, int value, int maxValue, Color color) => Expanded(
      child: Container(
        height: compact ? 72 : 82,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: paper,
          border: Border.all(color: brass.withValues(alpha: .55)),
        ),
        child: DefaultTextStyle(
          style: const TextStyle(
            color: ink,
            fontFamily: 'serif',
            fontSize: 11,
            height: 1.2,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: TextStyle(
                  color: color,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.2,
                ),
              ),
              const SizedBox(height: 3),
              Text(
                label == 'VITA' && vitaAfonaAttiva()
                    ? '???'
                    : '$value / $maxValue',
                style: const TextStyle(
                  fontSize: 24,
                  height: 1.2,
                  fontWeight: FontWeight.w700,
                ),
              ),
              const Spacer(),
              if (!(label == 'VITA' && vitaAfonaAttiva()))
                ClipRRect(
                  borderRadius: BorderRadius.circular(1),
                  child: LinearProgressIndicator(
                    minHeight: 3,
                    value: maxValue <= 0
                        ? 0
                        : (value / maxValue).clamp(0.0, 1.0),
                    color: color,
                    backgroundColor: const Color(0xFF2B2119),
                  ),
                ),
            ],
          ),
        ),
      ),
    );

    Widget eyeHeader() => InkWell(
      onTap: () => vaiAllaFunzione(
        page: 0,
        anchorId: 'sheet_image',
        logTitle: 'Occhio Oculum',
      ),
      child: Stack(
        fit: StackFit.expand,
        children: [
          const DecoratedBox(
            decoration: BoxDecoration(color: Color(0xFFE0CCA0)),
          ),
          const OculumManuscriptReferenceCrop(
            source: Rect.fromLTWH(154, 30, 56, 38),
          ),
        ],
      ),
    );

    final stats = Container(
      height: constraints.maxWidth < 500 ? 150 : (compact ? 74 : 84),
      decoration: BoxDecoration(
        color: paper,
        border: Border.all(color: brass.withValues(alpha: .7)),
      ),
      child: constraints.maxWidth < 500
          ? Column(
              children: [
                Row(
                  children: [
                    stat('VITA', hpCorrenti(), maxHp(), moss),
                    stat(
                      'VOL',
                      currentVolonta(),
                      max(1, leggiNumero(volontaController)),
                      blood,
                    ),
                  ],
                ),
                const SizedBox(height: 2),
                Row(
                  children: [
                    stat(
                      'MAT',
                      currentMateria(),
                      max(1, leggiNumero(materiaController)),
                      matter,
                    ),
                    stat('OCU', oculumTotale(), oculumMassimo(), oculum),
                  ],
                ),
              ],
            )
          : Row(
              children: [
                stat('VITA', hpCorrenti(), maxHp(), moss),
                const SizedBox(width: 3),
                stat(
                  'VOL',
                  currentSpendableStatValue('volonta'),
                  max(1, leggiNumero(volontaController)),
                  blood,
                ),
                const SizedBox(width: 3),
                SizedBox(
                  width: compact ? 96 : 122,
                  height: compact ? 74 : 84,
                  child: eyeHeader(),
                ),
                const SizedBox(width: 3),
                stat(
                  'MAT',
                  currentSpendableStatValue('materia'),
                  max(1, leggiNumero(materiaController)),
                  matter,
                ),
                const SizedBox(width: 3),
                stat('OCU', oculumTotale(), oculumMassimo(), oculum),
              ],
            ),
    );

    Widget manuscriptHeading(String text) => Padding(
      padding: const EdgeInsets.fromLTRB(10, 9, 10, 6),
      child: Row(
        children: [
          Text(
            text,
            style: const TextStyle(
              color: brass,
              fontFamily: 'serif',
              fontWeight: FontWeight.w900,
              letterSpacing: 1.15,
            ),
          ),
          const SizedBox(width: 8),
          const Expanded(child: Divider(height: 1, color: Color(0xFF725326))),
        ],
      ),
    );

    Widget partyRow(int index) => Tooltip(
      message:
          '${nomeSchedaPersonaggio(index)} · ${tipoSchedaPersonaggio(index)}',
      child: InkWell(
        onTap: () => cambiaSchedaPersonaggio(index),
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 5, vertical: 3),
          decoration: BoxDecoration(
            color: index == schedaCorrente ? const Color(0xFF302419) : shell,
            border: Border.all(
              color: index == schedaCorrente ? brass : const Color(0xFF483820),
            ),
          ),
          child: Center(child: masterPartyAvatar(index, size: 42)),
        ),
      ),
    );
    final left = frame(
      Column(
        children: [
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 8),
            child: Icon(Icons.people_outline, color: brass, size: 18),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: schedePersonaggio.length,
              itemExtent: 60,
              addAutomaticKeepAlives: false,
              itemBuilder: (context, index) => partyRow(index),
            ),
          ),
          IconButton(
            tooltip: 'Gestisci personaggi',
            onPressed: () =>
                vaiAllaFunzione(page: 9, logTitle: 'Gestisci personaggi'),
            icon: const Icon(Icons.group_add_outlined, color: brass, size: 18),
          ),
        ],
      ),
    );

    Widget manuscriptSectionTab({
      required String label,
      required VoidCallback onPressed,
    }) {
      return TextButton(
        onPressed: onPressed,
        style: TextButton.styleFrom(
          foregroundColor: const Color(0xFFCAA85D),
          minimumSize: Size.zero,
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 7),
          tapTargetSize: MaterialTapTargetSize.shrinkWrap,
          shape: const RoundedRectangleBorder(),
        ),
        child: Text(
          label,
          style: const TextStyle(
            fontWeight: FontWeight.w900,
            letterSpacing: .55,
          ),
        ),
      );
    }

    Widget combatMetric(
      String label,
      String value,
      Color color,
      VoidCallback action,
    ) => InkWell(
      onTap: action,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
        child: Text(
          '$label $value',
          style: TextStyle(
            color: color,
            fontSize: 11,
            fontWeight: FontWeight.w900,
          ),
        ),
      ),
    );

    Widget actionRow(int i) => Container(
      padding: const EdgeInsets.fromLTRB(10, 9, 10, 8),
      decoration: const BoxDecoration(
        border: Border(
          bottom: BorderSide(color: Color(0xFF8F713A), width: .65),
        ),
      ),
      child: Row(
        children: [
          const Icon(
            Icons.auto_awesome_outlined,
            color: Color(0xFF6F5121),
            size: 27,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  skills[i].nome,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                Text(
                  [
                    skills[i].tipo,
                    if (skills[i].costo.trim().isNotEmpty) skills[i].costo,
                  ].where((value) => value.trim().isNotEmpty).join('  ·  '),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                if (skills[i].descrizione.trim().isNotEmpty)
                  Text(
                    skills[i].descrizione,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 12),
                  ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          OutlinedButton(
            style: OutlinedButton.styleFrom(
              foregroundColor: const Color(0xFF24180F),
              side: const BorderSide(color: Color(0xFF604415)),
              shape: const RoundedRectangleBorder(),
            ),
            onPressed: () => usaFormaSkill(skills[i], i, 0),
            child: const Text('USA'),
          ),
        ],
      ),
    );

    Widget basicAction(
      String title,
      String detail,
      IconData icon,
      VoidCallback use,
    ) => Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: const BoxDecoration(
        border: Border(bottom: BorderSide(color: Color(0xFF947747), width: .6)),
      ),
      child: Row(
        children: [
          Icon(icon, color: ink, size: 23),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    color: ink,
                    fontSize: 15,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                Text(
                  detail,
                  style: const TextStyle(
                    color: Color(0xFF584632),
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          ),
          OutlinedButton(
            onPressed: use,
            style: OutlinedButton.styleFrom(
              foregroundColor: ink,
              minimumSize: const Size(48, 32),
              padding: const EdgeInsets.symmetric(horizontal: 10),
              side: const BorderSide(color: Color(0xFF795C32)),
              shape: const RoundedRectangleBorder(),
            ),
            child: const Text('USA', style: TextStyle(fontSize: 10)),
          ),
        ],
      ),
    );
    final basicActions = <Widget>[
      basicAction(
        'Attacco · VC',
        '1d20 + ${vc()} · Danno ${dannoTotale()}',
        Icons.gps_fixed,
        () => tiraValoreSpeciale('VC', vc()),
      ),
      basicAction(
        'Difesa · CM',
        '1d20 + ${cm()} · Difesa ${difesa()}',
        Icons.shield_outlined,
        () => tiraValoreSpeciale('CM', cm()),
      ),
      basicAction(
        'Iniziativa',
        'Determina il tuo posto nel turno',
        Icons.hourglass_bottom,
        () => tiraValoreSpeciale('Iniziativa', iniziativa()),
      ),
      basicAction(
        'Danno / Cura',
        'Applica un danno o recupera Vita',
        Icons.favorite_border,
        () => vaiAllaFunzione(
          page: 0,
          anchorId: 'sheet_damage_heal',
          logTitle: 'Danno / Cura',
        ),
      ),
      basicAction(
        'Sottotratti',
        'Scegli la prova adatta alla scena',
        Icons.auto_stories_outlined,
        () => vaiAllaFunzione(
          page: 0,
          anchorId: 'sheet_editable_values',
          logTitle: 'Sottotratti',
        ),
      ),
    ];

    final center = frame(
      Container(
        color: paper,
        child: DefaultTextStyle.merge(
          style: const TextStyle(color: ink, fontFamily: 'serif'),
          child: Column(
            children: [
              Container(
                color: const Color(0xFF110E0B),
                padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 3),
                child: Wrap(
                  alignment: WrapAlignment.center,
                  spacing: 1,
                  runSpacing: 1,
                  children: [
                    manuscriptSectionTab(
                      label: 'AZIONI',
                      onPressed: () => vaiAllaFunzione(
                        page: 4,
                        anchorId: 'skills_root',
                        logTitle: 'Azioni',
                      ),
                    ),
                    manuscriptSectionTab(
                      label: 'ART',
                      onPressed: () => vaiAllaFunzione(
                        page: 3,
                        anchorId: 'art_0',
                        logTitle: 'Art',
                      ),
                    ),
                    manuscriptSectionTab(
                      label: 'REAZIONI',
                      onPressed: () => vaiAllaFunzione(
                        page: 0,
                        anchorId: 'sheet_editable_values',
                        logTitle: 'Reazioni',
                      ),
                    ),
                    manuscriptSectionTab(
                      label: 'OGGETTI',
                      onPressed: () => vaiAllaFunzione(
                        page: 6,
                        anchorId: 'inventory_root',
                        logTitle: 'Oggetti',
                      ),
                    ),
                    manuscriptSectionTab(
                      label: 'CONDIZIONI',
                      onPressed: () => vaiAllaFunzione(
                        page: _OculumHomePageState.quickConditionsPageIndex,
                        logTitle: 'Condizioni',
                      ),
                    ),
                    manuscriptSectionTab(
                      label: 'SOTTOTRATTI',
                      onPressed: () => vaiAllaFunzione(
                        page: 0,
                        anchorId: 'sheet_editable_values',
                        logTitle: 'Sottotratti',
                      ),
                    ),
                    manuscriptSectionTab(
                      label: 'ALTRO',
                      onPressed: () => vaiAllaFunzione(
                        page: 5,
                        anchorId: 'story_root',
                        logTitle: 'Altro',
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: const BoxDecoration(
                  border: Border(bottom: BorderSide(color: Color(0xFF6F5121))),
                ),
                child: Wrap(
                  spacing: 4,
                  runSpacing: 2,
                  children: [
                    combatMetric(
                      '♥',
                      hpReadoutProtetto(),
                      vitaAfonaAttiva() ? Colors.black : moss,
                      () => vaiAllaFunzione(page: 0, anchorId: 'sheet_hp'),
                    ),
                    combatMetric(
                      '◇',
                      '${scudo()}',
                      const Color(0xFF397C94),
                      () => vaiAllaFunzione(page: 0, anchorId: 'sheet_shield'),
                    ),
                    combatMetric(
                      'VC',
                      '${vc()}',
                      brass,
                      () => tiraValoreSpeciale('VC', vc()),
                    ),
                    combatMetric(
                      'CM',
                      '${cm()}',
                      ink,
                      () => tiraValoreSpeciale('CM', cm()),
                    ),
                    combatMetric(
                      '⚔',
                      '${dannoTotale()}',
                      blood,
                      () => vaiAllaFunzione(
                        page: 0,
                        anchorId: 'sheet_editable_values',
                      ),
                    ),
                    combatMetric(
                      '◈',
                      '${difesa()}',
                      moss,
                      () => vaiAllaFunzione(
                        page: 0,
                        anchorId: 'sheet_defense_bonus',
                      ),
                    ),
                    combatMetric(
                      '↩',
                      '${reazioniTotali()}',
                      brass,
                      () => vaiAllaFunzione(
                        page: 0,
                        anchorId: 'sheet_editable_values',
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: RepaintBoundary(
                  child: CustomPaint(
                    painter: const OculumManuscriptPaperPainter(),
                    child: ListView.builder(
                      itemCount: basicActions.length + skills.length,
                      addAutomaticKeepAlives: false,
                      itemBuilder: (context, index) =>
                          index < basicActions.length
                          ? basicActions[index]
                          : actionRow(index - basicActions.length),
                    ),
                  ),
                ),
              ),
              Container(
                color: const Color(0xFF110E0B),
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
                child: Wrap(
                  alignment: WrapAlignment.center,
                  spacing: 2,
                  children: [
                    manuscriptSectionTab(
                      label: 'RIPOSO',
                      onPressed: () => vaiAllaFunzione(
                        page: 1,
                        anchorId: 'rest_root',
                        logTitle: 'Riposo',
                      ),
                    ),
                    manuscriptSectionTab(
                      label: 'DANNO / CURA',
                      onPressed: () => vaiAllaFunzione(
                        page: 0,
                        anchorId: 'sheet_damage_heal',
                        logTitle: 'Danno / Cura',
                      ),
                    ),
                    manuscriptSectionTab(
                      label: 'TIRA VC',
                      onPressed: () => tiraValoreSpeciale('VC', vc()),
                    ),
                    manuscriptSectionTab(
                      label: 'TIRA CM',
                      onPressed: () => tiraValoreSpeciale('CM', cm()),
                    ),
                    manuscriptSectionTab(
                      label: 'MODIFICA',
                      onPressed: () => vaiAllaFunzione(
                        page: 0,
                        anchorId: 'sheet_editable_values',
                        logTitle: 'Modifica',
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
      color: paper,
    );
    Widget initiativeRow(int index) {
      final token = masterInitiativeTokens[index];
      final active = index == masterInitiativeActiveIndex;
      final enemy = '${token['side'] ?? ''}' == 'enemy';
      final initiative = readIntValue(token['initiative']);
      return InkWell(
        onTap: () => setMasterInitiativeActiveIndex(index),
        child: Container(
          height: 34,
          padding: const EdgeInsets.symmetric(horizontal: 8),
          decoration: BoxDecoration(
            color: active ? const Color(0xFF2A2012) : Colors.transparent,
            border: const Border(bottom: BorderSide(color: Color(0xFF4D381D))),
          ),
          child: Row(
            children: [
              SizedBox(
                width: 23,
                child: Text(
                  '${index + 1}',
                  style: TextStyle(
                    color: active ? brass : const Color(0xFF8B6C3B),
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
              Icon(
                active
                    ? Icons.play_arrow
                    : (enemy ? Icons.close : Icons.person_outline),
                size: 15,
                color: active ? brass : const Color(0xFFB69662),
              ),
              const SizedBox(width: 5),
              Expanded(
                child: Text(
                  '${token['name'] ?? '???'}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: active
                        ? const Color(0xFFE6D0A1)
                        : const Color(0xFFBDA77F),
                    fontWeight: active ? FontWeight.w900 : FontWeight.w600,
                  ),
                ),
              ),
              Text(
                '$initiative',
                style: const TextStyle(color: Color(0xFF8B6C3B), fontSize: 11),
              ),
            ],
          ),
        ),
      );
    }

    final right = frame(
      LayoutBuilder(
        builder: (context, pane) => SingleChildScrollView(
          child: SizedBox(
            height: max(640.0, pane.maxHeight),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                manuscriptHeading(
                  'TURNO ${masterInitiativeRound > 0 ? masterInitiativeRound : ''}',
                ),
                SizedBox(
                  height: masterInitiativeTokens.isEmpty
                      ? 45
                      : min(230.0, masterInitiativeTokens.length * 34.0),
                  child: masterInitiativeTokens.isEmpty
                      ? const Padding(
                          padding: EdgeInsets.symmetric(horizontal: 10),
                          child: Text(
                            'Nessuna iniziativa attiva.',
                            style: TextStyle(color: Color(0xFF9B8254)),
                          ),
                        )
                      : ListView.builder(
                          itemCount: masterInitiativeTokens.length,
                          itemExtent: 34,
                          itemBuilder: (context, index) => initiativeRow(index),
                        ),
                ),
                TextButton.icon(
                  onPressed: masterInitiativeTokens.isEmpty
                      ? null
                      : () => nextMasterInitiativeTurn(),
                  icon: const Icon(Icons.skip_next, size: 16),
                  label: const Text('TURNO SUCCESSIVO'),
                  style: TextButton.styleFrom(foregroundColor: brass),
                ),
                manuscriptHeading('BERSAGLIO'),
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 3,
                  ),
                  child: Text(
                    masterInitiativeTokens.isEmpty
                        ? 'Seleziona un bersaglio dalla turnistica o dalla mappa.'
                        : 'Usa la turnistica o la Mappa per cambiare bersaglio.',
                    style: const TextStyle(
                      color: Color(0xFFBDA77F),
                      fontSize: 11,
                    ),
                  ),
                ),
                TextButton(
                  onPressed: () => vaiAllaFunzione(
                    page: _OculumHomePageState.mapPageIndex,
                    logTitle: 'Mappa e bersaglio',
                  ),
                  style: TextButton.styleFrom(foregroundColor: brass),
                  child: const Text('CAMBIA BERSAGLIO'),
                ),
                manuscriptHeading('DADI RAPIDI'),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  child: Wrap(
                    spacing: 3,
                    runSpacing: 2,
                    children: [4, 6, 8, 10, 12, 20]
                        .map(
                          (faces) => OutlinedButton(
                            onPressed: () => tiraDado(faces),
                            style: OutlinedButton.styleFrom(
                              minimumSize: Size.zero,
                              padding: const EdgeInsets.symmetric(
                                horizontal: 7,
                                vertical: 5,
                              ),
                              foregroundColor: const Color(0xFFE0CCA0),
                              side: const BorderSide(color: Color(0xFF725326)),
                              shape: const RoundedRectangleBorder(),
                            ),
                            child: Text('d$faces'),
                          ),
                        )
                        .toList(growable: false),
                  ),
                ),
                TextButton(
                  onPressed: () => vaiAllaFunzione(
                    page: _OculumHomePageState.dicePageIndex,
                    logTitle: 'Tutti i dadi',
                  ),
                  style: TextButton.styleFrom(foregroundColor: brass),
                  child: const Text('TUTTI I DADI'),
                ),
                manuscriptHeading('FEED DEGLI EVENTI'),
                Expanded(
                  child: logEventi.isEmpty
                      ? const Padding(
                          padding: EdgeInsets.all(10),
                          child: Text(
                            'Gli eventi di gioco appariranno qui.',
                            style: TextStyle(
                              color: Color(0xFF9B8254),
                              fontSize: 11,
                            ),
                          ),
                        )
                      : ListView.builder(
                          reverse: true,
                          itemCount: min(24, logEventi.length),
                          itemBuilder: (context, index) => Padding(
                            padding: const EdgeInsets.fromLTRB(10, 3, 10, 3),
                            child: Text(
                              logEventi[logEventi.length - 1 - index],
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: Color(0xFFBDA77F),
                                fontSize: 11,
                              ),
                            ),
                          ),
                        ),
                ),
              ],
            ),
          ),
        ),
      ),
    );

    return Theme(
      data: Theme.of(context).copyWith(
        scaffoldBackgroundColor: shell,
        colorScheme: Theme.of(
          context,
        ).colorScheme.copyWith(primary: brass, surface: shell),
      ),
      child: Container(
        color: shell,
        child: Column(
          children: [
            frame(
              SizedBox(
                height: 40,
                child: Row(
                  children: [
                    if (!wide)
                      SizedBox(width: 60, height: 40, child: eyeHeader()),
                    if (wide)
                      const Padding(
                        padding: EdgeInsets.symmetric(horizontal: 16),
                        child: Text(
                          '◉  OCULUM',
                          style: TextStyle(
                            color: brass,
                            fontFamily: 'serif',
                            fontSize: 18,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 2,
                          ),
                        ),
                      ),
                    Expanded(
                      child: Text(
                        wide ? activeCampaignName() : nomeController.text,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Color(0xFFE0CCA0),
                          fontFamily: 'serif',
                        ),
                      ),
                    ),
                    const Text(
                      'GIOCA',
                      style: TextStyle(
                        color: brass,
                        fontFamily: 'serif',
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    SizedBox(width: wide ? 24 : 4),
                    TextButton(
                      onPressed: mostraModificaRapida,
                      child: const Text('MODIFICA'),
                    ),
                    const SizedBox(width: 10),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 4),
            stats,
            const SizedBox(height: 5),
            Expanded(
              child: wide
                  ? Row(
                      children: [
                        SizedBox(width: 66, child: left),
                        const SizedBox(width: 5),
                        Expanded(child: center),
                        const SizedBox(width: 5),
                        SizedBox(width: compact ? 200 : 248, child: right),
                      ],
                    )
                  : DefaultTabController(
                      length: 2,
                      child: Column(
                        children: [
                          SizedBox(
                            height: 68,
                            child: ListView.builder(
                              scrollDirection: Axis.horizontal,
                              itemCount: schedePersonaggio.length,
                              itemExtent: 62,
                              itemBuilder: (context, index) => partyRow(index),
                            ),
                          ),
                          const TabBar(
                            labelColor: brass,
                            unselectedLabelColor: paper,
                            indicatorColor: brass,
                            tabs: [
                              Tab(text: 'AZIONI E ART'),
                              Tab(text: 'TURNO E DADI'),
                            ],
                          ),
                          Expanded(
                            child: TabBarView(children: [center, right]),
                          ),
                        ],
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget characterDesktopPage() {
    return LayoutBuilder(
      builder: (context, constraints) {
        if (constraints.maxWidth < 860) return characterMobilePage();
        if (manuscriptLivingActive && !manuscriptEditing) {
          return manuscriptLivingDesktopPage(constraints);
        }

        final layoutId =
            currentThemeVisualIdentity().mainSheetGuiStyle.sheetLayoutId;
        final wide = constraints.maxWidth >= 1180;
        final veryWide = constraints.maxWidth >= 1500;
        final gap = modalitaVeloce ? 8.0 : 10.0;
        final sideWidth = modalitaVeloce
            ? (veryWide ? 292.0 : 252.0)
            : (veryWide ? 310.0 : 264.0);

        Widget hpDamageRow() => LayoutBuilder(
          builder: (context, hpDamageConstraints) {
            final hpCard = functionAnchor('sheet_hp', hpModePanel());
            final damageCard = functionAnchor(
              'sheet_damage_heal',
              damageHealPanel(),
            );
            if (hpDamageConstraints.maxWidth < 620) {
              return Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  hpCard,
                  SizedBox(height: gap),
                  damageCard,
                ],
              );
            }
            return themedSheetDesktopRow([
              Expanded(child: hpCard),
              Expanded(child: damageCard),
            ], gap: gap);
          },
        );

        List<Widget> identityCards() => [
          functionAnchor('sheet_image', oculumEyeBox()),
          functionAnchor(
            'sheet_identity',
            sheetIdentityEditorPanel(dense: true),
          ),
          functionAnchor('sheet_race', raceIdentityPanel()),
          oculumResourcePanel(),
          functionAnchor('sheet_exp', experiencePanel()),
        ];

        List<Widget> commandCards() => [
          functionAnchor('sheet_command_center', sheetCommandCenter()),
          functionAnchor(
            'sheet_combat_values',
            combatOverviewPanel(dense: true),
          ),
          hpDamageRow(),
          functionAnchor('sheet_stats', statsOverviewPanel(dense: true)),
          functionAnchor('sheet_values', mainValuesOverviewPanel(dense: true)),
          functionAnchor('sheet_editable_values', editableMainValuesDropdown()),
          gradeBonusActionButton(),
        ];

        List<Widget> valueFirstCards() => [
          functionAnchor('sheet_values', mainValuesOverviewPanel(dense: true)),
          functionAnchor('sheet_editable_values', editableMainValuesDropdown()),
          functionAnchor('sheet_stats', statsOverviewPanel(dense: true)),
          functionAnchor(
            'sheet_combat_values',
            combatOverviewPanel(dense: true),
          ),
          hpDamageRow(),
          gradeBonusActionButton(),
        ];

        List<Widget> toolCards({bool includeResult = true}) => [
          desktopQuickBagSidePanel(),
          desktopArtSkillTextSidePanel(),
          functionAnchor(
            'sheet_dice_quick',
            sheetDiceDropdownPanel(dense: true),
          ),
          functionAnchor('sheet_party', partyPanel()),
          if (!modalitaVeloce) quickIndexButtonsPanel(),
          if (!modalitaVeloce) manualQuickToolsPanel(),
          if (includeResult) diceResultPanel(),
        ];

        Widget identityColumn({double? width, int flex = 1}) =>
            themedSheetDesktopColumn(
              width: width,
              flex: flex,
              children: identityCards(),
            );

        Widget commandColumn({double? width, int flex = 1}) =>
            themedSheetDesktopColumn(
              width: width,
              flex: flex,
              children: commandCards(),
            );

        Widget valuesColumn({double? width, int flex = 1}) =>
            themedSheetDesktopColumn(
              width: width,
              flex: flex,
              children: valueFirstCards(),
            );

        Widget toolsColumn({
          double? width,
          int flex = 1,
          bool includeResult = true,
        }) => themedSheetDesktopColumn(
          width: width,
          flex: flex,
          children: toolCards(includeResult: includeResult),
        );

        Widget combatFirstColumn({double? width, int flex = 1}) =>
            themedSheetDesktopColumn(
              width: width,
              flex: flex,
              children: [
                functionAnchor(
                  'sheet_combat_values',
                  combatOverviewPanel(dense: true),
                ),
                hpDamageRow(),
                functionAnchor('sheet_stats', statsOverviewPanel(dense: true)),
                functionAnchor('sheet_command_center', sheetCommandCenter()),
                functionAnchor(
                  'sheet_values',
                  mainValuesOverviewPanel(dense: true),
                ),
                functionAnchor(
                  'sheet_editable_values',
                  editableMainValuesDropdown(),
                ),
                gradeBonusActionButton(),
              ],
            );

        Widget machineActionColumn({double? width, int flex = 1}) =>
            themedSheetDesktopColumn(
              width: width,
              flex: flex,
              children: [
                functionAnchor('sheet_command_center', sheetCommandCenter()),
                functionAnchor(
                  'sheet_values',
                  mainValuesOverviewPanel(dense: true),
                ),
                functionAnchor(
                  'sheet_editable_values',
                  editableMainValuesDropdown(),
                ),
                desktopQuickBagSidePanel(),
                desktopArtSkillTextSidePanel(),
                if (!modalitaVeloce) quickIndexButtonsPanel(),
                if (!modalitaVeloce) manualQuickToolsPanel(),
              ],
            );

        Widget machineCombatColumn({double? width, int flex = 1}) =>
            themedSheetDesktopColumn(
              width: width,
              flex: flex,
              children: [
                functionAnchor(
                  'sheet_combat_values',
                  combatOverviewPanel(dense: true),
                ),
                hpDamageRow(),
                functionAnchor('sheet_stats', statsOverviewPanel(dense: true)),
                gradeBonusActionButton(),
                functionAnchor('sheet_party', partyPanel()),
                functionAnchor(
                  'sheet_dice_quick',
                  sheetDiceDropdownPanel(dense: true),
                ),
                diceResultPanel(),
              ],
            );

        Widget machineIdentityColumn({double? width, int flex = 1}) =>
            themedSheetDesktopColumn(
              width: width,
              flex: flex,
              children: [
                functionAnchor('sheet_image', oculumEyeBox()),
                functionAnchor(
                  'sheet_identity',
                  sheetIdentityEditorPanel(dense: true),
                ),
                functionAnchor('sheet_race', raceIdentityPanel()),
                oculumResourcePanel(),
                functionAnchor('sheet_exp', experiencePanel()),
              ],
            );

        Widget videoHudControlsColumn({double? width, int flex = 1}) =>
            themedSheetDesktopColumn(
              width: width,
              flex: flex,
              children: [
                functionAnchor('sheet_command_center', sheetCommandCenter()),
                functionAnchor(
                  'sheet_dice_quick',
                  sheetDiceDropdownPanel(dense: true),
                ),
                diceResultPanel(),
                if (!modalitaVeloce) quickIndexButtonsPanel(),
              ],
            );

        Widget videoHudLiveColumn({double? width, int flex = 1}) =>
            themedSheetDesktopColumn(
              width: width,
              flex: flex,
              children: [
                hpDamageRow(),
                functionAnchor(
                  'sheet_combat_values',
                  combatOverviewPanel(dense: true),
                ),
                functionAnchor('sheet_stats', statsOverviewPanel(dense: true)),
                gradeBonusActionButton(),
              ],
            );

        Widget videoHudInfoColumn({double? width, int flex = 1}) =>
            themedSheetDesktopColumn(
              width: width,
              flex: flex,
              children: [
                functionAnchor(
                  'sheet_values',
                  mainValuesOverviewPanel(dense: true),
                ),
                functionAnchor(
                  'sheet_editable_values',
                  editableMainValuesDropdown(),
                ),
                oculumResourcePanel(),
                functionAnchor('sheet_party', partyPanel()),
                desktopQuickBagSidePanel(),
              ],
            );

        Widget tacticalIdentityColumn({double? width, int flex = 1}) =>
            themedSheetDesktopColumn(
              width: width,
              flex: flex,
              children: [
                functionAnchor('sheet_image', oculumEyeBox()),
                functionAnchor(
                  'sheet_identity',
                  sheetIdentityEditorPanel(dense: true),
                ),
                functionAnchor('sheet_race', raceIdentityPanel()),
                oculumResourcePanel(),
                functionAnchor('sheet_exp', experiencePanel()),
              ],
            );

        Widget tacticalLiveColumn({double? width, int flex = 1}) =>
            themedSheetDesktopColumn(
              width: width,
              flex: flex,
              children: [
                functionAnchor('sheet_command_center', sheetCommandCenter()),
                hpDamageRow(),
                functionAnchor('sheet_stats', statsOverviewPanel(dense: true)),
                functionAnchor(
                  'sheet_combat_values',
                  combatOverviewPanel(dense: true),
                ),
                gradeBonusActionButton(),
              ],
            );

        Widget tacticalToolsColumn({double? width, int flex = 1}) =>
            themedSheetDesktopColumn(
              width: width,
              flex: flex,
              children: [
                functionAnchor(
                  'sheet_values',
                  mainValuesOverviewPanel(dense: true),
                ),
                functionAnchor(
                  'sheet_editable_values',
                  editableMainValuesDropdown(),
                ),
                functionAnchor(
                  'sheet_dice_quick',
                  sheetDiceDropdownPanel(dense: true),
                ),
                desktopQuickBagSidePanel(),
                functionAnchor('sheet_party', partyPanel()),
                diceResultPanel(),
              ],
            );

        Widget battleFocusLeftColumn({double? width, int flex = 1}) =>
            themedSheetDesktopColumn(
              width: width,
              flex: flex,
              children: [
                functionAnchor('sheet_command_center', sheetCommandCenter()),
                functionAnchor(
                  'sheet_dice_quick',
                  sheetDiceDropdownPanel(dense: true),
                ),
                diceResultPanel(),
                functionAnchor('sheet_party', partyPanel()),
              ],
            );

        Widget battleFocusCenterColumn({double? width, int flex = 1}) =>
            themedSheetDesktopColumn(
              width: width,
              flex: flex,
              children: [
                functionAnchor(
                  'sheet_combat_values',
                  combatOverviewPanel(dense: true),
                ),
                hpDamageRow(),
                functionAnchor('sheet_stats', statsOverviewPanel(dense: true)),
                gradeBonusActionButton(),
              ],
            );

        Widget battleFocusRightColumn({double? width, int flex = 1}) =>
            themedSheetDesktopColumn(
              width: width,
              flex: flex,
              children: [
                functionAnchor(
                  'sheet_values',
                  mainValuesOverviewPanel(dense: true),
                ),
                functionAnchor(
                  'sheet_editable_values',
                  editableMainValuesDropdown(),
                ),
                oculumResourcePanel(),
                desktopQuickBagSidePanel(),
                functionAnchor(
                  'sheet_identity',
                  sheetIdentityEditorPanel(dense: true),
                ),
              ],
            );

        Widget quickGrimoireIndexColumn({double? width, int flex = 1}) =>
            themedSheetDesktopColumn(
              width: width,
              flex: flex,
              children: [
                functionAnchor(
                  'sheet_values',
                  mainValuesOverviewPanel(dense: true),
                ),
                functionAnchor(
                  'sheet_editable_values',
                  editableMainValuesDropdown(),
                ),
                functionAnchor('sheet_stats', statsOverviewPanel(dense: true)),
                gradeBonusActionButton(),
              ],
            );

        Widget quickGrimoirePlayColumn({double? width, int flex = 1}) =>
            themedSheetDesktopColumn(
              width: width,
              flex: flex,
              children: [
                functionAnchor('sheet_command_center', sheetCommandCenter()),
                hpDamageRow(),
                functionAnchor(
                  'sheet_combat_values',
                  combatOverviewPanel(dense: true),
                ),
                functionAnchor(
                  'sheet_dice_quick',
                  sheetDiceDropdownPanel(dense: true),
                ),
                diceResultPanel(),
              ],
            );

        Widget quickGrimoireLoreColumn({double? width, int flex = 1}) =>
            themedSheetDesktopColumn(
              width: width,
              flex: flex,
              children: [
                functionAnchor('sheet_image', oculumEyeBox()),
                functionAnchor(
                  'sheet_identity',
                  sheetIdentityEditorPanel(dense: true),
                ),
                functionAnchor('sheet_race', raceIdentityPanel()),
                oculumResourcePanel(),
                desktopQuickBagSidePanel(),
                if (!modalitaVeloce) manualQuickToolsPanel(),
              ],
            );

        final children = <Widget>[
          functionAnchor('sheet_quick_glance', occhiataVeloceRaWidget()),
        ];

        switch (layoutId) {
          case 'video_hud':
            children.add(
              themedSheetDesktopRow(
                wide
                    ? [
                        videoHudControlsColumn(flex: 3),
                        videoHudLiveColumn(flex: 4),
                        videoHudInfoColumn(flex: 3),
                      ]
                    : [
                        videoHudControlsColumn(flex: 1),
                        videoHudLiveColumn(flex: 1),
                      ],
                gap: gap,
              ),
            );
            if (!wide) {
              children
                ..add(SizedBox(height: gap))
                ..add(videoHudInfoColumn());
            }
            break;
          case 'tactical_board':
            children.add(
              themedSheetDesktopRow(
                wide
                    ? [
                        tacticalIdentityColumn(flex: 3),
                        tacticalLiveColumn(flex: 4),
                        tacticalToolsColumn(flex: 3),
                      ]
                    : [
                        tacticalLiveColumn(flex: 1),
                        tacticalIdentityColumn(width: sideWidth),
                      ],
                gap: gap,
              ),
            );
            if (!wide) {
              children
                ..add(SizedBox(height: gap))
                ..add(tacticalToolsColumn());
            }
            break;
          case 'battle_focus':
            children.add(
              themedSheetDesktopRow(
                wide
                    ? [
                        battleFocusLeftColumn(flex: 3),
                        battleFocusCenterColumn(flex: 4),
                        battleFocusRightColumn(flex: 3),
                      ]
                    : [
                        battleFocusCenterColumn(flex: 1),
                        battleFocusLeftColumn(width: sideWidth),
                      ],
                gap: gap,
              ),
            );
            if (!wide) {
              children
                ..add(SizedBox(height: gap))
                ..add(battleFocusRightColumn());
            }
            break;
          case 'quick_grimoire':
            children.add(
              themedSheetDesktopRow(
                wide
                    ? [
                        quickGrimoireIndexColumn(flex: 3),
                        quickGrimoirePlayColumn(flex: 4),
                        quickGrimoireLoreColumn(flex: 3),
                      ]
                    : [
                        quickGrimoireIndexColumn(flex: 1),
                        quickGrimoirePlayColumn(flex: 1),
                      ],
                gap: gap,
              ),
            );
            if (!wide) {
              children
                ..add(SizedBox(height: gap))
                ..add(quickGrimoireLoreColumn());
            }
            break;
          case 'soft_orbit':
            children.add(
              themedSheetDesktopRow(
                wide
                    ? [
                        identityColumn(flex: 3),
                        commandColumn(flex: 4),
                        toolsColumn(flex: 3),
                      ]
                    : [
                        identityColumn(width: sideWidth),
                        commandColumn(flex: 1),
                      ],
                gap: gap,
              ),
            );
            if (!wide) {
              children
                ..add(SizedBox(height: gap))
                ..add(toolsColumn());
            }
            break;
          case 'botanical':
          case 'lantern':
            children.add(
              wide
                  ? themedSheetDesktopRow([
                      combatFirstColumn(flex: 3),
                      identityColumn(flex: 4),
                      toolsColumn(flex: 3),
                    ], gap: gap)
                  : themedSheetDesktopRow([
                      identityColumn(width: sideWidth),
                      combatFirstColumn(flex: 1),
                    ], gap: gap),
            );
            if (!wide) {
              children
                ..add(SizedBox(height: gap))
                ..add(toolsColumn());
            }
            break;
          case 'machine':
            children.add(
              themedSheetDesktopRow([
                machineActionColumn(flex: wide ? 3 : 1),
                machineCombatColumn(flex: wide ? 4 : 1),
                if (wide) machineIdentityColumn(flex: 3),
              ], gap: gap),
            );
            if (!wide) {
              children
                ..add(SizedBox(height: gap))
                ..add(machineIdentityColumn());
            }
            break;
          case 'phobia':
            children.add(
              themedSheetDesktopRow(
                wide
                    ? [
                        themedSheetDesktopColumn(
                          flex: 3,
                          children: [
                            functionAnchor(
                              'sheet_command_center',
                              sheetCommandCenter(),
                            ),
                            functionAnchor(
                              'sheet_dice_quick',
                              sheetDiceDropdownPanel(dense: true),
                            ),
                            diceResultPanel(),
                          ],
                        ),
                        combatFirstColumn(flex: 4),
                        themedSheetDesktopColumn(
                          flex: 3,
                          children: [
                            functionAnchor('sheet_image', oculumEyeBox()),
                            functionAnchor(
                              'sheet_identity',
                              sheetIdentityEditorPanel(dense: true),
                            ),
                            functionAnchor('sheet_race', raceIdentityPanel()),
                            desktopQuickBagSidePanel(),
                            functionAnchor('sheet_party', partyPanel()),
                            desktopArtSkillTextSidePanel(),
                          ],
                        ),
                      ]
                    : [
                        commandColumn(flex: 1),
                        identityColumn(width: sideWidth),
                      ],
                gap: gap,
              ),
            );
            if (!wide) {
              children
                ..add(SizedBox(height: gap))
                ..add(toolsColumn());
            }
            break;
          case 'chapel':
          case 'altar':
          case 'medieval':
            children.add(
              themedSheetDesktopRow(
                wide
                    ? [
                        identityColumn(flex: 3),
                        commandColumn(flex: 4),
                        toolsColumn(flex: 3),
                      ]
                    : [
                        commandColumn(flex: 1),
                        themedSheetDesktopColumn(
                          width: sideWidth,
                          children: [
                            functionAnchor('sheet_image', oculumEyeBox()),
                            functionAnchor(
                              'sheet_identity',
                              sheetIdentityEditorPanel(dense: true),
                            ),
                            oculumResourcePanel(),
                            functionAnchor('sheet_exp', experiencePanel()),
                          ],
                        ),
                      ],
                gap: gap,
              ),
            );
            if (!wide) {
              children
                ..add(SizedBox(height: gap))
                ..add(toolsColumn());
            }
            break;
          case 'archive':
          case 'sigil':
          case 'relic':
            children.add(
              themedSheetDesktopRow(
                wide
                    ? [
                        themedSheetDesktopColumn(
                          flex: 3,
                          children: [
                            functionAnchor(
                              'sheet_command_center',
                              sheetCommandCenter(),
                            ),
                            ...valueFirstCards(),
                          ],
                        ),
                        identityColumn(flex: 4),
                        toolsColumn(flex: 3),
                      ]
                    : [valuesColumn(flex: 1), identityColumn(width: sideWidth)],
                gap: gap,
              ),
            );
            if (!wide) {
              children
                ..add(SizedBox(height: gap))
                ..add(
                  functionAnchor('sheet_command_center', sheetCommandCenter()),
                );
            }
            if (!wide) {
              children
                ..add(SizedBox(height: gap))
                ..add(toolsColumn());
            }
            break;
          case 'orbital':
          case 'slime':
          case 'elemental':
            children.add(
              themedSheetDesktopRow(
                wide
                    ? [
                        identityColumn(flex: 3),
                        commandColumn(flex: 4),
                        toolsColumn(flex: 3),
                      ]
                    : [
                        identityColumn(width: sideWidth),
                        commandColumn(flex: 1),
                      ],
                gap: gap,
              ),
            );
            if (!wide) {
              children
                ..add(SizedBox(height: gap))
                ..add(toolsColumn());
            }
            break;
          case 'classic':
          default:
            children.add(
              themedSheetDesktopRow(
                wide
                    ? [
                        identityColumn(flex: 3),
                        commandColumn(flex: 4),
                        toolsColumn(flex: 3),
                      ]
                    : [
                        identityColumn(width: sideWidth),
                        commandColumn(flex: 1),
                      ],
                gap: gap,
              ),
            );
            if (!wide) {
              children
                ..add(SizedBox(height: gap))
                ..add(
                  themedSheetDesktopRow([
                    Expanded(child: desktopQuickBagSidePanel()),
                    Expanded(child: desktopArtSkillTextSidePanel()),
                  ], gap: gap),
                )
                ..add(
                  functionAnchor(
                    'sheet_dice_quick',
                    sheetDiceDropdownPanel(dense: true),
                  ),
                )
                ..add(functionAnchor('sheet_party', partyPanel()));
              if (!modalitaVeloce) children.add(manualQuickToolsPanel());
              children.add(diceResultPanel());
            }
        }

        return ListView.builder(
          key: sheetScrollKey('sheet_desktop'),
          padding: EdgeInsets.all(modalitaVeloce ? 8 : 10),
          itemCount: children.length,
          itemBuilder: (context, index) => children[index],
        );
      },
    );
  }

  Widget characterPage() {
    if (manuscriptLivingActive && !manuscriptEditing) {
      return LayoutBuilder(
        builder: (context, constraints) =>
            manuscriptLivingDesktopPage(constraints),
      );
    }
    final viewportWidth = MediaQuery.maybeOf(context)?.size.width ?? 1200;
    final content = !modalitaDesktop || phoneCompactUi || viewportWidth < 700
        ? characterMobilePage()
        : characterDesktopPage();
    if (!manuscriptLivingActive) return content;
    return Column(
      children: [
        Align(
          alignment: Alignment.centerLeft,
          child: TextButton.icon(
            onPressed: () =>
                updateOculumHomeUi(() => manuscriptEditing = false),
            icon: const Icon(Icons.arrow_back),
            label: const Text('Torna a Gioca'),
          ),
        ),
        Expanded(child: content),
      ],
    );
  }

  // =====================================================
}

/// A fixed seed keeps the engraving still across rebuilds. No image decoding
/// or generated bitmap is needed for the parchment surface.
class OculumManuscriptReferenceCrop extends StatelessWidget {
  const OculumManuscriptReferenceCrop({super.key, required this.source});
  final Rect source;

  @override
  Widget build(BuildContext context) => LayoutBuilder(
    builder: (context, constraints) {
      final scale = max(
        constraints.maxWidth / source.width,
        constraints.maxHeight / source.height,
      );
      return ClipRect(
        child: Stack(
          clipBehavior: Clip.hardEdge,
          children: [
            Positioned(
              left:
                  (constraints.maxWidth - source.width * scale) / 2 -
                  source.left * scale,
              top:
                  (constraints.maxHeight - source.height * scale) / 2 -
                  source.top * scale,
              width: 364 * scale,
              height: 253 * scale,
              child: Image.asset(
                'assets/oculum/manuscript_reference.png',
                fit: BoxFit.fill,
                filterQuality: FilterQuality.high,
                excludeFromSemantics: true,
              ),
            ),
          ],
        ),
      );
    },
  );
}

/// Decorative strips from the user's reference; all controls remain native.
class OculumManuscriptFrameOverlay extends StatelessWidget {
  const OculumManuscriptFrameOverlay({super.key});
  @override
  Widget build(BuildContext context) => const Stack(
    children: [
      Positioned(
        left: 0,
        right: 0,
        top: 0,
        height: 5,
        child: OculumManuscriptReferenceCrop(
          source: Rect.fromLTWH(45, 73, 213, 5),
        ),
      ),
      Positioned(
        left: 0,
        right: 0,
        bottom: 0,
        height: 5,
        child: OculumManuscriptReferenceCrop(
          source: Rect.fromLTWH(45, 235, 213, 5),
        ),
      ),
      Positioned(
        left: 0,
        top: 0,
        bottom: 0,
        width: 5,
        child: OculumManuscriptReferenceCrop(
          source: Rect.fromLTWH(40, 80, 5, 150),
        ),
      ),
      Positioned(
        right: 0,
        top: 0,
        bottom: 0,
        width: 5,
        child: OculumManuscriptReferenceCrop(
          source: Rect.fromLTWH(261, 80, 5, 150),
        ),
      ),
    ],
  );
}

class OculumManuscriptPaperPainter extends CustomPainter {
  const OculumManuscriptPaperPainter();
  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    canvas.drawRect(
      rect,
      Paint()
        ..shader = const LinearGradient(
          colors: [Color(0xFFC6AD7C), Color(0xFFE7D6AF), Color(0xFFD9C397)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ).createShader(rect),
    );
    final random = Random(91);
    final grain = Paint()
      ..color = const Color(0xFF513B21).withValues(alpha: .075);
    for (var i = 0; i < 750; i++) {
      final x = random.nextDouble() * size.width;
      final y = random.nextDouble() * size.height;
      canvas.drawLine(
        Offset(x, y),
        Offset(x + random.nextDouble() * 5, y),
        grain,
      );
    }
    final edge = Paint()
      ..color = const Color(0xFF846536).withValues(alpha: .4)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;
    canvas.drawRect(rect.deflate(4), edge);
    for (final corner in [
      rect.topLeft,
      rect.topRight,
      rect.bottomLeft,
      rect.bottomRight,
    ]) {
      canvas.drawCircle(corner, 15, edge);
      canvas.drawCircle(corner, 19, edge);
    }
  }

  @override
  bool shouldRepaint(covariant OculumManuscriptPaperPainter oldDelegate) =>
      false;
}
