import 'package:flutter_test/flutter_test.dart';
import 'package:oculum/main.dart';

void main() {
  group('mod Oculus', () {
    test('inizia con quattro dadi d4 e conserva una sola scheda dati', () {
      final data = oculusDefaultCharacterData();
      expect(data['resilienzaDie'], 4);
      expect(data['volontaDie'], 4);
      expect(data['materiaDie'], 4);
      expect(data['oculumDie'], 4);
      expect(data['forceDie'], 4);
      expect(data['activeForce'], 'fato');
      expect(data['skills'], hasLength(3));
      expect(data['artSkills'], hasLength(3));
      expect(data['missions'], hasLength(12));
      expect(data['inspirations'], 3);
      expect(data['growthPoints'], 0);
    });

    test('normalizza dati legacy senza perdere campi sconosciuti', () {
      final data = oculusNormalizeCharacterData(<String, dynamic>{
        'name': 'Iris',
        'skills': <String>['Una'],
        'level': 99,
        'progress': 8,
        'desire': 'Dato legacy da conservare',
        'futureField': 7,
      });
      expect(data['name'], 'Iris');
      expect(data['skills'], hasLength(3));
      expect(data['level'], 12);
      expect(data['progress'], 2);
      expect(data['desire'], 'Dato legacy da conservare');
      expect(data['futureField'], 7);
    });

    test('aggiunge Forme Art senza perdere le Skill dei salvataggi vecchi', () {
      final data = oculusNormalizeCharacterData(<String, dynamic>{
        'skills': <String>['Filo di Brace\n3 danni', 'Muro', 'Eco'],
        'artSkills': <Map<String, dynamic>>[
          <String, dynamic>{'name': 'Filo di Brace', 'formI': 'Tre danni'},
        ],
      });
      final artSkills = (data['artSkills'] as List).cast<Map>();

      expect(data['skills'], <String>['Filo di Brace\n3 danni', 'Muro', 'Eco']);
      expect(artSkills, hasLength(3));
      expect(artSkills[0]['name'], 'Filo di Brace');
      expect(artSkills[0]['formI'], 'Tre danni');
      expect(artSkills[1]['name'], 'Muro');
      expect(artSkills[2]['name'], 'Eco');
    });

    test('il dado Potere segue i livelli del Titolo del manuale', () {
      expect(oculusPowerDieForTitleLevel(0), 4);
      expect(oculusPowerDieForTitleLevel(2), 6);
      expect(oculusPowerDieForTitleLevel(4), 8);
      expect(oculusPowerDieForTitleLevel(7), 10);
      expect(oculusPowerDieForTitleLevel(10), 12);
      expect(oculusPowerDieForTitleLevel(12), 20);
      expect(oculusPowerDieForTitleLevel(99), 20);
    });

    test('ogni Art predefinita offre sei Skill e se ne scelgono tre', () {
      expect(
        oculusArtSkillCatalog.keys,
        containsAll(<String>[
          'Fuoco',
          'Acqua',
          'Terra',
          'Aria',
          'Luce',
          'Ombra',
        ]),
      );
      for (final skills in oculusArtSkillCatalog.values) {
        expect(skills, hasLength(6));
        expect(skills.map((skill) => skill.$1).toSet(), hasLength(6));
      }
    });
  });

  test('un sottotratto Homebrew resta compatibile nel JSON', () {
    final original = HiddenEyeStat(
      id: 'homebrew_eco_rosso',
      nome: 'Eco Rosso',
      descrizione: 'Ascolta il sangue.',
      valore: 2,
      category: 'altro',
      homebrew: true,
    );
    final restored = HiddenEyeStat.fromJson(original.toJson());
    expect(restored.category, 'altro');
    expect(restored.homebrew, isTrue);
    expect(restored.valore, 2);
  });
}
